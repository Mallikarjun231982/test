### Services Standard Deployment ###

## Folder Structure ##
build 		- Services Standard Build
frameworks 	- Servies Standard Frameworks
words 		- Project documentation, design, etc...
test 		- soon to be developed test framework

## Build Files ##

commons.xml - Common ANT properties and build targets

<module>/build.xml 		- calls the commons.xml and builds the module, overide targets to change the behavior
<module>/build.properties	- set the module specific build propeties
<module>/src			- the source files for the module
<moduel>/test			- test files along with test.xml ANT file used for executing function tests
<module>/build			- all the temporary build files.  Where we compile, package and test the source, exculded from SVN

### Getting started ###
1.  cd build
2.  ant package
- Under build folder you should have a ssb-<version>.zip file
3. ant test
- Runs the test.xml targets

Running ant from any folder should display simple help.
