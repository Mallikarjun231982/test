package com.philips.util;

import sailpoint.api.SailPointContext;
import sailpoint.object.Application;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.QueryOptions;
import sailpoint.tools.GeneralException;
import sailpoint.tools.ldap.LDAPUtil;
import org.apache.commons.logging.Log;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class PHLDAPUtil {

    /**
     * Establishes the connection to a LDAP application
     * @param context Sailpointcontext
     * @param applicationName Name of the LDAP application
     * @return DirContext with all connection parameter to the application
     */
    public static DirContext getDirContextByApplicationName(SailPointContext context, String applicationName) {
        DirContext dirContext = null;
        Log log = org.apache.commons.logging.LogFactory.getLog("com.philips.util.PHLDAPUtil");
        Application application = null;
        try {
            application = context.getObjectByName(Application.class, applicationName);
            log.debug("Getting application");
       } catch (GeneralException ge){
            log.error("Error getting application: ", ge);
            return null;
        }
        String provider_url;
        Hashtable env = new Hashtable();
        if(application.getAttributeValue("useSSL")!= null && Boolean.valueOf(application.getAttributeValue("useSSL").toString())) {
         log.debug("application uses ssl");
         provider_url = "ldaps://" + application.getAttributeValue("forestGC") + ":686";// + application.getAttributeValue("port");
        } else {
			log.debug("application do not use ssl");
           provider_url = "ldap://" + application.getAttributeValue("forestGC") + ":389";// + application.getAttributeValue("port");
        }
        try {
			log.debug("initializing dirxContext");
			log.debug("application" + application.getAttributeValue("domainSettings"));
			log.debug("user" + application.getAttributeValue("forestAdmin"));

            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            env.put(Context.PROVIDER_URL, provider_url);
            env.put(Context.SECURITY_AUTHENTICATION, "simple");
            env.put(Context.SECURITY_PRINCIPAL, application.getAttributeValue("forestAdmin").toString());         // username
            env.put(Context.SECURITY_CREDENTIALS, context.decrypt(application.getAttributeValue("forestAdminPassword").toString()));      // password
			log.debug("env" + env);

            dirContext = new InitialDirContext(env);
        } catch (GeneralException ge){
            log.error("Error decrypting password: ", ge);
            return null;
        } catch (NamingException ne){
            log.error("LDAP Error: ", ne);
            return null;
        }

        return dirContext;
    }

    /**
     * Return the value of an attribute from an specific entry
     * @param context Sailpoint context
     * @param dn of the entry
     * @param attribute name
     * @param applicationName name of the application in iiq
     * @return Returns the value of the attribute from a specific entry or null on error
     */
    public static String getAttributeValue(SailPointContext context, String dn, String attribute, String applicationName) {
        Log log = org.apache.commons.logging.LogFactory.getLog("com.philips.util.PHLDAPUtil");
        String result = null;

        DirContext dir = getDirContextByApplicationName(context, applicationName);
         log.debug("initializing dirxContext " + dir);
        if(dir==null) return null;
        try {
            result = LDAPUtil.getAttributeValue(dir, dn, attribute);
			log.debug("result " + result);
        } catch (GeneralException ge){
            log.error("Error getting AttributeValue: ", ge);
            return null;
        }
        return result;
    }

    /**
     * Moves an existing LDAP Entry in a new structure or renames it.
     * @param context Sailpoint Context provided from IIQ
     * @param applicationName Name of the LDAP application for connection parameters
     * @param oldDN Old DN of the Entry to rename / move
     * @param newDN New DN of the Entry to rename / move
     */
    public static void LDAPMove(SailPointContext context,String applicationName, String oldDN, String newDN) throws NamingException{
        Log log = org.apache.commons.logging.LogFactory.getLog("com.philips.util.PHLDAPUtil");
        DirContext dir = getDirContextByApplicationName(context, applicationName);
			log.debug("dir " + dir);
        if(dir==null) return;
		
		log.debug("oldDN " + oldDN);
		log.debug("newDN " + newDN);
		dir.rename(oldDN,newDN);

    }
	
    /**
     * Return a NamingEnumeration with the results of the ldap search
     * @param context Sailpoint context
     * @param applicationName name of the application in iiq
     * @param returningAttributes String array contains all attributes that will be returned in the searchresults
     * @param searchFilter Filter that is applied on the search
     * @param searchDN BaseDN for ldap search
     * @return NamingEnumeration with Searchresults of the ldap search or null on error
     */
    public static NamingEnumeration getAttributeValues(SailPointContext context, String applicationName, String [] returningAttributes, String searchFilter, String searchDN){
 
        return getAttributeValues(context, applicationName, returningAttributes, searchFilter, searchDN, SearchControls.SUBTREE_SCOPE);
 
    }
 
    /**
     * Return a NamingEnumeration with the results of the ldap search
     * @param context Sailpoint context
     * @param applicationName name of the application in iiq
     * @param returningAttributes String array contains all attributes that will be returned in the searchresults
     * @param searchFilter Filter that is applied on the search
     * @param searchDN BaseDN for ldap search
     * @param searchScope SearchScope of the search. Enum from SearchControls.
     * @return NamingEnumeration with Searchresults of the ldap search or null on error
     * @throws NamingException
     * @throws GeneralException
     */
    public static NamingEnumeration getAttributeValues(SailPointContext context, String applicationName, String [] returningAttributes, String searchFilter, String searchDN, int searchScope){
        NamingEnumeration result = null;
        Log log = org.apache.commons.logging.LogFactory.getLog("com.philips.util.PHLDAPUtil");
        DirContext dir = getDirContextByApplicationName(context, applicationName);
        if(dir==null) return null;
        String rootcontext = searchDN;
        SearchControls ctrl = new SearchControls();
        ctrl.setSearchScope(searchScope);
        ctrl.setReturningAttributes(returningAttributes);
 
        // Suchstring erstellen
        try {
            result = dir.search(rootcontext, searchFilter, ctrl);
        } catch (NamingException ne) {
            log.error("Error LDAP search: ", ne);
        }
        return result;
    }
 
    public static ArrayList<HashMap> getAttributeValuesList(SailPointContext context, String applicationName, String [] returningAttributes, String searchFilter, String searchDN, int searchScope)
    {
        ArrayList<HashMap> resultlist = null;
        Log log = org.apache.commons.logging.LogFactory.getLog("com.philips.util.PHLDAPUtil");
        try {
            NamingEnumeration ne = getAttributeValues(context, applicationName, returningAttributes, searchFilter, searchDN, searchScope);
            if(ne==null) return null;
            javax.naming.directory.SearchResult sr;
            javax.naming.directory.Attributes attrs;
            javax.naming.NamingEnumeration ids;
            resultlist = new ArrayList<>();
            HashMap hashMapResult;
            String name;
 
            while (ne.hasMore()) {
                hashMapResult = new HashMap();
                sr = (javax.naming.directory.SearchResult) ne.next();
                attrs = sr.getAttributes();
                ids = attrs.getIDs();
                while (ids.hasMore()) {
                    name = (String) ids.next();
                    hashMapResult.put(name, attrs.get(name).get().toString());
                }
                resultlist.add(hashMapResult);
            }
 
        } catch (NamingException ne) {
            log.error("Naming exception on result set: ", ne);
        }
 
        return resultlist;
 
    }

}
