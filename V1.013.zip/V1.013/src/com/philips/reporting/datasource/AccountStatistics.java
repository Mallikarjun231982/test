package com.philips.reporting.datasource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import sailpoint.api.IdentityService;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.LiveReport;
import sailpoint.object.QueryOptions;
import sailpoint.object.Sort;
import sailpoint.reporting.datasource.JavaDataSource;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class AccountStatistics implements JavaDataSource {
	
	private Log log = LogFactory.getLog(AccountStatistics.class);
	private List <Map<String,Object>> reportData = new ArrayList();
	private int recordcount = -1;
	private boolean hasmore = true;
	private final String PERSONALACCOUNT="4"; 
	private final String FUNCTIONALACCOUNT="2";
	private final String FUNCTIONALACTIVEKEY = "FUNCTIONALACTIVEKEY";
	private final String FUNCTIONALINACTIVEKEY = "FUNCTIONALINACTIVEKEY";
	private final String PERSONALACTIVEKEY = "PERSONALACTIVEKEY";
	private final String PERSONALINACTIVEKEY = "PERSONALINACTIVEKEY";
	private final String UNKNOWNACTIVEKEY = "UNKNOWNACTIVEKEY";
	private final String UNKNOWNINACTIVEKEY = "UNKNOWNINACTIVEKEY";
	private final String ACTIVECOUNT = "activeCount";
	private final String INACTIVECOUNT = "inactiveCount";
	private final String COMPANYNAME = "companyName";
	private final String COMPANYCODE = "companyCode";
	private final String ACCOUNTTYPE = "accountType";


	@Override
	public String getBaseHql() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions() {
		// TODO Auto-generated method stub
		return new QueryOptions();
	}


	@Override
	public int getSizeEstimate() throws GeneralException {
		
		buildReportDate();
		
		int size = -1;
		size = reportData.size();
		if (log.isDebugEnabled()) {
			log.debug("Enter getSizeEstimate returning " + size);

		}
		return size;
	}

	private void buildReportDate() throws GeneralException {
		
		boolean contextCreated = false;
		
		SailPointContext context = SailPointFactory.getCurrentContext();
		
		if(null == context){
			context = SailPointFactory.createContext();
			contextCreated=true;
		}
		
		Iterator identityIt = context.search(Identity.class, getBaseQueryOptions(), "id");
		
		int counter = 0;
		
		int systemActive=0;
		int systemInactive=0;
		
		int totalHTPerActive=0;
		int totalHTPerInactive=0;
		int totalLTPerActive=0;
		int totalLTPerInactive=0;
		
		int totalHTFunActive=0;
		int totalHTFunInactive=0;
		int totalLTFunActive=0;
		int totalLTFunInactive=0;
		
		int totalHTUnkActive=0;
		int totalHTUnkInactive=0;
		int totalLTUnkActive=0;
		int totalLTUnkInactive=0;
		
		
		Application app = context.getObjectByName(Application.class, "CODE1");
		
		Map<String,Map<String,Integer>> reportDataMap = new HashMap();
		
		while(identityIt.hasNext()){
			String id = (String)((Object[])identityIt.next())[0];
			
			if(log.isDebugEnabled()) log.debug("Starting id : " +id);
			
			Identity identity = context.getObjectById(Identity.class, id);
			
			
			String sectorCode = (String) identity.getAttribute("pdsSectorCode");
			
			int personalActive=0;
			int personalInactive=0;
			int functionalActive=0;
			int functionalInactive=0;
			int unknownActive=0;
			int unknownInactive=0;
			
			IdentityService ids = new IdentityService(context);
			
			List<Link> links = ids.getLinks(identity, app);
			
			for(Link link : links){
				String empType = (String) link.getAttribute("employeeType");
				boolean disabled = link.isDisabled();
				
				if(log.isDebugEnabled()) log.debug("Got Account Identity : " +identity.getName() +" sectorCode : " +sectorCode +" Link : " +link.getNativeIdentity() +" Type : " +empType +" Disabled : " +disabled);
				
				if(identity.isCorrelated()){
					if(disabled){
						if(PERSONALACCOUNT.equals(empType) ){
							personalInactive++;
							if("0100".equals(sectorCode)){
								totalLTPerInactive++;
							}else{
								totalHTPerInactive++;
							}
						}else if(FUNCTIONALACCOUNT.equals(empType)){
							functionalInactive++;
							if("0100".equals(sectorCode)){
								totalLTFunInactive++;
							}else{
								totalHTFunInactive++;
							}
						}else if(null == empType){
							 unknownInactive++;
							 if("0100".equals(sectorCode)){
								 totalLTUnkInactive++;
							 }else{
								 totalHTUnkInactive++;
							 }
						 }
						
					}else{
						if(PERSONALACCOUNT.equals(empType)){
							personalActive++;
							if("0100".equals(sectorCode)){
								totalLTPerActive++;
							}else{
								totalHTPerActive++;
							}
						}
						else if(FUNCTIONALACCOUNT.equals(empType)){
							functionalActive++;
							if("0100".equals(sectorCode)){
								totalLTFunActive++;
							}else{
								totalHTFunActive++;
							}
						}else if(null == empType){
							 unknownActive++;
							 if("0100".equals(sectorCode)){
								 totalLTUnkActive++;
							 }else{
								 totalHTUnkActive++;
							 }
						 }
						
					}
				} else {
					if(disabled){
						systemInactive++;
					}else {
						systemActive++;
					}
				}
			}
			
			if(identity.isCorrelated()){
				if(reportDataMap.containsKey(sectorCode)){
					Map<String, Integer> sectorDate = reportDataMap.get(sectorCode);
					if(sectorDate.containsKey(FUNCTIONALACTIVEKEY)){
						int number = sectorDate.get(FUNCTIONALACTIVEKEY);
						number = number + functionalActive;
						sectorDate.put(FUNCTIONALACTIVEKEY, number);
					} else {
						sectorDate.put(FUNCTIONALACTIVEKEY, functionalActive);
					}
					if(sectorDate.containsKey(FUNCTIONALINACTIVEKEY)){
						int number = sectorDate.get(FUNCTIONALINACTIVEKEY);
						number = number + functionalInactive;
						sectorDate.put(FUNCTIONALINACTIVEKEY, number);
					} else {
						sectorDate.put(FUNCTIONALINACTIVEKEY, functionalInactive);
					}
					if(sectorDate.containsKey(PERSONALACTIVEKEY)){
						int number = sectorDate.get(PERSONALACTIVEKEY);
						number = number + personalActive;
						sectorDate.put(PERSONALACTIVEKEY, number);
					} else {
						sectorDate.put(PERSONALACTIVEKEY, personalActive);
					}
					if(sectorDate.containsKey(PERSONALINACTIVEKEY)){
						int number = sectorDate.get(PERSONALINACTIVEKEY);
						number = number + personalInactive;
						sectorDate.put(PERSONALINACTIVEKEY, number);
					} else {
						sectorDate.put(PERSONALINACTIVEKEY, personalInactive);
					}
				} else {
					Map<String, Integer> sectorDate = new HashMap();
					sectorDate.put(FUNCTIONALACTIVEKEY, functionalActive);
					sectorDate.put(FUNCTIONALINACTIVEKEY, functionalInactive);
					sectorDate.put(PERSONALACTIVEKEY, personalActive);
					sectorDate.put(PERSONALINACTIVEKEY, personalInactive);
					reportDataMap.put(sectorCode, sectorDate);
				}
				
			}
			
			if(log.isDebugEnabled()) log.debug("ReportDataMap size : " +reportDataMap.size());
			
			if(counter % 100 == 0){
				context.decache();
			}
			
			counter++;
		}
		
		Map totalMap = new HashMap();
		totalMap.put(ACTIVECOUNT, totalHTPerActive + totalHTFunActive +totalHTUnkActive);
		totalMap.put(INACTIVECOUNT, totalHTPerInactive +totalHTFunInactive +totalHTUnkInactive);
		totalMap.put(COMPANYNAME, "Total HT");
		totalMap.put(COMPANYCODE, "Total HT");
		totalMap.put(ACCOUNTTYPE, "N/A");
		
		reportData.add(totalMap);
		
		totalMap = new HashMap();
		totalMap.put(ACTIVECOUNT, totalLTPerActive +totalLTFunActive +totalLTUnkActive);
		totalMap.put(INACTIVECOUNT, totalLTPerInactive +totalLTFunInactive +totalLTUnkInactive);
		totalMap.put(COMPANYNAME, "Total LS");
		totalMap.put(COMPANYCODE, "Total LS");
		totalMap.put(ACCOUNTTYPE, "N/A");
		
		reportData.add(totalMap);
		
		totalMap = new HashMap();
		totalMap.put(ACTIVECOUNT, totalHTPerActive);
		totalMap.put(INACTIVECOUNT, totalHTPerInactive);
		totalMap.put(COMPANYNAME, "Total HT Personal");
		totalMap.put(COMPANYCODE, "Total HT Personal");
		totalMap.put(ACCOUNTTYPE, "Personal");
		
		reportData.add(totalMap);
		
		totalMap = new HashMap();
		totalMap.put(ACTIVECOUNT, totalHTFunActive);
		totalMap.put(INACTIVECOUNT, totalHTFunInactive);
		totalMap.put(COMPANYNAME, "Total HT Functional");
		totalMap.put(COMPANYCODE, "Total HT Functional");
		totalMap.put(ACCOUNTTYPE, "Functional");

		reportData.add(totalMap);
		
		if(totalHTUnkActive != 0 || totalHTUnkInactive != 0){
			totalMap = new HashMap();
			totalMap.put(ACTIVECOUNT, totalHTUnkActive);
			totalMap.put(INACTIVECOUNT, totalHTUnkInactive);
			totalMap.put(COMPANYNAME, "Total HT Unknown");
			totalMap.put(COMPANYCODE, "Total HT Unknown");
			totalMap.put(ACCOUNTTYPE, "Unknown");

			reportData.add(totalMap);
		}
		
		totalMap = new HashMap();
		totalMap.put(ACTIVECOUNT, totalLTPerActive);
		totalMap.put(INACTIVECOUNT, totalLTPerInactive);
		totalMap.put(COMPANYNAME, "Total LS Personal");
		totalMap.put(COMPANYCODE, "Total LS Personal");
		totalMap.put(ACCOUNTTYPE, "Personal");

		reportData.add(totalMap);
		
		totalMap = new HashMap();
		totalMap.put(ACTIVECOUNT, totalLTFunActive);
		totalMap.put(INACTIVECOUNT, totalLTFunInactive);
		totalMap.put(COMPANYNAME, "Total LS Functional");
		totalMap.put(COMPANYCODE, "Total LS Functional");
		totalMap.put(ACCOUNTTYPE, "Functional");

		reportData.add(totalMap);
		
		if(totalLTFunActive != 0 || totalLTFunInactive != 0){
			totalMap = new HashMap();
			totalMap.put(ACTIVECOUNT, totalLTUnkActive);
			totalMap.put(INACTIVECOUNT, totalLTUnkInactive);
			totalMap.put(COMPANYNAME, "Total LS Unknown");
			totalMap.put(COMPANYCODE, "Total LS Unknown");
			totalMap.put(ACCOUNTTYPE, "Unknown");

			reportData.add(totalMap);
		}
		
		totalMap = new HashMap();
		totalMap.put(ACTIVECOUNT, systemActive);
		totalMap.put(INACTIVECOUNT, systemInactive);
		totalMap.put(COMPANYNAME, "System");
		totalMap.put(COMPANYCODE, "System");
		totalMap.put(ACCOUNTTYPE, "N/A");
		
		reportData.add(totalMap);
		
		for (String entry : reportDataMap.keySet()){
			Map<String, Integer> detailsMap = reportDataMap.get(entry);
			
			totalMap = new HashMap();
			totalMap.put(COMPANYCODE, entry);
			
			if("0100".equals(entry)){
				totalMap.put(COMPANYNAME, "LS");
			}else{
				totalMap.put(COMPANYNAME, "HT");
			}
			
			totalMap.put(ACCOUNTTYPE, "Personal");
			totalMap.put(ACTIVECOUNT, detailsMap.get(PERSONALACTIVEKEY));
			totalMap.put(INACTIVECOUNT, detailsMap.get(PERSONALINACTIVEKEY));

			reportData.add(totalMap);
			
			totalMap = new HashMap();
			totalMap.put(COMPANYCODE, entry);
			
			if("0100".equals(entry)){
				totalMap.put(COMPANYNAME, "LS");
			}else{
				totalMap.put(COMPANYNAME, "HT");
			}
			
			totalMap.put(ACCOUNTTYPE, "Functional");
			totalMap.put(ACTIVECOUNT, detailsMap.get(FUNCTIONALACTIVEKEY));
			totalMap.put(INACTIVECOUNT, detailsMap.get(FUNCTIONALINACTIVEKEY));
			
			reportData.add(totalMap);
			
			if((null != detailsMap.get(UNKNOWNACTIVEKEY) && detailsMap.get(UNKNOWNACTIVEKEY) != 0) || (null != detailsMap.get(UNKNOWNINACTIVEKEY) && detailsMap.get(UNKNOWNINACTIVEKEY) != 0)){
				totalMap = new HashMap();
				totalMap.put(COMPANYCODE, entry);

				if("0100".equals(entry)){
					totalMap.put(COMPANYNAME, "LS");
				}else{
					totalMap.put(COMPANYNAME, "HT");
				}

				totalMap.put(ACCOUNTTYPE, "Unknown");
				totalMap.put(ACTIVECOUNT, detailsMap.get(UNKNOWNACTIVEKEY));
				totalMap.put(INACTIVECOUNT, detailsMap.get(UNKNOWNINACTIVEKEY));

				reportData.add(totalMap);
			}
		}

		if(log.isDebugEnabled()) log.debug(reportData);
		
		if(contextCreated){
			SailPointFactory.releaseContext(context);
		}
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setMonitor(Monitor arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void initialize(SailPointContext context, LiveReport lr, Attributes<String, Object> atrbts, String string, List<Sort> list)
			throws GeneralException {
		
		if(log.isDebugEnabled())log.debug("Called initialize ");

		
	}

	@Override
	public void setLimit(int arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getFieldValue(String key) throws GeneralException {
		
		String returnvalue = null;

		if (log.isDebugEnabled()) {
			log.debug("Enter getFieldValue for record " + recordcount + " and field " + key);
		}
		Map<String, Object> companyData = reportData.get(recordcount);

		returnvalue = "" +companyData.get(key);


		if (log.isDebugEnabled()) {
			log.debug("..Returning " + returnvalue);
		}
		
		return returnvalue;
	}

	@Override
	public Object getFieldValue(JRField arg0) throws JRException {
		log.debug("Called getFieldValue with JRField " +arg0);
		return null;
	}

	@Override
	public boolean next() throws JRException {
		

		recordcount++;


		if (log.isDebugEnabled()) {
			log.debug("Enter next recordcount is " + recordcount);
		}

		if (recordcount < reportData.size()) {
			if (log.isDebugEnabled()) {
				log.debug("Returning true");
			}
			return hasmore;
		} else {
			hasmore = false;
		}
		if (log.isDebugEnabled()) {
			log.debug("Returning false");
		}

		return hasmore;
	}

}
