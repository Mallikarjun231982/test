package com.philips.reporting.datasource;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import sailpoint.api.IdentityService;
import sailpoint.api.ObjectUtil;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Filter.MatchMode;
import sailpoint.object.Identity;
import sailpoint.object.Identity.CapabilityManager;
import sailpoint.object.IdentityRequest;
import sailpoint.object.IdentityRequestItem;
import sailpoint.object.IdentitySnapshot;
import sailpoint.object.Link;
import sailpoint.object.LinkSnapshot;
import sailpoint.object.LiveReport;
import sailpoint.object.QueryOptions;
import sailpoint.object.ReportColumnConfig;
import sailpoint.object.Sort;
import sailpoint.object.ApprovalItem.ProvisioningState;
import sailpoint.reporting.datasource.JavaDataSource;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;
import sailpoint.web.identity.WorkgroupHelper;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class CapabilityPerOU implements JavaDataSource {
	
	private Log log = LogFactory.getLog(CapabilityPerOU.class);
	 private List <Map<String,Object>> reportData = new ArrayList();
	 private int recordcount = -1;
	 private boolean hasmore = true;
	 private List<String> ous = null;
	 
	 private final List<String> queryParameters= new ArrayList();

	@Override
	public String getBaseHql() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions()  {
		
		return null;
	}


	@Override
	public int getSizeEstimate() throws GeneralException {
		

		buildReportDate();

		
		int size = -1;
		size = reportData.size();
		if (log.isDebugEnabled()) {
			log.debug("Enter getSizeEstimate returning " + size);

		}
		return size;
	}

	private void buildReportDate() throws GeneralException {

		boolean contextCreated = false;

		SailPointContext context = SailPointFactory.getCurrentContext();

		if(null == context){
			context = SailPointFactory.createContext();
			contextCreated=true;
		}

		if(this.ous == null){
			this.ous = buildOuList(context);
		}
			
		if(log.isDebugEnabled())log.debug("ous : " +ous);
		
		for(String ou : ous){
			if(log.isDebugEnabled())log.debug("Dealing with ou : " +ou);
			
			
			//Get IdentityManagers
			
			//Get HelpDesk
			
			List<String> helpDeskUsers = getHelpDeskUsers(context, ou);

			//Get RAManagers
			
			List<String> raManagerUsers = getRAManagerUsers(context, ou);
			
			if(raManagerUsers.size() == 0 && helpDeskUsers.size() == 0){
				Map reportRow = new HashMap();
				reportRow.put("ou", ou);
				reportData.add(reportRow);
			} else if(raManagerUsers.size() > helpDeskUsers.size()){
				for(int i = 0; i< raManagerUsers.size(); i++){
					Map reportRow = new HashMap();
					reportRow.put("ou", ou);
					reportRow.put("raManager", raManagerUsers.get(i));
					if(helpDeskUsers.size()>i){
						reportRow.put("helpDesk", helpDeskUsers.get(i));
					}
					reportData.add(reportRow);
				}
			} else {
				for(int i = 0; i< helpDeskUsers.size(); i++){
					Map reportRow = new HashMap();
					reportRow.put("ou", ou);
					reportRow.put("helpDesk", helpDeskUsers.get(i));
					if(raManagerUsers.size()>i){
						reportRow.put("raManager", raManagerUsers.get(i));
					}
					reportData.add(reportRow);
				}
			}
			
		}

		if(contextCreated){
			SailPointFactory.releaseContext(context);
		}
	}
	


	private List<String> getRAManagerUsers(SailPointContext context, String ou) throws GeneralException {
		
		if(log.isDebugEnabled())log.debug("getRAManagerUsers with ou : " +ou);
		
		List returnList = new ArrayList();
		
		String ramanagerName = "wg-" +ou +"-RAManager";
		
		Identity workgroup = context.getObjectByName(Identity.class, ramanagerName);
		
		List props = new ArrayList();
		props.add("name");
		props.add("upn");
		
		if(log.isDebugEnabled())log.debug("workgroup : " +workgroup);
		
		if(null != workgroup){
			Iterator<Object[]> membersit = ObjectUtil.getWorkgroupMembers(context, workgroup, props);
			
			while(membersit.hasNext()){
				Object[] member = membersit.next();
				if(log.isDebugEnabled())log.debug("Members : " +member[0]);
				returnList.add(member[0] +" (" +member[1] +")");
			}
			
			context.decache(workgroup);
		}
		
		//Get the Global HelpDesk members
		
		Custom cmdb = context.getObjectByName(Custom.class, "PhilipsCMDB");
		
		if(null != cmdb){
			List hdExclusions = Util.csvToList((String) cmdb.get("GLOBALRAMANAGEREXCLUSIONS"),true);
			
			if(!hdExclusions.contains(ou)){
				
				QueryOptions qo = new QueryOptions();
				qo.addFilter(Filter.eq("workgroup", false));
				qo.addFilter(Filter.eq("capabilities.name", "GlobalRAManager"));

				Iterator<Object[]> membersit = context.search(Identity.class, qo, props);
				
				while(membersit.hasNext()){
					Object[] member = membersit.next();
					if(log.isDebugEnabled())log.debug("GlobalHelpDesk Members : " +member[0]);
					returnList.add(member[0] +" (" +member[1] +") (GlobalRAManager)");
				}
			}
		}
		
		return returnList;

	}

	private List getHelpDeskUsers(SailPointContext context, String ou) throws GeneralException {
		
		if(log.isDebugEnabled())log.debug("getHelpDeskUsers with ou : " +ou);
		
		List returnList = new ArrayList();
		
		String workgroupName = "wg-" +ou +"-HelpDesk";
		
		Identity workgroup = context.getObjectByName(Identity.class, workgroupName);
		
		List props = new ArrayList();
		props.add("name");
		props.add("upn");
		
		if(log.isDebugEnabled())log.debug("workgroup : " +workgroup);
		
		if(null != workgroup){
			Iterator<Object[]> membersit = ObjectUtil.getWorkgroupMembers(context, workgroup, props);
			
			while(membersit.hasNext()){
				Object[] member = membersit.next();
				if(log.isDebugEnabled())log.debug("Members : " +member[0]);
				returnList.add(member[0] +" (" +member[1] +")");
			}
			
			context.decache(workgroup);
		}
		
		//Get the Global HelpDesk members
		
		Custom cmdb = context.getObjectByName(Custom.class, "PhilipsCMDB");
		
		if(null != cmdb){
			List hdExclusions = Util.csvToList((String) cmdb.get("GLOBALHELPDESKEXCLUSIONS"),true);
			
			if(!hdExclusions.contains(ou)){
				
				QueryOptions qo = new QueryOptions();
				qo.addFilter(Filter.eq("workgroup", false));
				qo.addFilter(Filter.eq("capabilities.name", "GlobalHelpDesk"));

				Iterator<Object[]> membersit = context.search(Identity.class, qo, props);
				
				while(membersit.hasNext()){
					Object[] member = membersit.next();
					if(log.isDebugEnabled())log.debug("GlobalHelpDesk Members : " +member[0]);
					returnList.add(member[0] +" (" +member[1] +") (GlobalHelpDesk)");
				}
			}
		}
		
		return returnList;
	}

	private List buildOuList(SailPointContext context) throws GeneralException {
		List returnList = new ArrayList();
		
		QueryOptions qo = new QueryOptions();
		qo.addFilter(Filter.eq("workgroup", true));
		qo.addFilter(Filter.like("name", "wg-", MatchMode.START));
		qo.addFilter(Filter.like("name", "RAManager", MatchMode.END));
		
		Iterator identityit = context.search(Identity.class, qo, "name");
		
		while(identityit.hasNext()){
			String workgroupName = (String) ((Object[]) identityit.next())[0];
			returnList.add(workgroupName.substring(workgroupName.indexOf("-")+1, workgroupName.lastIndexOf("-")));

		}
		
		return returnList;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setMonitor(Monitor arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void initialize(SailPointContext context, LiveReport lr, Attributes<String, Object> atrbts, String string, List<Sort> list)
			throws GeneralException {
		
		if(log.isDebugEnabled())log.debug("Called initialize ");
	
		
		List<ReportColumnConfig> columns = lr.getGridColumns();
		
		for(ReportColumnConfig column : columns){
			queryParameters.add(column.getField());
		}
		
		if(atrbts.containsKey("ous")){
			this.ous = (List) atrbts.get("ous");
		}
		
		if(log.isDebugEnabled())log.debug("Setting queryParameters " +queryParameters);
		
	}

	@Override
	public void setLimit(int arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getFieldValue(String key) throws GeneralException {

		String returnvalue = null;

		if (log.isDebugEnabled()) {
			log.debug("Enter getFieldValue for record " + recordcount + " and field " + key);
		}
		Map<String, Object> identityData = reportData.get(recordcount);

		returnvalue = "" +identityData.get(key);


		if (log.isDebugEnabled()) {
			log.debug("..Returning " + returnvalue);
		}

		return returnvalue;
	}
	
	@Override
	public Object getFieldValue(JRField arg0) throws JRException {
		log.debug("Called getFieldValue with JRField " +arg0);
		return null;
	}

	@Override
	public boolean next() throws JRException {

		recordcount++;


		if (log.isDebugEnabled()) {
			log.debug("Enter next recordcount is " + recordcount);
		}

		if (recordcount < reportData.size()) {
			if (log.isDebugEnabled()) {
				log.debug("Returning true");
			}
			return hasmore;
		} else {
			hasmore = false;
		}
		if (log.isDebugEnabled()) {
			log.debug("Returning false");
		}

		return hasmore;
	}

}
