package com.philips.reporting.datasource;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import sailpoint.api.IdentityService;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.IdentityRequest;
import sailpoint.object.IdentityRequestItem;
import sailpoint.object.IdentitySnapshot;
import sailpoint.object.Link;
import sailpoint.object.LinkSnapshot;
import sailpoint.object.LiveReport;
import sailpoint.object.QueryOptions;
import sailpoint.object.ReportColumnConfig;
import sailpoint.object.Sort;
import sailpoint.object.ApprovalItem.ProvisioningState;
import sailpoint.reporting.datasource.JavaDataSource;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class UsersOnLegalHold implements JavaDataSource {
	
	private Log log = LogFactory.getLog(UsersOnLegalHold.class);
	 private List <Map<String,Object>> reportData = new ArrayList();
	 private int recordcount = -1;
	 private boolean hasmore = true;
	 
	 private final List<String> queryParameters= new ArrayList();

	@Override
	public String getBaseHql() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions()  {
		
		return null;
	}


	@Override
	public int getSizeEstimate() throws GeneralException {
		
		buildReportDate();
		
		int size = -1;
		size = reportData.size();
		if (log.isDebugEnabled()) {
			log.debug("Enter getSizeEstimate returning " + size);

		}
		return size;
	}

	private void buildReportDate() throws GeneralException {
		int counter =0;
		
		TreeSet<String> htUsers = new TreeSet();
		TreeSet<String> lsUsers = new TreeSet();
		TreeSet<String> unknownUsers = new TreeSet();
		
		Map<String, Map> identityDetails = new HashMap();

		boolean contextCreated = false;

		SailPointContext context = SailPointFactory.getCurrentContext();

		if(null == context){
			context = SailPointFactory.createContext();
			contextCreated=true;
		}

		Iterator<Object[]> identityIt = context.search(Identity.class, getBaseQueryOptions(), "id");


		while(identityIt.hasNext()){
			String id = (String)((Object[])identityIt.next())[0];

			if(log.isDebugEnabled()) log.debug("Starting id : " +id);


			Identity identity = context.getObject(Identity.class, id);	

			if(null != identity){

				String legalHold = (String) context.decrypt((String) identity.getAttribute("legalHold"));

				if(log.isDebugEnabled()) log.debug("legalHold is : " +legalHold);

				if(null != legalHold && "true".equals(legalHold.toLowerCase())){
					String sectorCode = (String) identity.getAttribute("pdsSectorCode");
					
					if(log.isDebugEnabled()) log.debug("sectorCode is : " +sectorCode);

					if(null != sectorCode){
						if("0100".equals(sectorCode)){
							lsUsers.add(identity.getLastname() +":" +identity.getId());
							addIdentityDetails(identity, identityDetails, "LS");
						} else {
							htUsers.add(identity.getLastname() +":" +identity.getId());
							addIdentityDetails(identity, identityDetails, "HT");
						}
					} else {
						unknownUsers.add(identity.getLastname() +":" +identity.getId());
						addIdentityDetails(identity, identityDetails, "UNKNOWN");
					}
					
				}

			}

			if(counter % 100 == 0){
				context.decache();
			}
			counter++;
		}
		
		//Consolidate Data
		
		for(String user : lsUsers){
			String[] userDetails = user.split(":");
			if(log.isDebugEnabled()) log.debug("Getting details for : " +userDetails[1]);
			reportData.add(identityDetails.get(userDetails[1]));
		}
		
		for(String user : htUsers){
			String[] userDetails = user.split(":");
			if(log.isDebugEnabled()) log.debug("Getting details for : " +userDetails[1]);
			reportData.add(identityDetails.get(userDetails[1]));
		}
		
		for(String user : unknownUsers){
			String[] userDetails = user.split(":");
			if(log.isDebugEnabled()) log.debug("Getting details for : " +userDetails[1]);
			reportData.add(identityDetails.get(userDetails[1]));
		}


		if(log.isDebugEnabled()) log.debug(reportData);

		if(contextCreated){
			SailPointFactory.releaseContext(context);
		}
	}
	
	private void addIdentityDetails(Identity identity, Map<String, Map> identityDetails, String company) {
		
		Map<String, String> detsils = new HashMap<String, String>();
		
		for(int i=0; i < queryParameters.size(); i++){
			String parameter = queryParameters.get(i);
			
			if("lastName".equals(parameter)){
				detsils.put("lastName", identity.getLastname());
			} else if("firstName".equals(parameter)){
				detsils.put("firstName", identity.getFirstname());
			} else if("name".equals(parameter)){
				detsils.put("name", identity.getName());
			}else if("manager".equals(parameter)){
				Identity managerIdentity = identity.getManager();
				
				String manager = "";
				
				if(null != managerIdentity){
					manager = managerIdentity.getDisplayableName();
				}
				
				detsils.put("manager", manager);
			} else if("company".equals(parameter)){
				detsils.put("company", company);
			} else{
				detsils.put(parameter, (String) identity.getAttribute(parameter));
			}
		}
		
		if(log.isDebugEnabled())log.debug("Adding to identityDetails : " +identity.getId() +" " +detsils);
		
		identityDetails.put(identity.getId(), detsils);
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setMonitor(Monitor arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void initialize(SailPointContext context, LiveReport lr, Attributes<String, Object> atrbts, String string, List<Sort> list)
			throws GeneralException {
		
		if(log.isDebugEnabled())log.debug("Called initialize ");
	
		
		List<ReportColumnConfig> columns = lr.getGridColumns();
		
		for(ReportColumnConfig column : columns){
			queryParameters.add(column.getField());
		}
		
		if(log.isDebugEnabled())log.debug("Setting queryParameters " +queryParameters);
		
	}

	@Override
	public void setLimit(int arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getFieldValue(String key) throws GeneralException {

		String returnvalue = null;

		if (log.isDebugEnabled()) {
			log.debug("Enter getFieldValue for record " + recordcount + " and field " + key);
		}
		Map<String, Object> identityData = reportData.get(recordcount);

		returnvalue = "" +identityData.get(key);


		if (log.isDebugEnabled()) {
			log.debug("..Returning " + returnvalue);
		}

		return returnvalue;
	}
	
	@Override
	public Object getFieldValue(JRField arg0) throws JRException {
		log.debug("Called getFieldValue with JRField " +arg0);
		return null;
	}

	@Override
	public boolean next() throws JRException {

		recordcount++;


		if (log.isDebugEnabled()) {
			log.debug("Enter next recordcount is " + recordcount);
		}

		if (recordcount < reportData.size()) {
			if (log.isDebugEnabled()) {
				log.debug("Returning true");
			}
			return hasmore;
		} else {
			hasmore = false;
		}
		if (log.isDebugEnabled()) {
			log.debug("Returning false");
		}

		return hasmore;
	}

}
