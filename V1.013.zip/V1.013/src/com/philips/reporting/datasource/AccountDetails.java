package com.philips.reporting.datasource;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import sailpoint.api.IdentityService;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.IdentityRequest;
import sailpoint.object.IdentityRequestItem;
import sailpoint.object.IdentitySnapshot;
import sailpoint.object.Link;
import sailpoint.object.LinkSnapshot;
import sailpoint.object.LiveReport;
import sailpoint.object.QueryOptions;
import sailpoint.object.Sort;
import sailpoint.object.ApprovalItem.ProvisioningState;
import sailpoint.reporting.datasource.JavaDataSource;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class AccountDetails implements JavaDataSource {
	
	private Log log = LogFactory.getLog(AccountDetails.class);
	 private List <Map<String,Object>> reportData = new ArrayList();
	 private int recordcount = -1;
	 private boolean hasmore = true;
	 private final String PERSONALACCOUNT="4"; 
	 private final String FUNCTIONALACCOUNT="2";
	 private final String FUNCTIONALCREATEKEY = "FUNCTIONALCREATEKEY";
	 private final String FUNCTIONALDELETEKEY = "FUNCTIONALDELETEKEY";
	 private final String PERSONALCREATEKEY = "PERSONALCREATEKEY";
	 private final String PERSONALDELETEKEY = "PERSONALDELETEKEY";
	 private final String UNKNOWNCREATEKEY = "UNKNOWNCREATEKEY";
	 private final String UNKNOWNDELETEKEY = "UNKNOWNDELETEKEY";
	 private final String CREATECOUNT = "createCount";
	 private final String DELETECOUNT = "deleteCount";
	 private final String COMPANYNAME = "companyName";
	 private final String COMPANYCODE = "companyCode";
	 private final String ACCOUNTTYPE = "accountType";

	@Override
	public String getBaseHql() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions()  {
		QueryOptions qo = new QueryOptions();
		
		qo.addFilter(Filter.or(Filter.eq("items.operation", "Create"), Filter.eq("items.operation", "Delete")));
		qo.addFilter(Filter.eq("items.application", "CODE1"));
		
		Calendar cal = Calendar.getInstance();
		
		
		//Hack the Date For Testing 
		/*
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		try {
			cal.setTime(format.parse("2016/04/07"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DATE, 1);
		cal.set(Calendar.HOUR,0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.SECOND,0);
		Date firstDateOfPreviousMonth = cal.getTime();

		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE)); 
		cal.set(Calendar.HOUR,23);
		cal.set(Calendar.MINUTE,59);
		cal.set(Calendar.SECOND,59);

		Date lastDateOfPreviousMonth = cal.getTime();
		
		qo.addFilter(Filter.ge("created", firstDateOfPreviousMonth));
		qo.addFilter(Filter.lt("created", lastDateOfPreviousMonth));
		
		log.debug("qo : " +qo.getFilters());
		return qo;
	}


	@Override
	public int getSizeEstimate() throws GeneralException {
		
		buildReportDate();
		
		int size = -1;
		size = reportData.size();
		if (log.isDebugEnabled()) {
			log.debug("Enter getSizeEstimate returning " + size);

		}
		return size;
	}

	private void buildReportDate() throws GeneralException {
		boolean contextCreated = false;

		 SailPointContext context = SailPointFactory.getCurrentContext();

		 if(null == context){
			 context = SailPointFactory.createContext();
			 contextCreated=true;
		 }

		 Iterator identityReqIt = context.search(IdentityRequest.class, getBaseQueryOptions(), "id");

		 int counter = 0;

		 int systemCreated=0;
		 int systemDeleted=0;

		 int totalHTPerCreated=0;
		 int totalHTPerDeleted=0;
		 int totalLTPerCreated=0;
		 int totalLTPerDeleted=0;

		 int totalHTFunCreated=0;
		 int totalHTFunDeleted=0;
		 int totalLTFunCreated=0;
		 int totalLTFunDeleted=0;
		 
		 int totalHTUnkCreated=0;
		 int totalHTUnkDeleted=0;
		 int totalLTUnkCreated=0;
		 int totalLTUnkDeleted=0;

		 //Application app = context.getObjectByName(Application.class, "CODE1");

		 Map<String,Map<String,Integer>> reportDataMap = new HashMap();

		 while(identityReqIt.hasNext()){
			 String id = (String)((Object[])identityReqIt.next())[0];

			 if(log.isDebugEnabled()) log.debug("Starting id : " +id);

			 IdentityRequest identityRequest = context.getObjectById(IdentityRequest.class, id);

			 String identityId = identityRequest.getTargetId();

			 if(log.isDebugEnabled()) log.debug("Getting Identity id : " +identityId);

			 Identity identity = context.getObject(Identity.class, identityId);	

			 if(null != identity){

				 String sectorCode = (String) identity.getAttribute("pdsSectorCode");

				 int personalCreated=0;
				 int personalDeleted=0;
				 int functionalCreated=0;
				 int functionalDeleted=0;
				 int unknownCreated=0;
				 int unknownDeleted=0;

				 List<IdentityRequestItem> items =identityRequest.getItems();

				 Application application = context.getObject(Application.class, "CODE1");

				 IdentityService ids = new IdentityService(context);

				 for(IdentityRequestItem item : items){


					 if("CODE1".equals(item.getApplication()) && (!item.getProvisioningState().equals(ProvisioningState.Failed) || !item.getProvisioningState().equals(ProvisioningState.Retry)) && ("Create".equals(item.getOperation()) || "Delete".equals(item.getOperation()))){
						 
						 if(log.isDebugEnabled()) log.debug("Got valid Item : " +item.getId());

						 String operation = item.getOperation();

						 String nativeIdentity = item.getNativeIdentity();

						 String empType = null;

						 //Lets try and find the Account so that we can work out if it personal or functional
						 Link link = ids.getLink(identity, application, null, nativeIdentity);

						 if(null == link){
							 //OK it does not exist any more :-(
							 QueryOptions qo = new QueryOptions();

							 List list = new ArrayList();
							 list.add("CODE1");

							 qo.addFilter(Filter.eq("identityName", identity.getName()));
							 qo.addFilter(Filter.like("applications", "CODE1"));
							 qo.addOrdering("created", false);
							 qo.setResultLimit(1);

							 List<IdentitySnapshot> objects = context.getObjects(IdentitySnapshot.class, qo);

							 for(IdentitySnapshot snapshot : objects){
								 List<LinkSnapshot> snapshotLinks = snapshot.getLinks("CODE1");

								 for(LinkSnapshot linkSnapshot : snapshotLinks){
									 if(nativeIdentity.equals(linkSnapshot.getNativeIdentity())){
										 empType = (String) linkSnapshot.getAttributes().get("employeeType");
									 }
								 }
							 }
						 } else {
							 empType = (String) link.getAttribute("employeeType");
						 }

						 if(log.isDebugEnabled()) log.debug("Got IdentityRequest Item for : " +identity.getName() +" Operation : " +operation +" employeeType : " +empType);

						 if(identity.isCorrelated()){
							 if("Delete".equals(operation)){
								 if(PERSONALACCOUNT.equals(empType) ){
									 personalDeleted++;
									 if("0100".equals(sectorCode)){
										 totalLTPerDeleted++;
									 }else{
										 totalHTPerDeleted++;
									 }
								 } else if(FUNCTIONALACCOUNT.equals(empType)){
									 functionalDeleted++;
									 if("0100".equals(sectorCode)){
										 totalLTFunDeleted++;
									 }else{
										 totalHTFunDeleted++;
									 }
								 } else if(null == empType){
									 unknownDeleted++;
									 if("0100".equals(sectorCode)){
										 totalLTUnkDeleted++;
									 }else{
										 totalHTUnkDeleted++;
									 }
								 }

							 }else{
								 if(PERSONALACCOUNT.equals(empType)){
									 personalCreated++;
									 if("0100".equals(sectorCode)){
										 totalLTPerCreated++;
									 }else{
										 totalHTPerCreated++;
									 }
								 } else if(FUNCTIONALACCOUNT.equals(empType)){
									 functionalCreated++;
									 if("0100".equals(sectorCode)){
										 totalLTFunCreated++;
									 }else{
										 totalHTFunCreated++;
									 }
								 } else if(null == empType){
									 unknownCreated++;
									 if("0100".equals(sectorCode)){
										 totalLTUnkCreated++;
									 }else{
										 totalHTUnkCreated++;
									 }
								 }

							 }
						 } else {
							 if("Delete".equals(operation)){
								 systemDeleted++;
							 }else {
								 systemCreated++;
							 }
						 }
					 }
				 }

				 if(identity.isCorrelated()){
					 if(reportDataMap.containsKey(sectorCode)){
						 Map<String, Integer> sectorDate = reportDataMap.get(sectorCode);
						 if(sectorDate.containsKey(FUNCTIONALCREATEKEY)){
							 int number = sectorDate.get(FUNCTIONALCREATEKEY);
							 number = number + functionalCreated;
							 sectorDate.put(FUNCTIONALCREATEKEY, number);
						 } else {
							 sectorDate.put(FUNCTIONALCREATEKEY, functionalCreated);
						 }
						 if(sectorDate.containsKey(FUNCTIONALDELETEKEY)){
							 int number = sectorDate.get(FUNCTIONALDELETEKEY);
							 number = number + functionalDeleted;
							 sectorDate.put(FUNCTIONALDELETEKEY, number);
						 } else {
							 sectorDate.put(FUNCTIONALDELETEKEY, functionalDeleted);
						 }
						 if(sectorDate.containsKey(PERSONALCREATEKEY)){
							 int number = sectorDate.get(PERSONALCREATEKEY);
							 number = number + personalCreated;
							 sectorDate.put(PERSONALCREATEKEY, number);
						 } else {
							 sectorDate.put(PERSONALCREATEKEY, personalCreated);
						 }
						 if(sectorDate.containsKey(PERSONALDELETEKEY)){
							 int number = sectorDate.get(PERSONALDELETEKEY);
							 number = number + personalDeleted;
							 sectorDate.put(PERSONALDELETEKEY, number);
						 } else {
							 sectorDate.put(PERSONALDELETEKEY, personalDeleted);
						 }
						 if(sectorDate.containsKey(UNKNOWNCREATEKEY)){
							 int number = sectorDate.get(UNKNOWNCREATEKEY);
							 number = number + unknownCreated;
							 sectorDate.put(UNKNOWNCREATEKEY, number);
						 } else {
							 sectorDate.put(UNKNOWNCREATEKEY, unknownCreated);
						 }
						 if(sectorDate.containsKey(UNKNOWNDELETEKEY)){
							 int number = sectorDate.get(UNKNOWNDELETEKEY);
							 number = number + unknownDeleted;
							 sectorDate.put(UNKNOWNDELETEKEY, number);
						 } else {
							 sectorDate.put(UNKNOWNDELETEKEY, unknownDeleted);
						 }
					 } else {
						 Map<String, Integer> sectorDate = new HashMap();
						 sectorDate.put(FUNCTIONALCREATEKEY, functionalCreated);
						 sectorDate.put(FUNCTIONALDELETEKEY, functionalDeleted);
						 sectorDate.put(PERSONALCREATEKEY, personalCreated);
						 sectorDate.put(PERSONALDELETEKEY, personalDeleted);
						 sectorDate.put(UNKNOWNCREATEKEY, unknownCreated);
						 sectorDate.put(UNKNOWNDELETEKEY, unknownDeleted);
						 reportDataMap.put(sectorCode, sectorDate);
					 }

				 }
			 }


				if(log.isDebugEnabled()) log.debug("ReportDataMap size : " +reportDataMap.size());

				if(counter % 100 == 0){
					context.decache();
				}

				counter++;
			}

			Map totalMap = new HashMap();
			totalMap.put(CREATECOUNT, totalHTPerCreated + totalHTFunCreated +totalHTUnkCreated);
			totalMap.put(DELETECOUNT, totalHTPerDeleted +totalHTFunDeleted +totalHTUnkDeleted);
			totalMap.put(COMPANYNAME, "Total HT");
			totalMap.put(COMPANYCODE, "Total HT");
			totalMap.put(ACCOUNTTYPE, "N/A");

			reportData.add(totalMap);
			
			totalMap = new HashMap();
			totalMap.put(CREATECOUNT, totalLTPerCreated +totalLTFunCreated +totalLTUnkCreated);
			totalMap.put(DELETECOUNT, totalLTPerDeleted +totalLTFunDeleted +totalLTUnkDeleted);
			totalMap.put(COMPANYNAME, "Total LS");
			totalMap.put(COMPANYCODE, "Total LS");
			totalMap.put(ACCOUNTTYPE, "N/A");

			reportData.add(totalMap);
			
			totalMap = new HashMap();
			totalMap.put(CREATECOUNT, totalHTPerCreated);
			totalMap.put(DELETECOUNT, totalHTPerDeleted);
			totalMap.put(COMPANYNAME, "Total HT Personal");
			totalMap.put(COMPANYCODE, "Total HT Personal");
			totalMap.put(ACCOUNTTYPE, "Personal");

			reportData.add(totalMap);
			
			totalMap = new HashMap();
			totalMap.put(CREATECOUNT, totalHTFunCreated);
			totalMap.put(DELETECOUNT, totalHTFunDeleted);
			totalMap.put(COMPANYNAME, "Total HT Functional");
			totalMap.put(COMPANYCODE, "Total HT Functional");
			totalMap.put(ACCOUNTTYPE, "Functional");
			
			reportData.add(totalMap);
			
			if(totalHTUnkCreated != 0 || totalHTUnkDeleted != 0){
				totalMap = new HashMap();
				totalMap.put(CREATECOUNT, totalHTUnkCreated);
				totalMap.put(DELETECOUNT, totalHTUnkDeleted);
				totalMap.put(COMPANYNAME, "Total HT Unknown");
				totalMap.put(COMPANYCODE, "Total HT Unknown");
				totalMap.put(ACCOUNTTYPE, "Unknown");

				reportData.add(totalMap);
			}

			totalMap = new HashMap();
			totalMap.put(CREATECOUNT, totalLTPerCreated);
			totalMap.put(DELETECOUNT, totalLTPerDeleted);
			totalMap.put(COMPANYNAME, "Total LS Personal");
			totalMap.put(COMPANYCODE, "Total LS Personal");
			totalMap.put(ACCOUNTTYPE, "Personal");

			reportData.add(totalMap);
			
			totalMap = new HashMap();
			totalMap.put(CREATECOUNT, totalLTFunCreated);
			totalMap.put(DELETECOUNT, totalLTFunDeleted);
			totalMap.put(COMPANYNAME, "Total LS Functional");
			totalMap.put(COMPANYCODE, "Total LS Functional");
			totalMap.put(ACCOUNTTYPE, "Functional");
		
			reportData.add(totalMap);
			
			if(totalLTUnkCreated != 0 || totalLTUnkDeleted != 0){
				totalMap = new HashMap();
				totalMap.put(CREATECOUNT, totalLTUnkCreated);
				totalMap.put(DELETECOUNT, totalLTUnkDeleted);
				totalMap.put(COMPANYNAME, "Total HT Unknown");
				totalMap.put(COMPANYCODE, "Total HT Unknown");
				totalMap.put(ACCOUNTTYPE, "Unknown");

				reportData.add(totalMap);
			}
			
			
			
			totalMap = new HashMap();
			totalMap.put(CREATECOUNT, systemCreated);
			totalMap.put(DELETECOUNT, systemDeleted);
			totalMap.put(COMPANYNAME, "Total System");
			totalMap.put(COMPANYCODE, "Total System");
			totalMap.put(ACCOUNTTYPE, "N/A");

			
			reportData.add(totalMap);
			
			for (String entry : reportDataMap.keySet()){
				Map<String, Integer> detailsMap = reportDataMap.get(entry);
				
				totalMap = new HashMap();
				totalMap.put(COMPANYCODE, entry);
				
				if("0100".equals(entry)){
					totalMap.put(COMPANYNAME, "LS");
				}else{
					totalMap.put(COMPANYNAME, "HT");
				}
				
				totalMap.put(ACCOUNTTYPE, "Personal");
				totalMap.put(CREATECOUNT, detailsMap.get(PERSONALCREATEKEY));
				totalMap.put(DELETECOUNT, detailsMap.get(PERSONALDELETEKEY));

				reportData.add(totalMap);
				
				totalMap = new HashMap();
				totalMap.put(COMPANYCODE, entry);
				
				if("0100".equals(entry)){
					totalMap.put(COMPANYNAME, "LS");
				}else{
					totalMap.put(COMPANYNAME, "HT");
				}
				
				totalMap.put(ACCOUNTTYPE, "Functional");
				totalMap.put(CREATECOUNT, detailsMap.get(FUNCTIONALCREATEKEY));
				totalMap.put(DELETECOUNT, detailsMap.get(FUNCTIONALDELETEKEY));

				reportData.add(totalMap);
				
				if((null != detailsMap.get(UNKNOWNCREATEKEY) && detailsMap.get(UNKNOWNCREATEKEY) != 0) || (null != detailsMap.get(UNKNOWNDELETEKEY) && detailsMap.get(UNKNOWNDELETEKEY) != 0)){
					totalMap = new HashMap();
					totalMap.put(COMPANYCODE, entry);

					if("0100".equals(entry)){
						totalMap.put(COMPANYNAME, "LS");
					}else{
						totalMap.put(COMPANYNAME, "HT");
					}

					totalMap.put(ACCOUNTTYPE, "Unknown");
					totalMap.put(CREATECOUNT, detailsMap.get(UNKNOWNCREATEKEY));
					totalMap.put(DELETECOUNT, detailsMap.get(UNKNOWNDELETEKEY));

					reportData.add(totalMap);
				}
			}
			
			if(log.isDebugEnabled()) log.debug(reportData);
			
			if(contextCreated){
				SailPointFactory.releaseContext(context);
			}
			
	}
	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setMonitor(Monitor arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void initialize(SailPointContext context, LiveReport lr, Attributes<String, Object> atrbts, String string, List<Sort> list)
			throws GeneralException {
		
		if(log.isDebugEnabled())log.debug("Called initialize ");

		
	}

	@Override
	public void setLimit(int arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getFieldValue(String key) throws GeneralException {

		String returnvalue = null;

		if (log.isDebugEnabled()) {
			log.debug("Enter getFieldValue for record " + recordcount + " and field " + key);
		}
		Map<String, Object> companyData = reportData.get(recordcount);

		returnvalue = "" +companyData.get(key);


		if (log.isDebugEnabled()) {
			log.debug("..Returning " + returnvalue);
		}

		return returnvalue;
	}
	
	@Override
	public Object getFieldValue(JRField arg0) throws JRException {
		log.debug("Called getFieldValue with JRField " +arg0);
		return null;
	}

	@Override
	public boolean next() throws JRException {

		recordcount++;


		if (log.isDebugEnabled()) {
			log.debug("Enter next recordcount is " + recordcount);
		}

		if (recordcount < reportData.size()) {
			if (log.isDebugEnabled()) {
				log.debug("Returning true");
			}
			return hasmore;
		} else {
			hasmore = false;
		}
		if (log.isDebugEnabled()) {
			log.debug("Returning false");
		}

		return hasmore;
	}

}
