package com.philips.custom.validation;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.reporting.datasource.*;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class ValidatorIdentityCapabilities implements JavaDataSource{
	
	private QueryOptions baseQueryOptions;
	private Object[] currentRow;
	private Monitor monitor;
	private Object startRow;
	private Object pageSize;
	
	private LinkedHashMap results;
	private Iterator<Map.Entry<String, Integer>> it;
	private Entry<String, Integer> currentEntry;
	private SailPointContext context;

	@Override
	public String getBaseHql() {
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions() {
		return baseQueryOptions;
	}

	@Override
	public Object getFieldValue(String field) throws GeneralException {
		if ("key".equals(field)){
			return currentEntry.getKey();
		} else if ("value".equals(field)){
			return currentEntry.getValue();
		} else {
			throw new GeneralException("Unknown column '"+field+"'");
		}
	}

	@Override
	public int getSizeEstimate() throws GeneralException {
		return 20;
	}

	@Override
	public void close() {
	}

	@Override
	public void setMonitor(Monitor m) {
		monitor = m;
	}

	@Override
	public Object getFieldValue(JRField jrField) throws JRException {
		String name = jrField.getName();
		try {
			return getFieldValue(name);
		} catch (GeneralException e) {
			throw new JRException(e);
		}
	}

	@Override
	public boolean next() throws JRException {
		if (it.hasNext()){
			currentEntry = it.next();
			return true;
		}
			return false;
	}

	@Override
	public void initialize(SailPointContext context, LiveReport report,
			Attributes<String, Object> arguments, String groupBy, List<Sort> sort)
			throws GeneralException {
		this.context = context;
		results = new LinkedHashMap();
		countIdentitiesWithCaps(results);
		it = results.entrySet().iterator();
	}
	
	private int countCapability(Iterator<Object[]> i, String capName){
		int result = 0;
		
		return result;
	}
	
	private void countIdentitiesWithCaps(LinkedHashMap results) throws GeneralException{
		int am, hd, ra, gi, gq, gm, lh;
		am = hd = ra = gi = gq = gm = lh = 0;
		QueryOptions qo = new QueryOptions();
		Iterator<Object[]> iter; 
		iter = context.search(Identity.class, qo, "id");
		
		int counter = 0;
		
		while(iter.hasNext()){
			Identity i = context.getObjectById(Identity.class, (String)iter.next()[0]);
			String lhAttribute = (String)i.getAttribute("legalHold");
			if(lhAttribute != null && lhAttribute.equals("1:FFl9gS71NuPO1vh6yuUNGA==")) //"encrypted" value of legalHold property set
				lh++;
			
			if(i.getCapabilityManager().hasCapability("AccountManager"))
				am++;
			else if(i.getCapabilityManager().hasCapability("HelpDesk"))
				hd++;
			else if(i.getCapabilityManager().hasCapability("RAManager"))
				ra++;
			else if(i.getCapabilityManager().hasCapability("GlobalDataInspector"))
				gi++;
			else if(i.getCapabilityManager().hasCapability("GlobalDataQualityManager"))
				gq++;
			else if(i.getCapabilityManager().hasCapability("GlobalMailManager"))
				gm++;
			
			if(counter % 100 == 0){
				context.decache();
			}
			++counter;
		}
		results.put("Identities with AccountManager Capability", am);
		results.put("Identities with HelpDesk Capability", hd);
		results.put("Identities with RAManager Capability", ra);
		results.put("Identities with GlobalDataInspector Capability", gi);
		results.put("Identities with GlobalDataQualityManager Capability", gq);
		results.put("Identities with GlobalMailManager Capability", gm);
		results.put("Identities on Legal Hold", lh);
	}

	@Override
	public void setLimit(int startRow, int pageSize) {
		this.startRow = startRow;
		this.pageSize = pageSize;
	}
	
}
