package com.philips.custom.validation;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.reporting.datasource.*;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;

public class ValidatorOUCapabilities implements JavaDataSource{
	
	private QueryOptions baseQueryOptions;
	private Object[] currentRow;
	private Monitor monitor;
	private Object startRow;
	private Object pageSize;
	private TreeMap results;
	private Iterator<Map.Entry<String, Integer[]>> it;
	private Entry<String, Integer[]> currentEntry;
	private SailPointContext context;

	@Override
	public String getBaseHql() {
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions() {
		return baseQueryOptions;
	}

	@Override
	public Object getFieldValue(String field) throws GeneralException {
		if ("key".equals(field)){
			return currentEntry.getKey();
		} else if ("ra".equals(field)){
			return currentEntry.getValue()[0];
		} else if ("hd".equals(field)){
			return currentEntry.getValue()[1];
		} else {
			throw new GeneralException("Unknown column '"+field+"'");
		}
	}

	@Override
	public int getSizeEstimate() throws GeneralException {
		return 20;
	}

	@Override
	public void close() {
	}

	@Override
	public void setMonitor(Monitor m) {
		monitor = m;
	}

	@Override
	public Object getFieldValue(JRField jrField) throws JRException {
		String name = jrField.getName();
		try {
			return getFieldValue(name);
		} catch (GeneralException e) {
			throw new JRException(e);
		}
	}

	@Override
	public boolean next() throws JRException {
		if (it.hasNext()){
			currentEntry = it.next();
			return true;
		}
			return false;
	}

	@Override
	public void initialize(SailPointContext context, LiveReport report,
			Attributes<String, Object> arguments, String groupBy, List<Sort> sort)
			throws GeneralException {
		this.context = context;
		results = new TreeMap();
		countCapabilitiesPerOU(results);
		it = results.entrySet().iterator();
	}
	
	private void countCapabilitiesPerOU(TreeMap results) throws GeneralException{
		QueryOptions qo = new QueryOptions();
		qo.addFilter(Filter.eq("application.name", "CODE1"));
		Iterator<Object[]> iter; 
		iter = context.search(Link.class, qo, "id");
		
		int counter = 0;
		
		while(iter.hasNext()){
			Link l = context.getObjectById(Link.class, (String)iter.next()[0]);
			Identity i = l.getIdentity();

			String dn = (String) l.getAttribute("distinguishedName");
			if(false) dn = "CN=400079246,OU=Users,OU=ORG2,OU=SailPoint,DC=code1-test,DC=emi-test,DC=philips,DC=com"; //sandbox test
			if(dn != null)
				for(String token : dn.split(",")){
					if(token.startsWith("OU=")){
						String ouName = token.substring("OU=".length());
						if(i.getCapabilityManager().hasCapability("HelpDesk")){
							if(results.get(ouName) == null){
								Integer[] val = {0, 0};
								results.put(ouName, val);
							}
							else{
								Integer[] val = (Integer[])results.get(ouName);
								val[0]++;
								results.put(ouName, val);
							}
						}
						if(i.getCapabilityManager().hasCapability("RAManager")){
							if(results.get(ouName) == null){
								Integer[] val = {0, 0};
								results.put(ouName, val);
							}
							else{
								Integer[] val = (Integer[])results.get(ouName);
								val[1]++;
								results.put(ouName, val);
							}
						}
					}
			}
			if(counter % 100 == 0){
				context.decache();
			}
			++counter;
		}
	}

	@Override
	public void setLimit(int startRow, int pageSize) {
		this.startRow = startRow;
		this.pageSize = pageSize;
	}
	
}
