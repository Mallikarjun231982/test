package com.philips.custom.validation;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;
import sailpoint.api.IdentityService;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.reporting.datasource.*;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class ValidatorIdentityDataQuality implements JavaDataSource{
	
	private QueryOptions baseQueryOptions;
	private Object[] currentRow;
	private Monitor monitor;
	private Object startRow;
	private Object pageSize;
	
	private TreeMap results;
	private Iterator<Map.Entry<String, Integer>> it;
	private Entry<String, Integer> currentEntry;
	private SailPointContext context;

	@Override
	public String getBaseHql() {
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions() {
		return baseQueryOptions;
	}

	@Override
	public Object getFieldValue(String field) throws GeneralException {
		if ("key".equals(field)){
			return currentEntry.getKey();
		} else if ("value".equals(field)){
			return currentEntry.getValue();
		} else {
			throw new GeneralException("Unknown column '"+field+"'");
		}
	}

	@Override
	public int getSizeEstimate() throws GeneralException {
		return 20;
	}

	@Override
	public void close() {
	}

	@Override
	public void setMonitor(Monitor m) {
		monitor = m;
	}

	@Override
	public Object getFieldValue(JRField jrField) throws JRException {
		String name = jrField.getName();
		try {
			return getFieldValue(name);
		} catch (GeneralException e) {
			throw new JRException(e);
		}
	}

	@Override
	public boolean next() throws JRException {
		if (it.hasNext()){
			currentEntry = it.next();
			return true;
		}
			return false;
	}

	@Override
	public void initialize(SailPointContext context, LiveReport report,
			Attributes<String, Object> arguments, String groupBy, List<Sort> sort)
			throws GeneralException {
		this.context = context;
		results = new TreeMap();
		countIdentities(results);
		it = results.entrySet().iterator();
	}
	
	private int countCapability(Iterator<Object[]> i, String capName){
		int result = 0;
		
		return result;
	}
	
	private void countIdentities(TreeMap results) throws GeneralException{
		int noCODE1, multipleCODE1, logons6M, endMismatch;
		noCODE1 = multipleCODE1 = logons6M = endMismatch = 0;
		
		Date past30days, past90days, past6M, past2years;
		
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -30);
		past30days = cal.getTime();
		
		cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -90);
		past90days = cal.getTime();
		
		cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -6);
		past6M = cal.getTime();
		
		cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, -2);
		past2years = cal.getTime();
		
		IdentityService identityService = new IdentityService(context);
		Application appCODE1 = context.getObjectByName(Application.class, "CODE1");
		
		QueryOptions qo = new QueryOptions();
		Iterator<Object[]> iter; 
		iter = context.search(Identity.class, qo, "id");
		while(iter.hasNext()){
			Identity i = context.getObject(Identity.class, (String)iter.next()[0]);
			
			Date terminationDate = (Date)i.getAttribute("terminationDate");
			Date contractEndDate = (Date)i.getAttribute("contractEndDate");
			
			String inGraceStatus = (String)i.getAttribute("inGraceStatus");
			if(contractEndDate != null){
				cal.setTime(contractEndDate);
				cal.add(Calendar.DATE, 1);
				if(cal.before(terminationDate) || cal.after(terminationDate))
					endMismatch++;
			} else
				endMismatch++;
			
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 7);
			if(cal.getTime().equals(terminationDate))
				if(results.get("Identities matching <current date> + 7 days and inGraceStatus '" + inGraceStatus + "'") == null)
					results.put("Identities matching <current date> + 7 days and inGraceStatus '" + inGraceStatus + "'", 1);
				else
					results.put("Identities matching <current date> + 7 days and inGraceStatus '" + inGraceStatus + "'",
							((int)results.get("Identities matching <current date> + 7 days and inGraceStatus '" + inGraceStatus + "'")) + 1);
			
			
			String identityStatus = (String)i.getAttribute("identityStatus");
			if(terminationDate != null){
				if(terminationDate.before(past30days))
					if(results.get("Identities with terminationDate more than 30 days ago and identityStatus '" + identityStatus + "'") == null)
						results.put("Identities with terminationDate more than 30 days ago and identityStatus '" + identityStatus + "'", 1);
					else
						results.put("Identities with terminationDate more than 30 days ago and identityStatus '" + identityStatus + "'",
								((int)results.get("Identities with terminationDate more than 30 days ago and identityStatus '" + identityStatus + "'")) + 1);
				if(terminationDate.before(past90days))
					if(results.get("Identities with terminationDate more than 90 days ago and identityStatus '" + identityStatus + "'") == null)
						results.put("Identities with terminationDate more than 90 days ago and identityStatus '" + identityStatus + "'", 1);
					else
						results.put("Identities with terminationDate more than 90 days ago and identityStatus '" + identityStatus + "'",
								((int)results.get("Identities with terminationDate more than 90 days ago and identityStatus '" + identityStatus + "'")) + 1);
				if(terminationDate.before(past2years))
					if(results.get("Identities with terminationDate more than 2 years ago and identityStatus '" + identityStatus + "'") == null)
						results.put("Identities with terminationDate more than 2 years ago and identityStatus '" + identityStatus + "'", 1);
					else
						results.put("Identities with terminationDate more than 2 years ago and identityStatus '" + identityStatus + "'",
								((int)results.get("Identities with terminationDate more than 2 years ago and identityStatus '" + identityStatus + "'")) + 1);
			}
			boolean lastLogonBefore6Months = false;
			if(appCODE1 != null){
				List<Link> links = identityService.getLinks(i, appCODE1);
				int numPersonalAccounts = 0;
				if(links.size() == 0)
					noCODE1++;
				else{
					for(Link l: links){
						Object employeeType = l.getAttribute("employeeType");
						if(employeeType != null){
							if(employeeType.toString().equals("4")){
								numPersonalAccounts++;
								String lastLogonTimeStamp = (String)l.getAttribute("lastLogonStatus");
								if("INACTIVE".equals(lastLogonTimeStamp))
									lastLogonBefore6Months = true;
							}
						}
						if(numPersonalAccounts == 2) break;
					}
					switch(numPersonalAccounts){
					case 0:
						noCODE1++;
						break;
					case 2:
						multipleCODE1++;
						break;
					}
				}
			} else
				noCODE1++;
			
			if(lastLogonBefore6Months)
				logons6M++;
				
			if(results.get("Identities with �LastLogonTimeStamp� more than 6 months in the past") == null)
				results.put("Identities with �LastLogonTimeStamp� more than 6 months in the past", 1);
			else
				results.put("Identities with �LastLogonTimeStamp� more than 6 months in the past",
						((int)results.get("Identities with �LastLogonTimeStamp� more than 6 months in the past")) + 1);
			
			context.decache(i);
		}
		results.put("Identities without CODE1 personal account", noCODE1);
		results.put("Identities with multiple CODE1 personal accounts", multipleCODE1);
		results.put("Users with a Termination Date different than �End Date� + 1 day", endMismatch);
		
	}

	@Override
	public void setLimit(int startRow, int pageSize) {
		this.startRow = startRow;
		this.pageSize = pageSize;
	}
	
}
