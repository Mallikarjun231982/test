package com.philips.custom.validation;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.reporting.datasource.*;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;

public class ValidatorCode1Personal implements JavaDataSource{
	
	private QueryOptions baseQueryOptions;
	private Object[] currentRow;
	private Monitor monitor;
	private Object startRow;
	private Object pageSize;
	
	private LinkedHashMap results;
	private Iterator<Map.Entry<String, Integer>> it;
	private Entry<String, Integer> currentEntry;
	private SailPointContext context;

	@Override
	public String getBaseHql() {
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions() {
		return baseQueryOptions;
	}

	@Override
	public Object getFieldValue(String field) throws GeneralException {
		if ("key".equals(field)){
			return currentEntry.getKey();
		} else if ("value".equals(field)){
			return currentEntry.getValue();
		} else {
			throw new GeneralException("Unknown column '"+field+"'");
		}
	}

	@Override
	public int getSizeEstimate() throws GeneralException {
		return 20;
	}

	@Override
	public void close() {
	}

	@Override
	public void setMonitor(Monitor m) {
		monitor = m;
	}

	@Override
	public Object getFieldValue(JRField jrField) throws JRException {
		String name = jrField.getName();
		try {
			return getFieldValue(name);
		} catch (GeneralException e) {
			throw new JRException(e);
		}
	}

	@Override
	public boolean next() throws JRException {
		if (it.hasNext()){
			currentEntry = it.next();
			return true;
		}
			return false;
	}

	@Override
	public void initialize(SailPointContext context, LiveReport report,
			Attributes<String, Object> arguments, String groupBy, List<Sort> sort)
			throws GeneralException {
		this.context = context;
		results = new LinkedHashMap();
		countCode1PersonalAccounts(results);
		it = results.entrySet().iterator();
	}
	
	private void countCode1PersonalAccounts(LinkedHashMap results) throws GeneralException{
		int total, enabled, disabled, noEmployeeType;
		enabled = disabled = total = noEmployeeType = 0;
		QueryOptions qo = new QueryOptions();
		qo.add(Filter.eq("application.name", "CODE1"));
		Iterator<Object[]> iter; 
		iter = context.search(Link.class, qo, "id");
		
		int counter = 0;
		while(iter.hasNext()){
			Link l = context.getObjectById(Link.class, (String)iter.next()[0]);
			Object employeeType = l.getAttribute("employeeType");
			if(employeeType != null){
				if(employeeType.toString().equals("4"))
					total++;
				else
					continue;
			} else {
				noEmployeeType++;
			}
			if(l.isDisabled())
				disabled++;
			else
				enabled++;
			String dn = (String) l.getAttribute("distinguishedName");
			if(false) dn = "CN=400079246,OU=Users,OU=ORG2,OU=SailPoint,DC=code1-test,DC=emi-test,DC=philips,DC=com"; //sandbox test
			if(dn != null)
				for(String token : dn.split(",")){
					if(token.startsWith("OU=")){
						String ouName = token.substring("OU=".length());
						if(results.get("OU: " + ouName) == null)
							results.put("OU: " + ouName, 1);
						else
							results.put("OU: " + ouName, ((int)results.get("OU: " + ouName)) + 1);
					}
			}
			
			if(counter % 100 == 0){
				context.decache();
			}
			++counter;
		}
		results.put("Enabled accounts", enabled);
		results.put("Disabled accounts", disabled);
		results.put("Total accounts", total);
		results.put("No employee type", noEmployeeType);
	}

	@Override
	public void setLimit(int startRow, int pageSize) {
		this.startRow = startRow;
		this.pageSize = pageSize;
	}
	
}
