package com.philips.custom.tools;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sailpoint.api.SailPointContext;
import sailpoint.object.Attributes;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.Identity.CapabilityManager;
import sailpoint.object.Link;
import sailpoint.object.QueryOptions;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskResult.CompletionStatus;
import sailpoint.object.TaskSchedule;
import sailpoint.task.AbstractTaskExecutor;
import sailpoint.task.TaskMonitor;
import sailpoint.tools.Message;
import sailpoint.tools.Util;
import sailpoint.web.messages.MessageKeys;

public class IdentityCSVExporter extends AbstractTaskExecutor{

	private Log logger = LogFactory.getLog(IdentityCSVExporter.class);
	
	private DateFormat df = null;
	
	private TaskMonitor monitor = null;

	boolean _terminate;

	public boolean is_terminate() {
		return _terminate;
	}

	public void set_terminate(boolean _terminate) {
		this._terminate = _terminate;
	}
	
	private String separator=null;
	private String keySeperator = "�`";
	private BufferedWriter bw = null;
	Map<Integer,String> identityAttMap = null;
	private SailPointContext _context = null;
	SortedSet<Integer> keys = null;
	int processed=0;

	@Override
	public void execute(SailPointContext context, TaskSchedule taskSchedule,
			TaskResult taskResult, Attributes<String, Object> att) throws Exception {

		monitor = new TaskMonitor(context, taskResult);
		setMonitor(monitor);
		
		_context=context;
		
		if(logger.isDebugEnabled()){
			Iterator<Map.Entry<String, Object>> entries = att.entrySet().iterator();
			while(entries.hasNext()){
				Map.Entry<String, Object> entry = entries.next();
				logger.debug("Attribute : " +entry.getKey() +" Value : " +entry.getValue());	
			}
		}

		
		List<String> nonIdentityAtt = Arrays.asList(new String[]{"explanation", "excludeHeader", "failIfExist", "fileLocation", "separator", "identityFilter", "dateFormat", "launcher"});
		
		identityAttMap = new HashMap();
		
		Iterator<Map.Entry<String, Object>> entries = att.entrySet().iterator();
		while(entries.hasNext()){
			Map.Entry<String, Object> entry = entries.next();
			String value = (String) entry.getValue();
			String display = null;
			Boolean nullValue = false;
			
			logger.debug("value 1 : " +value);
			
			if(null != value && (value.contains(";") || value.contains(","))){
				String[] valueAr = null;
				if(value.contains(";")){
					valueAr = value.split(";");
				} else {
					valueAr = value.split(",");
				}
				
				if(valueAr.length == 1){
					value=valueAr[0];
				} else if (valueAr.length == 2){
					value=valueAr[0];
					display=valueAr[1];
				}else if (valueAr.length == 3){
					value=valueAr[0];
					display=valueAr[1];
					if(valueAr[2].toLowerCase().equals("null")){
						nullValue=true;
					}
				}
			}
			
			logger.debug("value 2 : " +value);
			
			if(!nonIdentityAtt.contains(entry.getKey()) && null != value && isInteger(value, 10)){
				if(identityAttMap.containsKey(value)){
					throw new Exception("Duplicate column number " +value +" Please check your task definition");
				} else {
					identityAttMap.put(Integer.parseInt(value), entry.getKey()+keySeperator+display+keySeperator+nullValue);
				}
			}
		}
		
		logger.debug("identityAttMap : " +identityAttMap);
		
		keys = new TreeSet<Integer>(identityAttMap.keySet());
		
		logger.debug("keys : " +keys);

		boolean success = true;

		String identityFilter=null;
		Filter filter=null;

		if(att.containsKey("identityFilter"))
			identityFilter = (String) att.get("identityFilter");

		separator = (String) att.get("separator");

		String fileLocation = (String) att.get("fileLocation");
		String tempfileLocation = null;
		
		if(fileLocation.contains("(DATETIME)")){
			SimpleDateFormat filedf = new SimpleDateFormat("yyyyMMddHHmmss");
			fileLocation = fileLocation.replaceAll("\\(DATETIME\\)", filedf.format(new Date()));
		}
		
		if(fileLocation.toLowerCase().endsWith(".csv")){
			tempfileLocation = fileLocation.toLowerCase().replace(".csv", ".tmp");
		} else {
			tempfileLocation = fileLocation.toLowerCase()+".tmp";
		}

		boolean failIfExist = att.getBoolean("failIfExist");

		boolean excludeHeader = att.getBoolean("excludeHeader");
		
		String dateFormat = att.getString("dateFormat");
		
		
		if(null != dateFormat && !"".equals(dateFormat)){
			df = new SimpleDateFormat(dateFormat);
		} else {
			df = new SimpleDateFormat("dd-MMM-yyyy");
		}

		logger.debug("Got arguments identityFilter : " +identityFilter +" separator : " +separator +" fileLocation : " +fileLocation +" failIfExist : " +failIfExist +" excludeHeader : " +excludeHeader);


		String errorMessage="";

		try{

			//check the filelocation

			File exportFile = new File(fileLocation);
			File exportFiletemp = new File(tempfileLocation);

			if(exportFile.exists() && failIfExist){
				logger.debug("File existed and Fail if exist was set to true");
				success=false;
				errorMessage="Export file : " +fileLocation +" already exist and Fail if Exist is set to " +failIfExist;
			} else {

				bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempfileLocation), "UTF-8"));
				
				logger.debug("Can Write: "  +exportFile.canWrite() +" " +exportFiletemp.canWrite());
				
				exportFile.delete();
				
				if(!exportFiletemp.canWrite()){
					logger.debug("Failed to write to  " +fileLocation +" or " +tempfileLocation);
					success=false;
					errorMessage="We failed to write to  " +fileLocation +" or " +tempfileLocation;
				} else {
					//OK We are ready to start
					
					if(!excludeHeader)
						writeHeader();
					
					if(null != identityFilter)
						filter = Filter.compile(identityFilter);

					QueryOptions qo = new QueryOptions();
					qo.addFilter(filter);

					Iterator<Object[]> it = _context.search(Identity.class, qo, "id");
					
					while (it.hasNext()){
						Object[] identityObj = it.next();
						String identityID = (String)identityObj[0];
						writeExportEntry(identityID);
						
						if(processed % 20 == 0){
							_context.decache();
						}
					}
				}

			}

			if(!is_terminate() && success){
				bw.close();
				exportFiletemp.renameTo(exportFile);				
				
				taskResult.addMessage(new Message("Exported " +processed +" Identities", (Object)null));
				taskResult.setCompletionStatus(CompletionStatus.Success);
			} else {
				taskResult.addMessage(new Message(Message.Type.Error,MessageKeys.ERR_EXCEPTION,errorMessage));
			}
		}catch(Exception e){
			taskResult.addMessage(new Message(Message.Type.Error,MessageKeys.ERR_EXCEPTION,stack2string(e)));
		} finally{
			bw.close();
		}

	}

	private void writeExportEntry(String identityID) throws Exception {
		
		logger.debug("Entered writeExportEntry with : " +identityID);
		
		Identity identity = _context.getObjectById(Identity.class, identityID);

		if(null != identity){
			String line = "";
			
			for (Integer key : keys) { 
				String[] attributes = identityAttMap.get(key).split(keySeperator);
				String attribute = attributes[0];
				String display = attributes[1];
				Boolean nullValue = attributes[2].equals("true")? true : false;
				String value = "";
				Object objValue= null;
				
				logger.debug("attribute : " +attribute );
				
				if(attribute.equals(Identity.ATT_USERNAME))
					value = identity.getName();
				else if(attribute.equals(Identity.ATT_FIRSTNAME))
					value = identity.getFirstname();
				else if(attribute.equals(Identity.ATT_LASTNAME))
					value = identity.getLastname();
				else if(attribute.equals(Identity.ATT_MANAGER)){
					Identity manager = identity.getManager();
					if(null != manager){
						value=manager.getName();
					}
				}
				else if(attribute.equals(Identity.ATT_DISPLAYNAME))
					value = identity.getDisplayableName();
				else if(attribute.equals(Identity.ATT_EMAIL))
					value = identity.getEmail();
				else if(attribute.equals(Identity.ATT_INACTIVE))
					value = ""+identity.isInactive();
				else if(attribute.equals("AOKSupport"))
					value = getAOKKSupport(identity);
				else if(attribute.equals("PAccountStatus"))
					value = getPAccountStatus(identity);
				else if(attribute.equals("userAccountControl"))
					value = getUserAccountControl(identity);
				else if(attribute.equals("managerMail"))
					value = getUserManagerMail(identity);
				else if(attribute.equals("isRA"))
					value = getRAStatus(identity);
				else if(attribute.equals("isIM"))
					value = getIMStatus(identity);
				else if(attribute.equals("isHD"))
					value = getHDStatus(identity);
				else if(attribute.equals("partnerAdditionalAccess"))
					value = null != identity.getAttribute("partnerAdditionalAccess") && (boolean)identity.getAttribute("partnerAdditionalAccess") ?  "YES" :  "NO";
				else if(attribute.equals("objectType"))
					value = "person";
				else
					objValue = (Object)identity.getAttribute(attribute);
				
				if(objValue instanceof String)
					value = (String) objValue;
				if(objValue instanceof Integer)
					value = ""+objValue;
				if(objValue instanceof Date){
					value = df.format(objValue);
				}
				
				logger.debug("value : " +value );
				
				if(null == value || nullValue)
					line = line +"\"\""  +separator;
				else
					line = line + "\"" +value +"\""  +separator;
			}
			logger.debug("line : " +line );
			
			line = line.substring(0, line.length() - separator.length());
			
			bw.write(line);
			bw.newLine();
			bw.flush();
			
			processed++;

		} else {
			logger.error("Identity " +identityID +" Did not exist");
		}

	}

	private String getHDStatus(Identity identity) {
		CapabilityManager capmanager = identity.getCapabilityManager();
		
		if(capmanager.hasCapability("HelpDesk")){
			return "Yes";
		} else {
			return "No";
		}
	}

	private String getIMStatus(Identity identity) {
		CapabilityManager capmanager = identity.getCapabilityManager();
		
		if(capmanager.hasCapability("IdentityManager") || capmanager.hasCapability("IdentityDelegate")){
			return "Yes";
		} else {
			return "No";
		}
	}

	private String getRAStatus(Identity identity) {
		
		CapabilityManager capmanager = identity.getCapabilityManager();
		
		if(capmanager.hasCapability("RAManager")){
			return "Yes";
		} else {
			return "No";
		}

	}

	private String getUserManagerMail(Identity identity) {
		
		Identity manager = identity.getManager();
		
		if(null != manager){
			String email = manager.getEmail();
			if(null != email){
				return email;
			}
		}

		return "";
	}

	private String getUserAccountControl(Identity identity) {

		List<Link> links = identity.getLinks();
		
		for(Link link : links){
			if("CODE1".equals(link.getApplicationName()) && "4".equals(link.getAttribute("employeeType"))){
				Object userAccountControl = link.getAttribute("accountFlags");
				if(null != userAccountControl){
					if(userAccountControl instanceof String)
						return (String)userAccountControl;
					else if(userAccountControl instanceof List){
						return Util.listToCsv((List)userAccountControl);
					}
				}
			}
		}
		
		return "Unknown";
	}

	private String getPAccountStatus(Identity identity) {
		
		List<Link> links = identity.getLinks();
		
		for(Link link : links){
			if("CODE1".equals(link.getApplicationName()) && "4".equals(link.getAttribute("employeeType"))){
				if(link.isDisabled())
					return "Disabled";
				else
					return "Enabled";
			}
		}
		
		return "Unknown";
	}

	private String getAOKKSupport(Identity identity) {
		
		CapabilityManager capManager = identity.getCapabilityManager();
		
		if(capManager.hasCapability("IdentityManager") || capManager.hasCapability("IdentityDelegate"))
			return "YES";
		
		if(capManager.hasCapability("RAManager"))
			return "YES";
		
		if(capManager.hasCapability("HelpDesk"))
			return "YES";
		
		return "NO";
	}

	private void writeHeader() throws Exception {
		logger.debug("Entered writeHeader");
		
		String line = "";
		
		for (Integer key : keys) { 
			String[] attributes = identityAttMap.get(key).split(keySeperator);
			String display = attributes[1];
			
			if(display.equals("null") || display.equals(""))
				line = line +"\"" +attributes[0] +"\"" +separator;
			else
				line = line +"\"" + display +"\"" +separator;
		}
		
		line = line.substring(0, line.length() - separator.length());
		
		bw.write(line);
		bw.newLine();
		bw.flush();
		
	}
	
	private  boolean isInteger(String s, int radix) {
		logger.debug("Enter isInteger : " +s);
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}

	@Override
	public boolean terminate() {
		set_terminate(true);
		return is_terminate();
	}
	
	private String stack2string(Exception e) {
		try {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			return "------\r\n" + sw.toString() + "------\r\n";
		} catch (Exception e2) {
			return "bad stack2string";
		}
	}

}
