package com.philips.custom.tools.launchwftask;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.QueryOptions;
import sailpoint.tools.GeneralException;



public class InternalLeaverWorker implements Worker {
	
	private Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
		
	private String workflowKey_Notification = "internalLeaver_Notification";
	private Integer from_NumberOfDays_Notification;
	private Integer till_NumberOfDays_Notification;
	private String applicationName_Notification;
	
	private String workflowKey_Deactivation = "internalLeaver_Deactivation";
	private Integer from_NumberOfDays_Deactivation;
	private Integer till_NumberOfDays_Deactivation;
	
	public InternalLeaverWorker(SailPointContext context) throws GeneralException{
		
		initializeVariables_Notification(context);
		initializeVariable_Deactivate(context);
		
     }
	
	
	/**  1.	IDM evaluates the �Termination date� attribute:
					1.	IDM evaluates the �Termination date� attribute:
						a.	If Termination date is in 14 days, send notification to contact person and RA Manager
						b.	If the Termination date is the current date, deactivate identity

	 * 
	 */
	@Override
	public void process(SailPointContext context, CompletionService executorCreate, Set<Future<String>> futuresCreate, Map<String, Integer> resultMap, int numberOfThreads, String filterString) throws Exception {

		logger.debug("Entered InternalLeaverWorker");
		
		Iterator<Object[]> iter;
		
		iter=queryIdentities(context,"terminationDate",from_NumberOfDays_Notification,till_NumberOfDays_Notification, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey_Notification, applicationName_Notification,resultMap, numberOfThreads);}
		
		iter=queryIdentities(context,"terminationDate",from_NumberOfDays_Deactivation,till_NumberOfDays_Deactivation, filterString); 
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey_Deactivation, "",resultMap, numberOfThreads);}

	}
	

	private void startJobs(SailPointContext context, Set<Future<String>> futuresCreate,
			CompletionService executorCreate, Iterator<Object[]> iter, String workflowKey, String applicationName, Map<String, Integer> resultMap, int numberOfThreads) throws Exception {
		logger.debug("Entered InternalLeaverWorker.startJobs");

		while (iter.hasNext()){
			//CheckThreads.checkThreads(context, futuresCreate, numberOfThreads, resultMap, logger);
			 Object[] obj = (Object[]) iter.next();
			 logger.trace("Identity: "+obj[0]);
			 String id=obj[0].toString();
			 futuresCreate.add(executorCreate.submit(new InternalLeaverJob(id,"terminationDate",workflowKey,14,applicationName_Notification)));
		}
		
	}
	
	
	Iterator<Object[]> queryIdentities(SailPointContext context,String dateAttribute,Integer i1, Integer i2, String filterString) throws Exception {
		logger.debug("Entered InternalLeaverWorker.queryIdentities");
		
		Date d1 = null;
		Date d2 = null;
		
		if(null != i1){
			//get first date and second date of time interval
			Calendar cal1 = Calendar.getInstance();
			cal1.add(Calendar.DATE, i1); //today+i1
			d1 = cal1.getTime();
			logger.trace("First Date of time interval: "+d1);
		}

		if(null != i2){
			Calendar cal2 = Calendar.getInstance();
			cal2.add(Calendar.DATE, i2+1); //today+i2 and +1 because function below is greater or equal but just greater is required
			d2 = cal2.getTime();
			logger.trace("Second Date of time interval: "+d2);
		}
		
		QueryOptions qo = new QueryOptions();
		Iterator<Object[]> iter; 
		if(null != d1)
			qo.add(Filter.le(dateAttribute, d1));
		if(null != d2)
			qo.add(Filter.ge(dateAttribute, d2)); 	
		qo.addFilter(Filter.ignoreCase(Filter.eq("identityStatus","Active")));
		//qo.add(Filter.like("employeeType", "Employee"));
		qo.addFilter(Filter.ignoreCase(Filter.not(Filter.like("employeeType", "partner"))));
		
		if(null != filterString)
			qo.add(Filter.compile(filterString));
		
		if(logger.isDebugEnabled())logger.debug("Filter Query : " +qo.getQuery());
		
		iter = context.search(Identity.class, qo, "id");
		
		return iter;
	}
	
	

	
	private void initializeVariable_Deactivate(SailPointContext context) throws GeneralException {
		Custom custom = context.getObjectByName(Custom.class,"Philips Launch Workflow Task Parameters");
		if(custom == null){
										logger.trace("Object \"Philips Launch Workflow Task Parameters\" not found");
		}
		@SuppressWarnings("unchecked")
		Map<String, String> wfParameters = (Map<String, String>) custom.get(workflowKey_Deactivation);
										logger.trace("wfParameters: "+wfParameters);
		from_NumberOfDays_Deactivation= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays_Deactivation= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;

	}



	private void initializeVariables_Notification(SailPointContext context) throws GeneralException {
		Custom custom = context.getObjectByName(Custom.class,"Philips Launch Workflow Task Parameters");
		if(custom == null){
										logger.trace("Object \"Philips Launch Workflow Task Parameters\" not found");
		}
		@SuppressWarnings("unchecked")
		Map<String, String> wfParameters = (Map<String, String>) custom.get(workflowKey_Notification);
										logger.trace("wfParameters: "+wfParameters);
										
		from_NumberOfDays_Notification= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays_Notification= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		applicationName_Notification=wfParameters.get("applicationName");
	}



	
}