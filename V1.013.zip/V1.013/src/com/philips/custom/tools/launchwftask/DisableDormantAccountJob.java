package com.philips.custom.tools.launchwftask;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;
import sailpoint.object.Link;

public class DisableDormantAccountJob implements Job {
	
	private static final String WORKFLOWNAME_DISABLE="Philips Disable Account";
	
	private String id;
	private SailPointContext context;
	private Identity identity;
	private Link link;
	private String workflowKey;
	private String applicationName;
	private String nativeIdentity;
	
	private static Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	
	public DisableDormantAccountJob(String id, String applicationName, String workflowKey) {
		this.id=id;
		this.workflowKey=workflowKey;
		this.applicationName=applicationName;
		
	}


	@SuppressWarnings("rawtypes")
	@Override
	public String call() throws Exception {
		logger.debug("Entered DisableAccountJob");
		logger.trace("creating context...");

		try{
			context = SailPointFactory.createContext("DisableAccountJob");

			link=context.getObjectById(Link.class,id);
			identity=link.getIdentity();
			nativeIdentity=link.getNativeIdentity();

			String getLegaHold = context.decrypt((String) identity.getAttribute("legalHold"));

			logger.debug("LegalHold : " +getLegaHold);

			if(null == getLegaHold || (null != getLegaHold && getLegaHold.toLowerCase().equals("false"))){
				
				if(!link.isDisabled()){

					Map workflowArgs = getWorkflowArgsForDisablingAccount(identity);
					logger.trace("workflowArgs: "+workflowArgs.toString());
					WorkflowLauncher.launchWorkflow(WORKFLOWNAME_DISABLE, workflowArgs, context, identity);

					return workflowKey;

				} 
			}
			return null;
		} catch(Exception e){
			throw new Exception(e);
		} finally{
			logger.trace("releasing context...");
			SailPointFactory.releaseContext(context);
		}
	}

	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForDisablingAccount(Identity identity) {
		Map workflowArgs = new HashMap();
        
        workflowArgs.put("identityName", identity.getName());
        workflowArgs.put("applicationName", applicationName);
        workflowArgs.put("nativeIdentity", nativeIdentity);
		if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);
        
        return workflowArgs;

	}


}
