package com.philips.custom.tools.launchwftask;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;

import sailpoint.api.ObjectUtil;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.tools.Util;

public class InternalLeaverJob implements Job {

	private static final String WORKFLOWNAME_SEND_MAILS="Philips Dynamic Send Emails Sub";
	private static final String WORKFLOWNAME_ACTIVATE_DEACTIVATE="Philips Activate DeActivate";

	private String id;
	private long daysToExpiration;
	private SailPointContext context;
	private Identity identity;
	private Date terminationDate;
	private String attributeKey;
	private int daysInPast;
	private String workflowKey;
	private String applicationName;

	private static Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");

	public InternalLeaverJob(String id, String attributeKey, String workflowKey, int daysInPast, String applicationName) {
		this.id=id;
		this.attributeKey=attributeKey;
		this.daysInPast=daysInPast;
		this.workflowKey=workflowKey;
		this.applicationName=applicationName;


	}


	@SuppressWarnings("rawtypes")
	@Override
	public String call() throws Exception {
		logger.debug("Entered InternalLeaverJob");
		logger.trace("creating context...");

		try{

			context = SailPointFactory.createContext("PartnerLeaverJob");

			identity=context.getObjectById(Identity.class,id);
			
			//Disable the check for legal Hold

			//String getLegaHold = context.decrypt((String) identity.getAttribute("legalHold"));

			//logger.debug("LegalHold : " +getLegaHold);

			//if(null == getLegaHold || (null != getLegaHold && getLegaHold.toLowerCase().equals("false"))){

				terminationDate = (Date)identity.getAttribute(attributeKey);
				daysToExpiration = 1+TimeUnit.DAYS.convert(terminationDate.getTime() - new Date().getTime(), TimeUnit.MILLISECONDS);
				logger.trace("identity: "+identity.getDisplayName());
				logger.trace("terminationDate: "+terminationDate);
				logger.trace("daysToExpiration: "+daysToExpiration);


				if (WorkflowLauncher.workflowAlreadyLaunched(identity, workflowKey,terminationDate,daysInPast)==true){
					return "Workflow already launched";
				}

				Map workflowArgs=null;
				if(!workflowKey.equals("internalLeaver_Deactivation")){
					workflowArgs = getWorkflowArgsForInternalLeaverNotificationMail(context, identity, daysToExpiration,terminationDate, workflowKey, applicationName);
					WorkflowLauncher.launchWorkflow(WORKFLOWNAME_SEND_MAILS, workflowArgs, context, identity);
				}else{
					workflowArgs = getWorkflowArgsForAccountDeactivation(identity, workflowKey);
					WorkflowLauncher.launchWorkflow(WORKFLOWNAME_ACTIVATE_DEACTIVATE, workflowArgs, context, identity);
				}
				logger.trace("workflowArgs: "+workflowArgs.toString());

				return workflowKey;
			//}
			//return null;
		} catch(Exception e){
			throw new Exception(e);
		}finally{
			logger.trace("releasing context...");
			SailPointFactory.releaseContext(context);
		}
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForAccountDeactivation(Identity identity, String workflowKey) {
		Map workflowArgs = new HashMap();

		workflowArgs.put("identity", identity.getName());
		workflowArgs.put("action", "deactivate");
		workflowArgs.put("deactivateAccounts", "true");
		workflowArgs.put("workflowKey", workflowKey);
		if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);

		return workflowArgs;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Map getWorkflowArgsForInternalLeaverNotificationMail(SailPointContext context, Identity identity, long daysToExpiration, Date terminationDate, String workflowKey, String applicationName) throws Exception{
		//Get attributes for two email
		// 1. notification to contact person (Manager)
		// 2. notification to RA Manager group
		// "Hi, the account of identity is going to expire in 14 days"
		//
		DateFormat emailDateFormat = new SimpleDateFormat("dd MMM yyyy");
		Map workflowArgs = new HashMap();
		List emailArgList = new ArrayList();
		List<Link> fAccountList = getFunctionalAccounts(identity, applicationName);
		String fAccountString = getfAccountString(fAccountList);
		Link personalAccount = getPersonalAccount(identity, applicationName);



		/*
		 * emailArgs.toDisplayName (String)	:       The name of the Contact Person Manager (ContactPerson attribute).
	  emailArgs.identityDisplayName   	:		The Display Name of identity whose account will be disabled.	 Display Name: [//Target/DisplayName]
	  emailArgs.date				  	 :		Expiration Date: [//Target/ExpirationTime] - Date for number of days left till identity/accounts are disabled.
	  emailArgs.emptype				 	: 		EmployeeType the type of Employee( Internal, Contractor, Partner)[//Target/EmployeeType] 
      emailArgs.philipsaccount			:		Philips Account: [//Target/AccountName]
	  emailArgs.pdspayrollnum			:		Payroll Number: [//Target/PDSPayrollNumber]
	  emailArgs.pdsid					: 		Domain Name: [//Target/Domain]
	  emailArgs.ownedfaccounts 			:		Owned Functional accounts: [//Target/OwnedfAccounts] 
		 */


		//MAIL TO MANAGER
		Map emailArgsManager = new HashMap();
		emailArgsManager.put("emailTemplate", "Philips Internal Leaver Contact Person");
		try{
			emailArgsManager.put("to", identity.getManager().getEmail());
			emailArgsManager.put("toDisplayName", identity.getManager().getDisplayableName());
		}catch(Exception e){
			logger.trace("Possibly no manager assigned!");
		}
		emailArgsManager.put("identityDisplayName", identity.getDisplayableName());
		emailArgsManager.put("date", emailDateFormat.format(identity.getAttribute("terminationDate")));
		emailArgsManager.put("emptype", identity.getAttribute("employeeType"));
		if(personalAccount!=null) {
			emailArgsManager.put("philipsaccount", personalAccount.getDisplayableName());
		}else emailArgsManager.put("philipsaccount", "no account found");
		emailArgsManager.put("pdsid", identity.getAttribute("globalEmployeeId"));
		emailArgsManager.put("ownedfaccounts", fAccountString);
		emailArgList.add(emailArgsManager);
		logger.trace("emailArgsManager: "+emailArgsManager.toString());





		/*
		 *        emailArgs.toDisplayName (String):          The name of the RA Manager.
				  emailArgs.identityDisplayName   :			 The Display Name of identity whose account will be disabled.	 Display Name: [//Target/DisplayName]
				  emailArgs.date				  :			 Date for number of days left till identity/accounts are disabled.
			      emailArgs.philipsaccount		  :			 Philips Account: [//Target/AccountName]
				  emailArgs.ou					  :			 Organizational Unit: [//Target/OU]
				  emailArgs.domain				  : 		 Domain Name: [//Target/Domain]
				  emailArgs.ownedfaccounts		  :			 Owned Functional accounts: [//Target/OwnedfAccounts]
				  emailArgs.days				  :			 Number of days until termination															
		 */


		//MAIL TO RA MANAGER
		List<String> raManagers=getRAManagerEmailList(context, identity);
		logger.trace("raManagers: "+raManagers);
		
		List mailList = new ArrayList();
		
		for(String id : raManagers){

			Identity ramanager = context.getObject(Identity.class, id);
			if(null != ramanager){
				String mail = null;
				
				mail = ramanager.getEmail();
				
				if(null == mail){
					mail = (String)ramanager.getAttribute("partnerUniqueMail");
				}
				
				if(null != mail){
					mailList.add(mail);
				}
				context.decache(ramanager);
			}
		}
		
		String mail = Util.listToCsv(mailList, true);
		
		if(null != mail){
			Map emailArgsRAManagers = new HashMap();
			emailArgsRAManagers.put("emailTemplate", "Philips Internal Leaver RA Manager");
			emailArgsRAManagers.put("to", mail);
			emailArgsRAManagers.put("toDisplayName", "RA Manager");
			emailArgsRAManagers.put("identityDisplayName", identity.getDisplayableName());
			emailArgsRAManagers.put("expdate", emailDateFormat.format(identity.getAttribute("terminationDate")));
			emailArgsRAManagers.put("date", emailDateFormat.format(identity.getAttribute("terminationDate")));
			if(personalAccount!=null) {
				emailArgsRAManagers.put("philipsaccount", personalAccount.getDisplayableName());
				String domain = (String) personalAccount.getAttribute("msDS-PrincipalName");
			       if(null != domain && domain.contains("\\")){
			    	   domain = domain.substring(0, domain.indexOf("\\"));
			       }else{
			    	   domain="Philips";
			       }
				emailArgsRAManagers.put("domainname", domain);
			}else{
				emailArgsRAManagers.put("philipsaccount", "no account found");
				emailArgsRAManagers.put("domainname", "---");
			}
			emailArgsRAManagers.put("ou", identity.getAttribute("ou"));
			emailArgsRAManagers.put("ownedfaccounts", fAccountString);
			emailArgsRAManagers.put("days", String.valueOf(daysToExpiration));
			emailArgsRAManagers.put("emptype", identity.getAttribute("employeeType"));
			emailArgList.add(emailArgsRAManagers);
		}

		workflowArgs.put("emailArgList", emailArgList);
		workflowArgs.put("identityName", identity.getName());
		workflowArgs.put("workflowKey", workflowKey);
		if(logger.isDebugEnabled())
			workflowArgs.put("trace", true);
		else
			workflowArgs.put("trace", false);

		return workflowArgs;
	}



	private static String getfAccountString(List<Link> fAccountList) {
		logger.debug("Entered getfAccountString");
		String fAccountString="";
		List<String> fAStrings=new ArrayList<String>();
		for (Link link : fAccountList) {
			fAStrings.add(link.getApplicationName()+": "+link.getDisplayableName());
		}
		fAccountString=fAStrings.toString();
		logger.trace("fAccountString: "+fAccountString);
		return fAccountString;
	}


	private static List<Link> getFunctionalAccounts(Identity identity, String applicationName) {
		logger.debug("Entered getFunctionalAccounts");
		List<Link> linkList = identity.getLinks();
		List<Link> removeLinkList = new ArrayList();
		logger.trace("linkList: "+linkList.toString());
		if(linkList!=null){
			for (Link link : linkList) {
				if(link.getApplicationName().equals(applicationName)){
					if (null != link.getAttribute("employeeType") && link.getAttribute("employeeType").equals("2")){
						removeLinkList.add(link);
					}
				}
			}
		}
		return removeLinkList;
	}


	private static Link getPersonalAccount(Identity identity, String applicationName) {
		logger.debug("Entered getPersonalAccount");
		List<Link> linkList = identity.getLinks();
		logger.debug("linkList: "+linkList.toString());
		if(linkList!=null){
			for (Link link : linkList) {
				if(link.getApplicationName().equals(applicationName)){
					if (null != link.getAttribute("employeeType") && link.getAttribute("employeeType").equals("4")){
						Link pAccount = link;
						return pAccount;
					}
				}
			}
		}
		return null;
	}


	private static List<String> getRAManagerEmailList(SailPointContext context, Identity identity) throws Exception {
		logger.debug("Entered getRAManagerList");
		String wgNamePreFix = "wg-";
		String wgNameSufix = "-RAManager";
		List<String> raManagers = new ArrayList<String>();

		if(null != identity){
			String ou = (String)identity.getAttribute("ou");
			logger.trace("OU: "+ou);
			if(null != ou){
				Identity workgroup = context.getObject(Identity.class, wgNamePreFix+ou+wgNameSufix);
				logger.trace("workgroup: "+workgroup);

				if(null == workgroup){
					logger.error("Could not find Workgroup with name " +wgNamePreFix+ou+wgNameSufix +" skipping email to RA Managers");
				} else {

					List<String> props = new ArrayList<String>();
					props.add("id");

					Iterator<Object[]> it = ObjectUtil.getWorkgroupMembers(context, workgroup, props);
					logger.trace("iterator: "+it.toString());
					while (it.hasNext()){
						logger.trace("Entered while");
						Object[] obj = it.next();
						raManagers.add((String) obj[0]);
					}
					context.decache(workgroup);
				}
			}
		}
		if (raManagers.isEmpty()){
			logger.debug("No RA Manager found");
		}

		return raManagers;

	}



}
