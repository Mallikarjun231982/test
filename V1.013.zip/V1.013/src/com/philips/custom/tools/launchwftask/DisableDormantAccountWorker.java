package com.philips.custom.tools.launchwftask;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Link;
import sailpoint.object.QueryOptions;
import sailpoint.tools.GeneralException;



public class DisableDormantAccountWorker implements Worker {
	
	private Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");

	private String workflowKey = "disableDormantAccounts";
	 
	private String applicationName;
	
	public DisableDormantAccountWorker(SailPointContext context) throws GeneralException{
		Custom custom = context.getObjectByName(Custom.class,"Philips Launch Workflow Task Parameters");
		if(custom == null){
										logger.trace("Object \"Philips Launch Workflow Task Parameters\" not found");
		}
		@SuppressWarnings("unchecked")
		Map<String, String> wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);
		
		applicationName=wfParameters.get("applicationName");
	}
	
	
	/**  If the account is not logged in longer than 6 months, IDM shall disable the account.
	 * 
	 * @see com.philips.custom.tools.launchwftask.Worker#process(sailpoint.api.SailPointContext, java.util.concurrent.ExecutorService, java.util.Collection, org.apache.commons.logging.Log)
	 */
	@Override
	public void process(SailPointContext context, CompletionService executorCreate, Set<Future<String>> futuresCreate, Map<String, Integer> resultMap, int numberOfThreads, String filterString) throws Exception {
		
		logger.debug("Entered DisableDormantAccountWorker");
		
		Iterator<Object[]> iter;
		iter=queryLinks(context,"lastLogonStatus","INACTIVE", filterString);
		if(iter.hasNext()){startJobs(context, futuresCreate, executorCreate, iter ,resultMap, numberOfThreads);}
		
	}
	

	private void startJobs(SailPointContext context, Set<Future<String>> futuresCreate,
			CompletionService executorCreate, Iterator<Object[]> iter , Map<String, Integer> resultMap, int numberOfThreads) throws Exception {
		logger.debug("Entered DisableDormantAccountWorker.startJobs");

		while (iter.hasNext()){
			//CheckThreads.checkThreads(context, futuresCreate, numberOfThreads, resultMap, logger);
			 Object[] obj = (Object[]) iter.next();
			 logger.trace("Identity: "+obj[0]);
			 String id=obj[0].toString();
			 futuresCreate.add(executorCreate.submit(new DisableDormantAccountJob(id, applicationName, workflowKey)));
		}
		
	}
	
	
	Iterator<Object[]> queryLinks(SailPointContext context,String statusAttribute, String status, String filterString) throws Exception {
		logger.debug("Entered DisableDormantAccountWorker.queryIdentities");
		
	

	
		QueryOptions qo = new QueryOptions();
		Iterator<Object[]> iter=null;
		if(null != status)
			qo.add(Filter.eq(statusAttribute, status)); 
		 
		qo.addFilter(Filter.eq("linkDisabled", false)); // PH Added a disabled check as well
    	qo.add(Filter.eq("application.name",applicationName));
    	
    	if(null != filterString){
    		String[] filterElements = filterString.split(" (?=(([^'\"]*['\"]){2})*[^'\"]*$)");
			
			filterString="";
			
			
			for(int i=4; i<filterElements.length+4; i++){
				if(i % 4 == 0){
					filterString = filterString +" identity." +filterElements[i-4];
				} else {
					filterString = filterString +" " +filterElements[i-4];
				}
			}
			
			if(logger.isDebugEnabled())logger.debug("newFilterString : " +filterString);
			qo.add(Filter.compile(filterString));
    	}
    	
    	if(logger.isDebugEnabled())logger.debug("Filter Query : " +qo.getQuery());
    	
		iter = context.search(Link.class, qo, "id");
		
		return iter;
	}
	
}
