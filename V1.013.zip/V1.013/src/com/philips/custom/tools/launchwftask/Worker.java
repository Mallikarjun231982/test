package com.philips.custom.tools.launchwftask;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import sailpoint.api.SailPointContext;

public interface Worker {

	/**
	 * Searches for identities and schedules threaded jobs
	 * 
	 * @param context not <code>null</code>
	 * @param executorCreate not <code>null</code>
	 * @param futuresCreate not <code>null</code>
	 * @return
	 * @throws Exception
	 */
	public abstract void process(SailPointContext context,
			CompletionService executorCreate,
			Set<Future<String>> futuresCreater, Map<String, Integer> resultMap, int numberOfThreads, String filterString) throws Exception;
	
	


}