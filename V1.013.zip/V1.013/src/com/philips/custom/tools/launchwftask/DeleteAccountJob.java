package com.philips.custom.tools.launchwftask;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;
import sailpoint.object.Link;

public class DeleteAccountJob implements Job {
	
	private static final String WORKFLOWNAME="Philips Leaver Delete Account";
	
	private String id;
	private SailPointContext context;
	private Identity identity;
	private Date terminationDate;
	private String workflowKey;
	private int daysInPast;
	private String applicationName;
	
	
	private static Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	
	public DeleteAccountJob(String id, String workflowKey, String applicationName, int daysInPast) {
		this.id=id;
		this.workflowKey=workflowKey;
		this.daysInPast=daysInPast;
		this.applicationName=applicationName;
	}


	@SuppressWarnings("rawtypes")
	@Override
	public String call() throws Exception {
		logger.debug("Entered DeleteAccountJob");
		logger.trace("creating context..");

		try{							
			context = SailPointFactory.createContext("DeleteAccountJob");


			identity=context.getObjectById(Identity.class,id);

			String getLegaHold = context.decrypt((String) identity.getAttribute("legalHold"));

			logger.debug("LegalHold : " +getLegaHold);

			if(null == getLegaHold || (null != getLegaHold && getLegaHold.toLowerCase().equals("false"))){

				terminationDate = (Date)identity.getAttribute("terminationDate");
				logger.trace("identity: "+identity.getDisplayName());
				logger.trace("terminationDate: "+terminationDate);								


				List<Link> accountsToDelete=new ArrayList<Link>();
				List<String> accountsToDeleteNames=new ArrayList<String>();
				if (workflowKey.equals("deletePersonalAccounts")){
					Link account = getPersonalAccount(identity, applicationName);
					if(null != account){
						accountsToDeleteNames.add(applicationName +":" +account.getNativeIdentity());
					}
				}else if (workflowKey.equals("deleteFunctionalAccounts")){
					accountsToDelete=getFunctionalAccounts(identity, applicationName);
					for (Link link : accountsToDelete) {
						accountsToDeleteNames.add(applicationName +":" +link.getNativeIdentity());
					}
				}


				if(accountsToDeleteNames.size() > 0){
					
					if (WorkflowLauncher.workflowAlreadyLaunched(identity, workflowKey,terminationDate,daysInPast)==true){
						return "Workflow already launched";
					}
					
					
					Map workflowArgs=null;
					workflowArgs = getWorkflowArgsForAccountDeletion(identity, workflowKey, accountsToDeleteNames);
					logger.trace("workflowArgs: "+workflowArgs.toString());
					WorkflowLauncher.launchWorkflow(WORKFLOWNAME, workflowArgs, context, identity);
					logger.trace("Workflow launched");
					logger.trace("End DeleteAccountJob.call");
					logger.trace("return workflowKey: "+workflowKey);


					return workflowKey;
				} else {
					return null;
				}
			}
			return null;
		} catch (Exception e){
			throw new Exception(e);
		} finally{
			SailPointFactory.releaseContext(context);
		}

	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForAccountDeletion(Identity identity, String workflowKey, List accountsToDelete) {
		Map workflowArgs = new HashMap();
        
		workflowArgs.put("identityName", identity.getName());
		workflowArgs.put("workflowKey", workflowKey);
		workflowArgs.put("deleteListLinks", accountsToDelete);
		if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);

		return workflowArgs;
	}
	
	
	
	private static List<Link> getFunctionalAccounts(Identity identity, String applicationName) {
		logger.debug("Entered getFunctionalAccounts");
		List<Link> linkList = identity.getLinks();
		List<Link> removeLinkList = new ArrayList();
		logger.trace("linkList: "+linkList.toString());
		if(linkList!=null){
			for (Link link : linkList) {
				if(link.getApplicationName().equals(applicationName)){
					if (null != link.getAttribute("employeeType") && link.getAttribute("employeeType").equals("2")){
						removeLinkList.add(link);
					}
				}
			}
		}
		return removeLinkList;
	}


	private static Link getPersonalAccount(Identity identity, String applicationName) {
		logger.debug("Entered getPersonalAccount");
		List<Link> linkList = identity.getLinks();
		logger.debug("linkList: "+linkList.toString());
		if(linkList!=null){
			for (Link link : linkList) {
				if(link.getApplicationName().equals(applicationName)){
					if (null != link.getAttribute("employeeType") && link.getAttribute("employeeType").equals("4")){
						Link pAccount = link;
						return pAccount;
					}
				}
			}
		}
		return null;
	}


}
