package com.philips.custom.tools.launchwftask;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Attributes;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskResult.CompletionStatus;
import sailpoint.object.TaskSchedule;
import sailpoint.task.AbstractTaskExecutor;


public class IdentityEventProcessor extends AbstractTaskExecutor{

	//get a logger and do plenty of it
	private Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");	


	@Override
	public void execute(SailPointContext context, TaskSchedule taskSchedule,
			TaskResult taskResult, Attributes<String, Object> arguments) throws Exception {
		
		Map<String, Integer> resultMap = new HashMap<String, Integer>();

		try{

			logger.debug("Enter IdentityEventProcessor.execute");


			int numberOfThreads;
			try{
				numberOfThreads=Integer.parseInt(arguments.get("numberThreads").toString());
				logger.trace("numberThreads from GUI: "+numberOfThreads);
			}catch(Exception e){
				numberOfThreads=5;
				logger.trace("No numberThreads defined in GUI, default to 5");
			}

			ThreadPoolExecutor threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(numberOfThreads);
			CompletionService executorCreate = new ExecutorCompletionService(threadPool);
			Set<Future<String>> futuresCreate = new HashSet<Future<String>>();
			
			//ExecutorService executorCreate = Executors.newFixedThreadPool(numberOfThreads);
			//ConcurrentLinkedQueue<Future<?>> futuresCreate = new ConcurrentLinkedQueue<Future<?>>(); //List with return values


			logger.trace("Input arguments: "+arguments.toString());
			
			String filterString = null;
			
			if(arguments.containsKey("filter")){
				filterString = (String) arguments.get("filter");
				if(logger.isDebugEnabled())logger.debug("Got additional Filter : " +filterString);
				
				if(filterString.contains("(") || filterString.contains(")")){
					throw new Exception("Only simple filters are supported for filter " +filterString);
				}
				
				int splitlength = filterString.split(" (?=(([^'\"]*['\"]){2})*[^'\"]*$)").length;
				
				if(splitlength != 3 && splitlength != 7 && splitlength != 11 && splitlength != 15 && splitlength != 19 && splitlength != 23){
					throw new Exception("This does not apear to be a valid Filter : " +filterString);
				}
			}

			if(arguments.containsKey("activateIdentities")){
				if(Boolean.parseBoolean(arguments.get("activateIdentities").toString())==true){
					new ActivateWorker(context).process(context, executorCreate, futuresCreate, resultMap, numberOfThreads, filterString);			
				}
			}
			if(arguments.containsKey("disableDormantAccounts")){
				if(Boolean.parseBoolean(arguments.get("disableDormantAccounts").toString())==true){
					new DisableDormantAccountWorker(context).process(context, executorCreate, futuresCreate, resultMap, numberOfThreads, filterString);			
				}
			}
			if(arguments.containsKey("internalLeaver")){
				if(Boolean.parseBoolean(arguments.get("internalLeaver").toString())==true){
					new InternalLeaverWorker(context).process(context, executorCreate, futuresCreate, resultMap, numberOfThreads, filterString);			
				}
			}
			if(arguments.containsKey("passwordExpiry")){
				if(Boolean.parseBoolean(arguments.get("passwordExpiry").toString())==true){
					new PasswordExpiryWorker().process(context, executorCreate, futuresCreate, resultMap, numberOfThreads, filterString);			
				}
			}
			if(arguments.containsKey("partnerLeaver")){
				if(Boolean.parseBoolean(arguments.get("partnerLeaver").toString())==true){
					new PartnerLeaverWorker().process(context, executorCreate, futuresCreate, resultMap, numberOfThreads, filterString);			
				}
			}
			if(arguments.containsKey("deleteAccounts")){
				if(Boolean.parseBoolean(arguments.get("deleteAccounts").toString())==true){
					new DeleteAccountWorker(context).process(context, executorCreate, futuresCreate, resultMap, numberOfThreads, filterString);			
				}
			}
			if(arguments.containsKey("deleteMailboxes")){
				if(Boolean.parseBoolean(arguments.get("deleteMailboxes").toString())==true){
					new DeleteMailboxWorker(context).process(context, executorCreate, futuresCreate, resultMap, numberOfThreads, filterString);			
				}
			}
			if(arguments.containsKey("deleteIdentity")){
				if(Boolean.parseBoolean(arguments.get("deleteIdentity").toString())==true){
					new DeleteIdentityWorker(context).process(context, executorCreate, futuresCreate, resultMap, numberOfThreads, filterString);			
				}
			}




			//Wait for it to finish and count how often workflow has been launched
			
			logger.trace("Waiting for shutdown  : " );
			
			
			logger.trace("Finishing  : " +resultMap);

			int counter;
			logger.debug("Size of Futures : " +futuresCreate.size());

			while(futuresCreate.size()>0){
				
				String workflowKey="";

				Future completedFuture = executorCreate.take();

				futuresCreate.remove(completedFuture);

				try{
					workflowKey = (String) completedFuture.get();
				}catch(Exception con){
					logger.error("Exception will try again " +stack2string(con));
					Thread.sleep(10);
					try{
						workflowKey = (String) completedFuture.get();
					}catch(Exception con1){
						logger.error("Giving up on that one " +stack2string(con1));
					}
						
				}


				if(null != workflowKey){
					if(workflowKey!="" && resultMap.containsKey(workflowKey)){
						counter=resultMap.get(workflowKey);
						if(logger.isDebugEnabled()) logger.trace("updating resultMap " +workflowKey +" : "+counter);
						resultMap.put(workflowKey, ++counter);
					}else if(workflowKey!="" && !resultMap.containsKey(workflowKey)){
						if(logger.isDebugEnabled()) logger.trace("initiating resultMap : " +workflowKey); 
						resultMap.put(workflowKey, 1);
					}
				}
			}

			logger.trace("resultMap: "+resultMap.toString());

			threadPool.shutdown();

			//return result
			//if there is no result or the result is "" because WF has been launched already
			if(resultMap.isEmpty()){
				taskResult.addMessage("No Workflows have been launched...");
			}else{
				for (Map.Entry<String, Integer> entry : resultMap.entrySet()){
					taskResult.addMessage(entry.getKey()+": "+entry.getValue());
					logger.trace("resultMap entry: "+entry.toString());
				}	
			}


			taskResult.setCompletionStatus(CompletionStatus.Success);

			logger.debug("End IdentityEventProcessor");
		} catch (Exception e){
			logger.error(stack2string(e));
			throw new Exception(e);
		}finally{
			synchronized(resultMap){
				resultMap.notify();
            }
		}
	}



	@Override
	public boolean terminate() {
		// TODO Auto-generated method stub
		return false;
	}
	
	private String stack2string(Exception e) { 

        try { 

            StringWriter sw = new StringWriter(); 
            PrintWriter pw = new PrintWriter(sw); 
            e.printStackTrace(pw); 

            return "------\r\n" + sw.toString() + "------\r\n"; 

        } 
        catch(Exception e2) { 
            return "bad stack2string"; 
        } 
    }
}
