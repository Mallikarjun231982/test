package com.philips.custom.tools.launchwftask;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;
import sailpoint.object.Link;

public class PartnerLeaverJob implements Job {
	
	private static final String WORKFLOWNAME_SEND_MAILS="Philips Dynamic Send Emails Sub";
	private static final String WORKFLOWNAME_ACTIVATE_DEACTIVATE="Philips Activate DeActivate";
	
	private String id;
	private long daysToExpiration;
	private SailPointContext context;
	private Identity identity;
	private Date endDate;
	private String attributeKey;
	private int daysInPast;
	private String workflowKey;
	private String applicationName;
	
	private static Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	
	public PartnerLeaverJob(String id, String attributeKey, String workflowKey, int daysInPast, String applicationName) {
		this.id=id;
		this.attributeKey=attributeKey;
		this.daysInPast=daysInPast;
		this.workflowKey=workflowKey;
		this.applicationName=applicationName;
		
	}


	@SuppressWarnings("rawtypes")
	@Override
	public String call() throws Exception {
		logger.debug("Entered PartnerLeaverJob");
		logger.trace("creating context...");

		try{
			context = SailPointFactory.createContext("PartnerLeaverJob");

			identity=context.getObjectById(Identity.class,id);
			endDate = (Date)identity.getAttribute(attributeKey);
			daysToExpiration = 1+TimeUnit.DAYS.convert(endDate.getTime() - new Date().getTime(), TimeUnit.MILLISECONDS);
			logger.trace("identity: "+identity.getDisplayName());
			logger.trace("endDate: "+endDate);
			logger.trace("daysToExpiration: "+daysToExpiration);

			//Disable the check for legal Hold
			
			//String getLegaHold = context.decrypt((String) identity.getAttribute("legalHold"));

			//logger.debug("LegalHold : " +getLegaHold);

			//if(null == getLegaHold || (null != getLegaHold && getLegaHold.toLowerCase().equals("false"))){


				if (WorkflowLauncher.workflowAlreadyLaunched(identity, workflowKey,endDate,daysInPast)==true){

					return "Workflow already launched";
				}

				logger.debug("## workflowKey : " +workflowKey);

				if(!workflowKey.equals("Partner_Leaver_Deactivate")){
					Map workflowArgsPartnerNotification = getWorkflowArgsForPartnerNotification(identity, daysToExpiration, workflowKey, applicationName);
					WorkflowLauncher.launchWorkflow(WORKFLOWNAME_SEND_MAILS, workflowArgsPartnerNotification, context, identity);
					logger.trace("workflowArgsPartnerNotification: "+workflowArgsPartnerNotification.toString());

					if(workflowKey.equals("Partner_Leaver_Notification_14_days")){
						Map workflowArgsManagerNotification = getWorkflowArgsForManagerNotification(identity, daysToExpiration, workflowKey, applicationName);
						WorkflowLauncher.launchWorkflow(WORKFLOWNAME_SEND_MAILS, workflowArgsManagerNotification, context, identity);
						logger.trace("workflowArgsManagerNotification: "+workflowArgsManagerNotification.toString());
					}

				}else{
					Map workflowArgsDeactivation = getWorkflowArgsForPartnerLeaverAccountDeactivation(identity, workflowKey);
					WorkflowLauncher.launchWorkflow(WORKFLOWNAME_ACTIVATE_DEACTIVATE, workflowArgsDeactivation, context, identity);
					logger.trace("workflowArgs: "+workflowArgsDeactivation.toString());
				}


				return workflowKey;
			//}
			//return null;
		}catch(Exception e){
			throw new Exception(e);
		}finally{
			logger.trace("releasing context...");
			SailPointFactory.releaseContext(context);
		}
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForManagerNotification(Identity identity2,
			long daysToExpiration2, String workflowKey2, String applicationName2) {
									logger.trace("Entered PartnerLeaverJob.getWorkflowArgsForManagerNotification");
		
		DateFormat emailDateFormat = new SimpleDateFormat("dd MMM yyyy");
        
	    Map workflowArgs = new HashMap();
	    
	    List emailArgList = new ArrayList();
	    
	    Link personalAccount = getPersonalAccount(identity, applicationName);
									logger.trace("personalAccount: "+personalAccount);
	    
	    /*emailArgsManager
	     * Template: Partner Leaver Manager Notification
	     *  $emailArgs.toDisplayName
			$emailArgs.partnerEndDate
			$emailArgs.username
			$emailArgs.emailaddress
			$emailArgs.companyname
			$emailArgs.invitationreason
			$emailArgs.philipsaccount
			$emailArgs.domainname
			$emailArgs.joindate
			$emailArgs.partnerDisplayName
	     * 
	     */
	    Map emailArgsManager = new HashMap();
	    
	    emailArgsManager.put("emailTemplate", "Partner Leaver Manager Notification");
	    
	    try{
	    emailArgsManager.put("to", identity.getManager().getEmail());
	    emailArgsManager.put("toDisplayName", identity.getManager().getDisplayableName());
	    }catch(Exception e){
	    	logger.debug("No manager assigned!");
	    }
	    
	    emailArgsManager.put("userType", "Manager");
	    emailArgsManager.put("partnerEndDate", emailDateFormat.format(identity.getAttribute("terminationDate")));
	    emailArgsManager.put("partnerDisplayName", identity.getDisplayableName());
	    emailArgsManager.put("username", identity.getName());
	    emailArgsManager.put("emailaddress", identity.getAttribute("partnerUniqueMail"));
	    emailArgsManager.put("companyname", identity.getAttribute("externalCompanyName"));
	    emailArgsManager.put("invitationreason", identity.getAttribute("invitationReason"));
	    emailArgsManager.put("joindate", identity.getAttribute("contractStartDate"));
	    //TODO: find domain name attribute
	    if(null != personalAccount){
	    	//emailArgsManager.put("philipsaccount", personalAccount);
	    	String dn = (String) personalAccount.getAttribute("distinguishedName");
			emailArgsManager.put("philipsaccount", dn.subSequence(dn.toUpperCase().indexOf("CN=")+3, dn.indexOf(",")));
	    	emailArgsManager.put("domainname", dn.subSequence(dn.toUpperCase().indexOf("DC=")+3, dn.indexOf(",", dn.toUpperCase().indexOf("DC=")+3)));
	    }else{
	    	emailArgsManager.put("philipsaccount", "");
	    	emailArgsManager.put("domainname","");
	    												logger.debug("No personalAccount found!");
	    }
	    

	    emailArgList.add(emailArgsManager);
	    
	    workflowArgs.put("emailArgList", emailArgList);
	    workflowArgs.put("identityName", identity.getName());
	    workflowArgs.put("workflowKey", workflowKey);
	    if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);
	    
		return workflowArgs;

	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForPartnerLeaverAccountDeactivation(Identity identity, String workflowKey) {
		Map workflowArgs = new HashMap();
        
		workflowArgs.put("identity", identity.getName());
		workflowArgs.put("action", "deactivate");
		workflowArgs.put("deactivateAccounts", "true");
		workflowArgs.put("workflowKey", workflowKey);
		if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);

		return workflowArgs;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Map getWorkflowArgsForPartnerNotification(Identity identity, long daysToExpiration, String workflowKey, String applicationName){
												logger.trace("Entered PartnerLeaverJob.getWorkflowArgsForPartnerNotification");
		DateFormat emailDateFormat = new SimpleDateFormat("dd MMM yyyy");
	    Map workflowArgs = new HashMap();
	    List emailArgList = new ArrayList();
		List<Link> fAccountList = getFunctionalAccounts(identity, applicationName);
												logger.trace("fAccountList: "+fAccountList);
		String fAccountString = getfAccountString(fAccountList);
												logger.trace("fAccountString: "+fAccountString);
		Link personalAccount = getPersonalAccount(identity, applicationName);	
												logger.trace("personalAccount: "+personalAccount);
	    
	    
	    /*emailArgsPartner
	     * Template: Partner Leaver Notification
	     *  $emailArgs.toDisplayName
			$emailArgs.partnerEndDate /expiration date
			$emailArgs.philipsaccount
			$emailArgs.invitationreason
			$emailArgs.functionalaccounts
			$emailArgs.pimmanager
	     */
	    
	    Map emailArgsPartner = new HashMap();
	    
	    emailArgsPartner.put("emailTemplate", "Partner Leaver Notification");
	    
	    emailArgsPartner.put("to", identity.getAttribute("partnerUniqueMail"));
	    emailArgsPartner.put("toDisplayName", identity.getDisplayableName());
	    emailArgsPartner.put("userType", "Partner");
	    emailArgsPartner.put("partnerEndDate", emailDateFormat.format(identity.getAttribute("terminationDate")));
	    emailArgsPartner.put("invitationreason", identity.getAttribute("invitationReason"));
	    emailArgsPartner.put("functionalaccounts", fAccountString);
	    if(null != personalAccount){
	    		//emailArgsPartner.put("philipsaccount", personalAccount.toString());
				String dn = (String) personalAccount.getAttribute("distinguishedName");
				emailArgsPartner.put("philipsaccount", dn.subSequence(dn.toUpperCase().indexOf("CN=")+3, dn.indexOf(",")));
	    }else{
	    	emailArgsPartner.put("philipsaccount", "---");
	    													logger.debug("No personalAccount found!");
	    }
	    try{
	    	emailArgsPartner.put("pimmanager", identity.getManager().getDisplayableName());
	    }catch(Exception e){
	    													logger.debug("No manager assigned!");
	    }

	    emailArgList.add(emailArgsPartner);

	    workflowArgs.put("emailArgList", emailArgList);
	    workflowArgs.put("identityName", identity.getName());
	    workflowArgs.put("workflowKey", workflowKey);
	    if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);
	    
		return workflowArgs;
		}
	
	
	private static Link getPersonalAccount(Identity identity, String applicationName) {
		logger.debug("Entered getPersonalAccount");
		List<Link> linkList = identity.getLinks();
		logger.debug("linkList: "+linkList.toString());
		if(linkList!=null){
			for (Link link : linkList) {
				if(link.getApplicationName().equals(applicationName)){
					if (null != link.getAttribute("employeeType") && link.getAttribute("employeeType").equals("4")){
						Link pAccount = link;
						return pAccount;
					}
				}
			}
		}
		return null;
	}
	
	private static String getfAccountString(List<Link> fAccountList) {
		logger.debug("Entered getfAccountString");
		String fAccountString="";
		List<String> fAStrings=new ArrayList<String>();
		for (Link link : fAccountList) {
			fAStrings.add(link.getApplicationName()+": "+link.getDisplayableName());
		}
		fAccountString=fAStrings.toString();
		logger.trace("fAccountString: "+fAccountString);
		return fAccountString;
	}


	private static List<Link> getFunctionalAccounts(Identity identity, String applicationName) {
		logger.debug("Entered getFunctionalAccounts");
		List<Link> linkList = identity.getLinks();
		List<Link> removeLinkList = new ArrayList();
		logger.trace("linkList: "+linkList.toString());
		if(linkList!=null){
			for (Link link : linkList) {
				if(link.getApplicationName().equals(applicationName)){
					if (null != link.getAttribute("employeeType") && link.getAttribute("employeeType").equals("2")){
						removeLinkList.add(link);
					}
				}
			}
		}
		return removeLinkList;
	}


}
