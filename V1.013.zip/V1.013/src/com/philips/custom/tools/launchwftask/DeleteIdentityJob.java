package com.philips.custom.tools.launchwftask;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;

public class DeleteIdentityJob implements Job {
	
	private static final String WORKFLOWNAME="Philips Leaver Delete Identity";
	
	private String id;
	private SailPointContext context;
	private Identity identity;
	private Date terminationDate;
	private String workflowKey;
	
	
	private static Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	
	public DeleteIdentityJob(String id, String workflowKey) {
		this.id=id;
		this.workflowKey=workflowKey;
	}


	@SuppressWarnings("rawtypes")
	@Override
	public String call() throws Exception {
		logger.debug("Entered DeleteIdentityJob");

		logger.trace("creating context...");
		context = SailPointFactory.createContext("DeleteIdentityJob");
		
		try{

		identity=context.getObjectById(Identity.class,id);

		String getLegaHold = context.decrypt((String) identity.getAttribute("legalHold"));
		
		logger.debug("LegalHold : " +getLegaHold);

		if(null == getLegaHold || (null != getLegaHold && getLegaHold.toLowerCase().equals("false"))){

			terminationDate = (Date)identity.getAttribute("terminationDate");
			logger.trace("identity: "+identity.getDisplayName());
			logger.trace("terminationDate: "+terminationDate);

			Map workflowArgs=null;

			workflowArgs = getWorkflowArgsForIdentityDeletion(identity, workflowKey);
			logger.trace("workflowArgs: "+workflowArgs.toString());
			WorkflowLauncher.launchWorkflow(WORKFLOWNAME, workflowArgs, context, identity);
			logger.trace("Workflow launched");
			logger.trace("End DeleteIdentityJob.call");
			logger.trace("return workflowKey: "+workflowKey);

			logger.trace("releasing context...");
			return workflowKey;
		}
		
		return null;
		
		} catch(Exception e){
			throw new Exception(e);
		}finally{
			SailPointFactory.releaseContext(context);
		}

	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForIdentityDeletion(Identity identity, String workflowKey) {
		Map workflowArgs = new HashMap();
        
		workflowArgs.put("identityName", identity.getName());
		if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);

		return workflowArgs;
	}


}
