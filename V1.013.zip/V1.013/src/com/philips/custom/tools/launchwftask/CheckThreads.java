package com.philips.custom.tools.launchwftask;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Future;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.api.TaskManager;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;
import sailpoint.object.Request;
import sailpoint.object.TaskDefinition;
import sailpoint.task.Housekeeper;
import sailpoint.tools.GeneralException;

public class CheckThreads {
	
	public static void checkThreads(SailPointContext context, Collection<Future<?>> futuresCreate,
			 int numberOfThreads, Map<String, Integer> resultMap, Log logger) throws Exception {

		int maxWaitingRequests = 100;
		boolean wait = true;
		
		if(logger.isDebugEnabled()) logger.debug("checkThreads " +resultMap);
		
		Thread.sleep(10);
		
		List<Future<?>> cloneCollection = (List<Future<?>>) new ArrayList(futuresCreate).clone();
		
		List<Future<?>> removeCollection = new ArrayList();

		do{
			wait=false;
			int counter = 0;
			String workflowKey="";
			
			Iterator<Future<?>> futureIt =cloneCollection.iterator();
			while (futureIt.hasNext()){
				Future<?> future = futureIt.next();
				if(future.isDone()){
					if(null != future.get()){
						if(logger.isDebugEnabled()) logger.trace("future get: "+future.get().toString()); 
						workflowKey=future.get().toString();
					} 
					synchronized (resultMap) {
						if(workflowKey!="" && resultMap.containsKey(workflowKey)){
							int workflowKeyCounter=resultMap.get(workflowKey);
							if(logger.isDebugEnabled()) logger.trace("updating resultMap: "+workflowKeyCounter); 
							resultMap.put(workflowKey, ++workflowKeyCounter);
						}else if(workflowKey!="" && !resultMap.containsKey(workflowKey)){
							if(logger.isDebugEnabled()) logger.trace("initiating resultMap: "); 
							resultMap.put(workflowKey, 1);
						}
					}
					removeCollection.add(future);
				} else {
					counter ++;
				}
			}
			
			futuresCreate.removeAll(removeCollection);
			
			if(logger.isDebugEnabled()) logger.debug("counter " +counter +" threads " +numberOfThreads);
			

			if(counter >= numberOfThreads){
				synchronized (resultMap) {
					if(logger.isDebugEnabled()) logger.debug("wait");
					wait=true;
					resultMap.wait(1000,500);
					//launchPerformMaintenance(context, logger);
				}
			}
			
			QueryOptions qo = new QueryOptions();
			qo.addFilter(Filter.notnull("id"));
			
			/*
			Disabling checking the limit of request objects
			
			int requestNumber = context.countObjects(Request.class, qo);
			
			if(requestNumber > maxWaitingRequests){
				
				synchronized (resultMap) {
					if(logger.isDebugEnabled()) logger.debug("wait for requests " +requestNumber);
					wait=true;
					launchPerformMaintenance(context, logger);
					if(logger.isDebugEnabled()) logger.debug("sleeping 10 Sec" );
					resultMap.wait(10000,500);
				}
			}
			*/

			
		} while(wait);

	}

	private static void launchPerformMaintenance(SailPointContext context, Log logger) {
		TaskManager tm = new TaskManager(context);
		
		tm.setLauncher("spadmin");
		
		try{
		
		TaskDefinition task = context.getObjectByName(TaskDefinition.class, "Philips PIEP Maintenence");
		
		if(null != task){
			tm.run(task, null);	
		}
		} catch(Exception e){
			logger.error(stack2string(e));
		}

	}
	
	private static String stack2string(Exception e) {
		try {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			return "------\r\n" + sw.toString() + "------\r\n";
		} catch (Exception e2) {
			return "bad stack2string";
		}
	}

}
