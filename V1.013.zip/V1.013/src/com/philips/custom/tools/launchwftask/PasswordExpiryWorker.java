package com.philips.custom.tools.launchwftask;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Link;
import sailpoint.object.QueryOptions;



public class PasswordExpiryWorker implements Worker {
	
	private Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	private String applicationName = "CODE1";
	private String attributeKey="passwordExpiry";
	private String workflowKeyPrefix = "PasswordExpiry";
	
	private Integer from_NumberOfDays;
	private Integer till_NumberOfDays;
	

	/**
	 * Send password expiry notification mails 14, 7, 5, 3, 2 and 1 days before expiration date
	 */
	@Override
	public void process(SailPointContext context, CompletionService executorCreate, Set<Future<String>> futuresCreate, Map<String, Integer> resultMap, int numberOfThreads, String filterString) throws Exception {		
		
		logger.debug("Entered PasswordExpiryWorker");
		
		Custom custom = context.getObjectByName(Custom.class,"Philips Launch Workflow Task Parameters");
		if(custom == null){
			logger.trace("Object \"Philips Launch Workflow Task Parameters\" not found");
		}

		Iterator<Object[]> iter;
		
		String workflowKey = workflowKeyPrefix +"14";
		
		Map<String, String> wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);
		
		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		

		iter=queryLinks(context, attributeKey, from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey,resultMap, numberOfThreads, logger);}
		
		workflowKey = workflowKeyPrefix +"7";
		
		wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);
		
		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		
		iter=queryLinks(context, attributeKey, from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey, resultMap, numberOfThreads, logger);}
		
		workflowKey = workflowKeyPrefix +"5";
		
		wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);
		
		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		
		iter=queryLinks(context, attributeKey, from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey, resultMap, numberOfThreads, logger);}
		
		workflowKey = workflowKeyPrefix +"3";
		
		wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);
		
		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		
		iter=queryLinks(context, attributeKey, from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey, resultMap, numberOfThreads, logger);}
		
		workflowKey = workflowKeyPrefix +"2";
		
		wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);
		
		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		
		iter=queryLinks(context, attributeKey, from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey, resultMap, numberOfThreads, logger);}
		
		workflowKey = workflowKeyPrefix +"1";
		
		wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);
		
		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		
	    iter=queryLinks(context, attributeKey, from_NumberOfDays,till_NumberOfDays, filterString);
	    if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey, resultMap, numberOfThreads, logger);}

	}
	

	private void startJobs(SailPointContext context,Set<Future<String>> futuresCreate,
			CompletionService executorCreate, Iterator<Object[]> iter, String workflowKey, Map<String, Integer> resultMap, int numberOfThreads, Log logger) throws Exception {
		logger.debug("Entered method startProcessPasswordExpiry");
		
		while (iter.hasNext()){
			//CheckThreads.checkThreads(context,futuresCreate, numberOfThreads, resultMap, logger);
			Object[] obj = (Object[]) iter.next();
			logger.trace("Identity passed on to Password Expiry Job: "+obj[0]);
			String id=obj[0].toString();
			futuresCreate.add(executorCreate.submit(new PasswordExpiryJob(id,attributeKey,workflowKey,14)));
		}

	}
	
	Iterator<Object[]> queryLinks(SailPointContext context,String dateAttribute, Integer i1, Integer i2, String filterString) throws Exception {
		logger.debug("Entered method queryIdentities");
		//get first date and second date of time interval
		
		Date d1 = null;
		Date d2 = null;
		
		if(null != i1){
			Calendar cal1 = Calendar.getInstance();
			cal1.setTime(cal1.getTime()); // compute End of the day for the timestamp
			cal1.set(Calendar.HOUR_OF_DAY, 23);
			cal1.set(Calendar.MINUTE, 59);
			cal1.set(Calendar.SECOND, 59);
			cal1.set(Calendar.MILLISECOND, 999);
			cal1.add(Calendar.DATE, i1); //today+i1
			d1 = cal1.getTime();
			logger.trace("First Date: "+d1 +" " +d1.getTime());
		}

		if(null != i2){
			Calendar cal2 = Calendar.getInstance();
			cal2.setTime(cal2.getTime()); // compute start of the day for the timestamp
			cal2.set(Calendar.HOUR_OF_DAY, 23);
			cal2.set(Calendar.MINUTE, 59);
			cal2.set(Calendar.SECOND, 59);
			cal2.set(Calendar.MILLISECOND, 999);
			cal2.add(Calendar.DATE, i2+1); //today+i2
			d2 = cal2.getTime();
			logger.trace("Second Date: "+d2 +" " +d2.getTime());
		}
		
		QueryOptions qo = new QueryOptions();
		Iterator<Object[]> iter; 
		if(null != d1)
			qo.add(Filter.le(dateAttribute, d1));
		if((null != d2))
			qo.add(Filter.ge(dateAttribute, d2)); 	
		//qo.add(Filter.eq("application.name",applicationName)); PH Don't think we need this filter or at least not for now
		qo.addFilter(Filter.and(Filter.eq("application.name",applicationName),Filter.ne("linkDisabled","true")));
		
		if(null != filterString){
    		String[] filterElements = filterString.split(" (?=(([^'\"]*['\"]){2})*[^'\"]*$)");
			
			filterString="";
			
			
			for(int i=4; i<filterElements.length+4; i++){
				if(i % 4 == 0){
					filterString = filterString +" identity." +filterElements[i-4];
				} else {
					filterString = filterString +" " +filterElements[i-4];
				}
			}
			
			if(logger.isDebugEnabled())logger.debug("newFilterString : " +filterString);
			qo.add(Filter.compile(filterString));
    	}
		
		if(logger.isDebugEnabled())logger.debug("Filter Query : " +qo.getQuery());
		
		iter = context.search(Link.class, qo, "id");
		
		return iter;
	}
	
}