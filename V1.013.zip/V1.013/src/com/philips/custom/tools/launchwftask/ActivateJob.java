package com.philips.custom.tools.launchwftask;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;

public class ActivateJob implements Job {
	
	//private static final String WORKFLOWNAME_SEND_MAILS="Philips Dynamic Send Emails Sub";
	private static final String WORKFLOWNAME_ACTIVATE_DEACTIVATE="Philips Activate DeActivate";
	
	private String id;
	//private long daysToExpiration;
	private SailPointContext context;
	private Identity identity;
	private Date startDate;
	private String attributeKey;
	private String workflowKey;
	
	private static Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	
	public ActivateJob(String id, String attributeKey, String workflowKey) {
		this.id=id;
		this.attributeKey=attributeKey;
		this.workflowKey=workflowKey;
		
	}


	@SuppressWarnings("rawtypes")
	@Override
	public String call() throws Exception {
		logger.debug("Entered ActivateJob");
										logger.trace("creating context..");
		context = SailPointFactory.createContext("ActivateJob");
		
		identity=context.getObjectById(Identity.class,id);
		startDate = (Date)identity.getAttribute(attributeKey);
										logger.trace("identity: "+identity.getDisplayName());
										logger.trace("startDate: "+startDate);
										
		Map workflowArgs=null;
		/*
		if(identity.getAttribute("employeeType").toString().contains("Partner")){
										logger.trace("Identity is a partner");
			workflowArgs = getWorkflowArgsForPartnerWelcomeMail(identity, daysToExpiration, workflowKey);
			WorkflowLauncher.launchWorkflow(WORKFLOWNAME_SEND_MAILS, workflowArgs, context, identity);
		}
		*/
		workflowArgs = getWorkflowArgsForAccountDeactivation(identity, workflowKey);
										logger.trace("workflowArgs: "+workflowArgs.toString());
		WorkflowLauncher.launchWorkflow(WORKFLOWNAME_ACTIVATE_DEACTIVATE, workflowArgs, context, identity);
										logger.trace("releasing context...");
		SailPointFactory.releaseContext(context);									
		return workflowKey;

	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForAccountDeactivation(Identity identity, String workflowKey) {
		Map workflowArgs = new HashMap();
        
		workflowArgs.put("identity", identity.getName());
		workflowArgs.put("action", "activate");
		workflowArgs.put("activateAccounts", "true");
		workflowArgs.put("workflowKey", workflowKey);
				
		if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);


		return workflowArgs;
	}

/*
	public static Map getWorkflowArgsForPartnerWelcomeMail(Identity identity, long daysToExpiration, String workflowKey){

		DateFormat emailDateFormat = new SimpleDateFormat("dd MMM yyyy");
        
	    Map workflowArgs = new HashMap();
	    List emailArgList = new ArrayList();
	    

	    Map emailArgsPartner = new HashMap();
	    emailArgsPartner.put("emailTemplate", "Partner Welcome");
	    emailArgsPartner.put("to", identity.getAttribute("partnerUniqueMail"));
	    emailArgsPartner.put("toDisplayName", identity.getDisplayableName());
	    emailArgList.add(emailArgsPartner);

		return workflowArgs;
		}
*/

}
