package com.philips.custom.tools.launchwftask;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Custom;
import sailpoint.object.Identity;
import sailpoint.object.Link;

public class DeleteMailboxJob implements Job {
	
	private static final String WORKFLOWNAME="Philips Delete Mail";
	
	private String id;
	private SailPointContext context;
	private Identity identity;
	private Link link;
	private String workflowKey;
	private String applicationName;
	
	
	private static Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	
	public DeleteMailboxJob(String id, String applicationName, String workflowKey) {
		this.id=id;
		this.workflowKey=workflowKey;
		this.applicationName=applicationName;
	}


	@SuppressWarnings("rawtypes")
	@Override
	public String call() throws Exception {
		logger.debug("Entered DeleteMailboxJob");
		logger.trace("creating context...");
		context = SailPointFactory.createContext("DeleteIdentityJob");
		link=context.getObjectById(Link.class,id);
		identity=link.getIdentity();

		if(null != link.getAttribute("mail") && !"".equals(null != link.getAttribute("mail"))){
			
			//Delete the tempoary mailAttribute Custom Object
			Custom storedMailAttr = context.getObjectByName(Custom.class, "keepMailAttr-" +link.getAttribute("objectguid"));
			
			if(null != storedMailAttr){
				context.removeObject(storedMailAttr);
				context.commitTransaction();
			}

			Map workflowArgs=getWorkflowArgsForIdentityDeletion(identity, link, workflowKey);
			logger.trace("workflowArgs: "+workflowArgs.toString());
			WorkflowLauncher.launchWorkflow(WORKFLOWNAME, workflowArgs, context, identity);
			logger.trace("Workflow launched");
			logger.trace("End DeleteMailboxJob.call");
			logger.trace("return workflowKey: "+workflowKey);
			logger.trace("releasing context...");

			SailPointFactory.releaseContext(context);
			return workflowKey;

		} else {
			return null;
		}

	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForIdentityDeletion(Identity identity, Link link, String workflowKey) {
		Map workflowArgs = new HashMap();
        
        workflowArgs.put("identityName", identity.getName()); 
        workflowArgs.put("nativeIdentity", link.getNativeIdentity());
        workflowArgs.put("applicationName", applicationName);
		if(logger.isDebugEnabled())
            workflowArgs.put("trace", true);
		else
            workflowArgs.put("trace", false);

		return workflowArgs;
	}


}
