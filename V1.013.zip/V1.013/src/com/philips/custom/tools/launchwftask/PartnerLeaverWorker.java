package com.philips.custom.tools.launchwftask;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.QueryOptions;



public class PartnerLeaverWorker implements Worker {

	private Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	private String workflowKeyPrefix = "Partner_Leaver";
	private Integer from_NumberOfDays;
	private Integer till_NumberOfDays;
	private String applicationName;

	/**  1.	IDM evaluates the �Termination date� attribute:
					a.	If Termination date is in 28 days, the process continues at Alternate Course  [a1]	
					b.	If Termination date is in 14 days, the process continues at Alternate Course  [a2]	
					c.	If Termination date is in 7 days, the process continues at Alternate Course  [a3]	
					d.	If the Termination date is the current date, the process continues at step 2.
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void process(SailPointContext context, CompletionService executorCreate, Set<Future<String>> futuresCreate, Map<String, Integer> resultMap, int numberOfThreads, String filterString) throws Exception {

		logger.debug("Entered PartnerLeaverWorker");

		Custom custom = context.getObjectByName(Custom.class,"Philips Launch Workflow Task Parameters");
		if(custom == null){
			logger.trace("Object \"Philips Launch Workflow Task Parameters\" not found");
		}

		Iterator<Object[]> iter;

		String workflowKey = workflowKeyPrefix +"_Notification_28_days";

		Map<String, String> wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);

		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		applicationName=wfParameters.get("applicationName");

		iter=queryIdentities(context,"terminationDate",from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey,applicationName,resultMap, numberOfThreads, logger);}

		workflowKey = workflowKeyPrefix +"_Notification_14_days";

		wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);

		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		applicationName=wfParameters.get("applicationName");

		iter=queryIdentities(context,"terminationDate",from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey,applicationName, resultMap, numberOfThreads, logger);}

		workflowKey = workflowKeyPrefix +"_Notification_7_days";

		wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);

		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		applicationName=wfParameters.get("applicationName");

		iter=queryIdentities(context,"terminationDate",from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey,applicationName, resultMap, numberOfThreads, logger);}

		workflowKey = workflowKeyPrefix +"_Deactivate";

		wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);

		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;
		applicationName=wfParameters.get("applicationName");

		iter=queryIdentities(context,"terminationDate",from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context,futuresCreate, executorCreate, iter, workflowKey,applicationName, resultMap, numberOfThreads, logger);}

	}


	private static void startJobs(SailPointContext context,Set<Future<String>> futuresCreate,
			CompletionService executorCreate, Iterator<Object[]> iter, String workflowKey, String applicationName, Map<String, Integer> resultMap, int numberOfThreads, Log logger) throws Exception {
		logger.debug("Entered PartnerLeaverWorker.startJobs");

		while (iter.hasNext()){
			//CheckThreads.checkThreads(context, futuresCreate, numberOfThreads, resultMap, logger);
			Object[] obj = (Object[]) iter.next();
			logger.trace("Identity: "+obj[0]);
			String id=obj[0].toString();
			futuresCreate.add(executorCreate.submit(new PartnerLeaverJob(id,"terminationDate",workflowKey,28,applicationName)));
		}

	}


	Iterator<Object[]> queryIdentities(SailPointContext context,String dateAttribute, Integer i1, Integer i2, String filterString) throws Exception {
		logger.debug("Entered method queryIdentities");

		Date d1 = null;
		Date d2 = null;

		if(null != i1){
			//get first date and second date of time interval
			Calendar cal1 = Calendar.getInstance();
			cal1.add(Calendar.DATE, i1); //today+i1
			d1 = cal1.getTime();
			logger.trace("First Date: "+d1);
		}

		if(null != i2){
			Calendar cal2 = Calendar.getInstance();
			cal2.add(Calendar.DATE, i2+1); //today+i2 and +1 because function below is greater or equal but just greater is required
			d2 = cal2.getTime();
			logger.trace("Second Date: "+d2);
		}

		QueryOptions qo = new QueryOptions();
		Iterator<Object[]> iter; 
		if(null != d1)
			qo.add(Filter.le(dateAttribute, d1));
		if(null != d2)
			qo.add(Filter.ge(dateAttribute, d2)); 	
		qo.addFilter(Filter.ignoreCase(Filter.eq("identityStatus","Active")));
		qo.add(Filter.ignoreCase(Filter.like("employeeType", "Partner")));
		
		if(null != filterString)
			qo.add(Filter.compile(filterString));
		
		if(logger.isDebugEnabled())logger.debug("Filter Query : " +qo.getQuery());
		
		iter = context.search(Identity.class, qo, "id");

		return iter;
	}

}