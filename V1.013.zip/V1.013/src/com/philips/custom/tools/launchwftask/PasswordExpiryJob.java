package com.philips.custom.tools.launchwftask;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;
import sailpoint.object.Link;

public class PasswordExpiryJob implements Job {
	
	private static final String WORKFLOWNAME="Philips Dynamic Send Emails Sub";
	
	private String id;
	private long daysToExpiration;
	private SailPointContext context;
	private Identity identity;
	private Link link;
	private Date endDate;
	private String attributeKey;
	private int daysInPast;
	private String workflowKey;
	
	private Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	
	

	public PasswordExpiryJob(String id, String attributeKey, String workflowKey, int daysInPast) {
		this.id=id;
		this.attributeKey=attributeKey;
		this.daysInPast=daysInPast;
		this.workflowKey=workflowKey;
		
	}

	@SuppressWarnings("rawtypes")
	@Override
	public String call() throws Exception {
					logger.debug("Entered PasswordExpiryJob...");
					
					logger.trace("creating context..");
		context = SailPointFactory.createContext("PasswordExpiryJob");

		
		link=context.getObjectById(Link.class,id);
		identity=link.getIdentity();
		
		logger.debug("Identity  Status: " +identity.getAttribute("identityStatus"));
		
		if(null != identity.getAttribute("identityStatus") && identity.getAttribute("identityStatus").toString().toLowerCase().equals("active")){
			
			logger.debug("Got Active Identity : " +identity.getName());
		
		endDate = (Date)link.getAttribute(attributeKey);
		daysToExpiration = 1+TimeUnit.DAYS.convert(endDate.getTime() - new Date().getTime(), TimeUnit.MILLISECONDS);
					logger.trace("identity: "+identity.getDisplayName());
					logger.trace("endDate: "+endDate);
					logger.trace("daysToExpiration: "+daysToExpiration);
										

		if (WorkflowLauncher.workflowAlreadyLaunched(identity, workflowKey,endDate,daysInPast)==true){
					logger.trace("releasing context...");
			SailPointFactory.releaseContext(context);
			return "Workflow already launched";
		}

		
		Map workflowArgs = getWorkflowArgsForPasswordExpiry(identity, daysToExpiration, workflowKey, link);
										logger.trace("workflowArgs: "+workflowArgs.toString());
										
		if(!workflowArgs.isEmpty()) //PH added if in case the workflowArgs is empty
			WorkflowLauncher.launchWorkflow(WORKFLOWNAME, workflowArgs, context, identity);
					logger.trace("releasing context...");
			SailPointFactory.releaseContext(context);
			return workflowKey;
		}else{
					logger.trace("releasing context...");
			SailPointFactory.releaseContext(context);
			return null;
		}
		

	}
	

	/*
	private Date parseDate(String dateAsString) throws ParseException {
		Date d;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

		d = sdf.parse(dateAsString);
		return d;
		
	}
	*/

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map getWorkflowArgsForPasswordExpiry(Identity identity, long daysToExpiration, String workflowKey, Link link) {
		    
		Map workflowArgs = new HashMap();

		List emailArgList = new ArrayList();
		Map emailArgs = new HashMap();

		String email = identity.getEmail();

		if(null == email)
		       email = (String)identity.getAttribute("partnerUniqueMail");

		if(null != email){
		       emailArgs.put("to", email);
		       emailArgs.put("emailTemplate", "Message to Code1 User about password expiration 1d");
		       emailArgs.put("toDisplayName", identity.getDisplayableName());
		       emailArgs.put("philipsaccount", link.getAttribute("sAMAccountName"));
		       emailArgs.put("emailaddress", email);
		       String domain = (String) link.getAttribute("msDS-PrincipalName");
		       if(null != domain && domain.contains("\\")){
		    	   domain = domain.substring(0, domain.indexOf("\\"));
		       }else{
		    	   domain="Philips";
		       }
		       emailArgs.put("dn", domain);
		       emailArgs.put("days", String.valueOf(daysToExpiration));
		       
		       emailArgList.add(emailArgs);
		       
		       workflowArgs.put("emailArgList", emailArgList);
		       workflowArgs.put("identityName", identity.getName());
		       workflowArgs.put("workflowKey", workflowKey);
				if(logger.isDebugEnabled())
		            workflowArgs.put("trace", true);
				else
		            workflowArgs.put("trace", false);
		}

		return workflowArgs;
	}

	

}
