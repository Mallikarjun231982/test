package com.philips.custom.tools.launchwftask;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.commons.logging.Log;

import sailpoint.api.RequestManager;
import sailpoint.api.SailPointContext;
import sailpoint.object.Attributes;
import sailpoint.object.Identity;
import sailpoint.object.Request;
import sailpoint.object.RequestDefinition;
import sailpoint.workflow.StandardWorkflowHandler;

public class WorkflowLauncher {
	
	
	private static Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");
	
	private WorkflowLauncher() {
	//Util
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected static void launchWorkflow(String workflowName, Map workflowArgs, SailPointContext context, Identity identity) throws Exception {
		logger.trace("Entered WorkflowLauncher.launchWorkflow");
		logger.trace("Input: workflowargs: "+workflowArgs+" SailpointContext: "+context+" identity: "+identity);
		String caseName     = "Run '" + workflowName + "' (" +identity.getName()+") from Task ";
	    
	    long launchTime = System.currentTimeMillis() + 1000;  
	    caseName = caseName + "(" + launchTime + ")";
	    
	    // Build out a map of arguments to pass to the Request Scheduler. 
	    Attributes reqArgs = new Attributes();  
	    reqArgs.put(StandardWorkflowHandler.ARG_REQUEST_DEFINITION,  sailpoint.request.WorkflowRequestExecutor.DEFINITION_NAME);  
	    reqArgs.put(sailpoint.workflow.StandardWorkflowHandler.ARG_WORKFLOW,  workflowName);  
	    reqArgs.put(sailpoint.workflow.StandardWorkflowHandler.ARG_REQUEST_NAME,  caseName);  
	    reqArgs.put( "requestName", caseName ); 
	    
	    reqArgs.putAll(workflowArgs); 
	    
	    // Use the Request Launcher to schedule the workflow reqeust.  This requires  
	    // a Request object to store the properties of the request item.  
	    Request req = new Request();  
	    RequestDefinition reqdef = context.getObject(RequestDefinition.class, "Workflow Request");  
	    req.setDefinition(reqdef);  
	    req.setEventDate( new Date( launchTime ) );  
	    req.setOwner(identity);  
	    req.setName(caseName);  
	    req.setAttributes( reqdef, reqArgs );  
	    logger.trace("req: "+req.toString()); 
	    // Schedule the work flow via the request manager.  
	    RequestManager.addRequest(context, req);
	    
	    logger.trace("End WorkflowLauncher.launchWorkflow");
	    
	}
	
	
	@SuppressWarnings("unchecked")
	protected static boolean workflowAlreadyLaunched(Identity identity, String workflowKey, Date endDate, int daysInPast) {
		if(logger.isDebugEnabled()) logger.trace("Entered method workflowAlreadyLaunched identity : " +identity.getName() +" workflowKey : " +workflowKey +" endDate : " +endDate +" daysInPast : " +daysInPast);
		if(identity.getAttribute("workflowsInProgress")!=null){
			Map<String, Object> workflowsInProgress = (Map<String, Object>)identity.getAttribute("workflowsInProgress");
										logger.trace("workflowsInProgress Map: "+workflowsInProgress);
			
			if(workflowsInProgress.containsKey(workflowKey)){
				Date timestampFromLastWFLaunch =(Date)workflowsInProgress.get(workflowKey);				
										logger.trace("timestampFromLastWFLaunch: "+timestampFromLastWFLaunch);

			    Calendar cal = Calendar.getInstance();
				//cal.setTime(endDate);
				cal.add(Calendar.DATE, -daysInPast); 
				Date d = cal.getTime();
				
				if(timestampFromLastWFLaunch.after(d)){ 
				logger.trace("workflow has been launched already");
				return true; 
				}
				
			}

		}
		
		return false;
	}


}
