package com.philips.custom.tools.launchwftask;

import java.util.concurrent.Callable;

public interface Job extends Callable<String> {
		
	public abstract String call() throws Exception;
	
	
	
	

}
