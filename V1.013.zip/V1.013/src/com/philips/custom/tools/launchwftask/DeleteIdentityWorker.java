package com.philips.custom.tools.launchwftask;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.QueryOptions;
import sailpoint.tools.GeneralException;



public class DeleteIdentityWorker implements Worker {

	private Log logger=org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.LaunchWorkflowTask");

	private String workflowKey = "deleteIdentity";
	private Integer from_NumberOfDays;
	private Integer till_NumberOfDays;

	public DeleteIdentityWorker(SailPointContext context) throws GeneralException{
		Custom custom = context.getObjectByName(Custom.class,"Philips Launch Workflow Task Parameters");
		if(custom == null){
			logger.trace("Object \"Philips Launch Workflow Task Parameters\" not found");
		}
		@SuppressWarnings("unchecked")
		Map<String, String> wfParameters = (Map<String, String>) custom.get(workflowKey);
		logger.trace("wfParameters: "+wfParameters);

		from_NumberOfDays= wfParameters.containsKey("from_NumberOfDays") ? Integer.parseInt(wfParameters.get("from_NumberOfDays")) : null;
		till_NumberOfDays= wfParameters.containsKey("till_NumberOfDays") ? Integer.parseInt(wfParameters.get("till_NumberOfDays")) : null;


	}


	/** IDM shall delete the identity if the �Termination Date� was 730 days (2 years) in the past
	 * 
	 */
	@Override
	public void process(SailPointContext context, CompletionService executorCreate, Set<Future<String>> futuresCreate, Map<String, Integer> resultMap, int numberOfThreads, String filterString) throws Exception {

		logger.debug("Entered DeleteIdentityWorker");

		Iterator<Object[]> iter;

		iter=queryIdentities(context,"terminationDate", from_NumberOfDays,till_NumberOfDays, filterString);
		if(iter.hasNext()){startJobs(context, futuresCreate, executorCreate, iter, resultMap, numberOfThreads, logger);}

	}


	private void startJobs(SailPointContext context, Set<Future<String>> futuresCreate,
			CompletionService executorCreate, Iterator<Object[]> iter, Map<String, Integer> resultMap, int numberOfThreads, Log logger) throws Exception {
		logger.debug("Entered DeleteIdentityWorker.startJobs");

		while (iter.hasNext()){
			//CheckThreads.checkThreads(context, futuresCreate, numberOfThreads, resultMap, logger);
			Object[] obj = (Object[]) iter.next();
			logger.trace("Identity: "+obj[0]);
			String id=obj[0].toString();
			futuresCreate.add(executorCreate.submit(new DeleteIdentityJob(id, workflowKey)));
		}

	}


	Iterator<Object[]> queryIdentities(SailPointContext context, String dateAttribute, Integer i1, Integer i2, String filterString) throws Exception {
		logger.debug("Entered DeleteIdentityWorker.queryIdentities");

		Date d1 = null;
		Date d2 = null;

		if(null != i1){
			Calendar cal1 = Calendar.getInstance();
			cal1.add(Calendar.DATE, i1); 
			d1 = cal1.getTime();
			logger.trace("First Date of time interval: "+d1);
		}

		if(null != i2){
			Calendar cal2 = Calendar.getInstance();
			cal2.add(Calendar.DATE, i2); 
			d2 = cal2.getTime();
			logger.trace("Second Date of time interval: "+d2);
		}

		QueryOptions qo = new QueryOptions();
		Iterator<Object[]> iter; 
		if(null != d1)
			qo.add(Filter.ge(dateAttribute, d1));
		if(null != d2)
			qo.add(Filter.le(dateAttribute, d2)); 	
		qo.addFilter(Filter.ignoreCase(Filter.eq("identityStatus","Inactive")));
		
		if(null != filterString)
			qo.add(Filter.compile(filterString));
		
		if(logger.isDebugEnabled())logger.debug("Filter Query : " +qo.getQuery());
		
		iter = context.search(Identity.class, qo, "id");

		return iter;
	}

}