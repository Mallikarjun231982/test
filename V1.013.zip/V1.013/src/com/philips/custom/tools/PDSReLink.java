package com.philips.custom.tools;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import sailpoint.api.IdentityService;
import sailpoint.api.Provisioner;
import sailpoint.api.Terminator;
import sailpoint.api.Workflower;
import sailpoint.api.SailPointContext;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.Identity.CapabilityManager;
import sailpoint.object.Link;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.ProvisioningPlan.ObjectOperation;
import sailpoint.object.QueryOptions;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskResult.CompletionStatus;
import sailpoint.object.TaskSchedule;
import sailpoint.object.Workflow;
import sailpoint.object.WorkflowLaunch;
import sailpoint.task.AbstractTaskExecutor;
import sailpoint.task.TaskMonitor;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;
import sailpoint.tools.Util;
import sailpoint.web.messages.MessageKeys;

public class PDSReLink extends AbstractTaskExecutor{

	private Log logger = LogFactory.getLog(PDSReLink.class);
	
	private TaskMonitor monitor = null;

	boolean _terminate;

	public boolean is_terminate() {
		return _terminate;
	}

	private SailPointContext _context = null;

	int processed=0;
	
	String _location=null;
	
	public void set_terminate(boolean _terminate) {
		this._terminate = _terminate;
	}

	@Override
	public void execute(SailPointContext context, TaskSchedule taskSchedule,
			TaskResult taskResult, Attributes<String, Object> att) throws Exception {

		monitor = new TaskMonitor(context, taskResult);
		setMonitor(monitor);
		
		_context=context;
		
		if(logger.isDebugEnabled()){
			Iterator<Map.Entry<String, Object>> entries = att.entrySet().iterator();
			while(entries.hasNext()){
				Map.Entry<String, Object> entry = entries.next();
				logger.debug("Attribute : " +entry.getKey() +" Value : " +entry.getValue());	
			}
		}
		
		String oldPDSID=null;
		String newPDSID=null;
		
		if(att.containsKey("oldPDSID"))
			oldPDSID=att.getString("oldPDSID");
		
		if(att.containsKey("newPDSID"))
			newPDSID=att.getString("newPDSID");
		
		if(att.containsKey("pdsOutLocation"))
			_location=att.getString("pdsOutLocation");
		
		if(oldPDSID == null || newPDSID == null)
			throw new GeneralException("both oldPDSID and newPDSID must have a value");
		
		Identity oldIdentity = context.getObjectByName(Identity.class, oldPDSID);
		
		if(null == oldIdentity)
			throw new GeneralException("Did not find Identity for oldPDSID : " +oldPDSID);
		
		Identity newIdentity = context.getObjectByName(Identity.class, newPDSID);
		if(null == newIdentity)
			throw new GeneralException("Did not find Identity for newPDSID : " +newPDSID);
		
		IdentityService ids = new IdentityService(context);
		Application pdsApp = context.getObjectByName(Application.class, "PDS");
		
		List oldPDSLinks = ids.getLinks(oldIdentity, pdsApp);
		Link oldPDSLink = null;
		
		if(oldPDSLinks.size() != 1){
			throw new GeneralException(oldPDSID +" We didn't find exactly one PDS Account " );
		} else {
			oldPDSLink = (Link) oldPDSLinks.get(0);
		}
		
		List newPDSLinks = ids.getLinks(newIdentity, pdsApp);
		
		Link newPDSLink = null;
		
		if(newPDSLinks.size() != 1){
			throw new GeneralException(newPDSID +" We didn't find exactly one PDS Account " );
		} else {
			newPDSLink = (Link) newPDSLinks.get(0);
		}
		
		String newEmployeeID = (String) newIdentity.getAttribute("globalEmployeeId");
		
		deleteCode1Accounts(newIdentity);
		
		movePDSAccount(oldIdentity, oldPDSLink, newIdentity, newPDSLink);
		
		deleteIdentityCube(newPDSID);
		
		context.decache(newIdentity);
		
		oldIdentity.setAttribute("globalEmployeeId", newEmployeeID);
		
		writeToPDS(oldIdentity, oldPDSLink);
		
		taskResult.addMessage("Success");
		taskResult.setCompletionStatus(CompletionStatus.Success);
	}

	private void writeToPDS(Identity identity, Link account) {
		
		logger.debug("Starting writeToPDS: " +identity.getName());

		try{
			String mail = identity.getEmail();

			if(!"Partner".equals(identity.getAttribute("employeeType"))){
				
				logger.debug("account : " +account.getNativeIdentity());
				
				if("PDS".equals(account.getApplicationName())){

					String fileLocation = _location +"/" + account.getAttribute("Global employee identifier") +".xml";

					logger.debug("fileLocation : " +fileLocation);

					DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

					// root elements
					Document doc = docBuilder.newDocument();
					Element rootElement = doc.createElement("PIMToPDS");
					doc.appendChild(rootElement);

					// staff elements
					Element employee = doc.createElement("Employee");
					rootElement.appendChild(employee);


					// firstname elements
					Element oxygenID = doc.createElement("OxygeNID");
					oxygenID.appendChild(doc.createTextNode((String) account.getAttribute("Oxygen ID")));
					employee.appendChild(oxygenID);

					// lastname elements
					Element globalEmployeeID = doc.createElement("GlobalEmployeeIdentifier");
					globalEmployeeID.appendChild(doc.createTextNode((String) account.getAttribute("Global employee identifier")));
					employee.appendChild(globalEmployeeID);

					// nickname elements
					if(null != mail && mail.equals("DELETE")){
						Element businessEmail = doc.createElement("BusinessEmailAddress");
						employee.appendChild(businessEmail);
					} else if(null != mail){
						Element businessEmail = doc.createElement("BusinessEmailAddress");
						businessEmail.appendChild(doc.createTextNode((String) mail));
						employee.appendChild(businessEmail);
					}

					// write the content into xml file
					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = transformerFactory.newTransformer();
					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
					transformer.setOutputProperty(OutputKeys.METHOD, "xml");
					transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
					transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");
					DOMSource source = new DOMSource(doc);
					StreamResult result = new StreamResult(new File(fileLocation));

					logger.debug("result : " +result);

					// Output to console for testing
					// StreamResult result = new StreamResult(System.out);

					transformer.transform(source, result);

				}
			}
		}catch(Exception e){
			logger.error("Exception :", e);
			try {
				throw new GeneralException("Exception: " +e.toString());
			} catch (GeneralException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	private void movePDSAccount(Identity oldIdentity, Link oldPDSLink, Identity newIdentity, Link newPDSLink) {

		try{
			deletePDSAccount(oldIdentity, oldPDSLink);

			Link link = newPDSLink;

			link.setDisplayName(oldIdentity.getName());
			link.setNativeIdentity(oldIdentity.getName());
			link.setAttribute("Oxygen ID",oldIdentity.getName());

			_context.saveObject(link);
			_context.commitTransaction();

			String oxygenId = (String) link.getAttribute("Oxygen ID");
			logger.debug("deleteRedundantIdentities oxygenId " +oxygenId);

			ProvisioningPlan plan = new ProvisioningPlan();
			AccountRequest ar = new AccountRequest();
			AttributeRequest attr = new AttributeRequest();
			List reqs = new ArrayList();

			ar.setApplication(ProvisioningPlan.APP_IIQ);
			attr.setName("links");
			attr.setValue(link.getId());
			attr.setOperation(ProvisioningPlan.Operation.Remove);
			Attributes attributes = new Attributes();
			Map map = new HashMap();
			map.put("destinationIdentity", oldIdentity.getName());
			attributes.setMap(map);
			attr.setArgs(attributes);
			ar.add(attr);	

			reqs.add(ar);


			plan.setAccountRequests(reqs);

			logger.debug("Plan : "+ plan.toXml() );

			HashMap launchArgsMap = new HashMap();

			launchArgsMap.put("plan",plan);
			launchArgsMap.put("identityName",newIdentity.getName());
			launchArgsMap.put("approvalScheme","none");
			//launchArgsMap.put("trace","true");

			//Create WorkflowLaunch and set values
			WorkflowLaunch wflaunch = new WorkflowLaunch();
			Workflow wf = (Workflow) _context.getObjectByName(Workflow.class,"SP Provision Processor Sub");
			wflaunch.setWorkflowName(wf.getName());
			wflaunch.setWorkflowRef(wf.getName());
			wflaunch.setCaseName("LCM Provisioning");
			wflaunch.setVariables(launchArgsMap);
			//Create Workflower and launch workflow from WorkflowLaunch
			Workflower workflower = new Workflower(_context);
			WorkflowLaunch launch = workflower.launch(wflaunch);
			String workFlowId = launch.getWorkflowCase().getId();

			logger.debug("launched WF " +workFlowId);

		}catch(Exception e){
			logger.error("Exception :", e);
			try {
				throw new GeneralException("Exception: " +e.toString());
			} catch (GeneralException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	private void deletePDSAccount(Identity oldIdentity, Link oldPDSLink) {

		try{

			oldIdentity.remove(oldPDSLink);
			
			_context.saveObject(oldIdentity);
			_context.commitTransaction();

		} catch(Exception e){
			logger.error("Exception :", e);
			try {
				throw new GeneralException("Exception: " +e.toString());
			} catch (GeneralException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	private void deleteIdentityCube(String newPDSID) {
		
		Terminator term = new Terminator(_context);
		try {
			term.deleteObjects(Identity.class, new QueryOptions(Filter.eq("name", newPDSID)));
		} catch (GeneralException | IllegalArgumentException e) {
			logger.error("Exception :", e);
			try {
				throw new GeneralException("Exception: " +e.toString());
			} catch (GeneralException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}

	private void deleteCode1Accounts(Identity newIdentity) {

		try{
			IdentityService ids = new IdentityService(_context);

			Application application = _context.getObjectByName(Application.class, "CODE1");

			List<Link> links = ids.getLinks(newIdentity, application);
			
			for(Link link : links){
				ProvisioningPlan plan = new ProvisioningPlan();
				AccountRequest ar = new AccountRequest();
				
				ar.setApplication("CODE1");
				ar.setNativeIdentity(link.getNativeIdentity());
				ar.setOp(ObjectOperation.Delete);
				
				plan.add(ar);
				plan.setIdentity(link.getIdentity());
				
				Provisioner prov = new Provisioner(_context);
				prov.execute(plan);
			}
			
		} catch(Exception e){
			logger.error("Exception :", e);
			try {
				throw new GeneralException("Exception: " +e.toString());
			} catch (GeneralException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	@Override
	public boolean terminate() {
		set_terminate(true);
		return is_terminate();
	}
	
	private String stack2string(Exception e) {
		try {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			return "------\r\n" + sw.toString() + "------\r\n";
		} catch (Exception e2) {
			return "bad stack2string";
		}
	}

}
