package com.philips.custom.tools;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sailpoint.api.RequestManager;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Attributes;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.Request;
import sailpoint.object.RequestDefinition;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;
import sailpoint.workflow.StandardWorkflowHandler;

public class ExtendedRefreshAttributes extends Thread{

	private Log logger = LogFactory.getLog(ExtendedRefreshAttributes.class);

	String _identityName = null;
	String _type = "ALL";

	public ExtendedRefreshAttributes(String identityName, String type){
		_identityName = identityName;

		if(null != type){
			_type=type;
		}
	}

	public void run(){

		SailPointContext context=null;

		try{

			context = SailPointFactory.createContext();

			Identity identity = context.getObjectByName(Identity.class, _identityName);

			ProvisioningPlan plan = new ProvisioningPlan();

			if(null != identity){

				String firstName = identity.getFirstname();

				if(null == firstName){
					firstName = "";
				}

				String lastName = identity.getLastname();

				if(null == lastName){
					lastName = "";
				}

				String lastNamePreFix = (String) identity.getAttribute("nameRoyalPref");


				if(logger.isDebugEnabled()) logger.debug("Got type :" +_type);

				List typeList = Util.csvToList(_type);

				List links = identity.getLinks();

				if(typeList.contains("description") || typeList.contains("ALL")){
					if(logger.isDebugEnabled()) logger.debug("getDescription Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							Date terminationDate = (Date) identity.getAttribute("terminationDate");
							String oldDescription = (String) link.getAttribute("description");
							DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

							//if(logger.isDebugEnabled()) logger.debug("oldDescription : " +oldDescription);

							if( null == link.getAttribute("IIQDisabled") || "false".equals(link.getAttribute("IIQDisabled"))){
								//Account is Active
								if(logger.isDebugEnabled()) logger.debug("Account is Active");
								
								String logonStatus = (String) link.getAttribute("lastLogonStatus");
								
								if(null != logonStatus && logonStatus.equals("INACTIVE") && !oldDescription.toUpperCase().startsWith("_DISABLED_") && !oldDescription.toUpperCase().startsWith("_RETIRED_")){
									if(logger.isDebugEnabled()) logger.debug("Not Logged on for more that 180 days");
									if(null == accreq){
										accreq = PrepareAccountRequest(link);
									} 
									addAttReqtoAccReq(accreq, link, "description", "_DISABLED_" +dateFormat.format(new Date()) +"GMT:NOT_LOGGED_ON_FOR_MONTHS");
								} else if(null != logonStatus && logonStatus.equals("UNKNOWN") && !oldDescription.toUpperCase().startsWith("_DISABLED_") && !oldDescription.toUpperCase().startsWith("_RETIRED_")){
									if(logger.isDebugEnabled()) logger.debug("logonStatus is UNKNOWN");
									//need to check whencreated to see if it was created more than 180 days ago
									String whenCreated = (String) link.getAttribute("whenCreated");
									if(null != whenCreated){
										String[] parts = whenCreated.split("[.]");
										String dateTimePart = parts[0];
										String timeZonePart = "+0" + parts[1].substring(0, parts[1].length() - 1) + "00";
										SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssZ");
										Date whenCreatedDate = sdf.parse(dateTimePart + timeZonePart);
										Calendar whenCreated180DaysAgo = Calendar.getInstance();
										whenCreated180DaysAgo.setTime(whenCreatedDate);
										whenCreated180DaysAgo.add(Calendar.DATE, 180);
										if(whenCreated180DaysAgo.getTime().before(new Date())){
											if(logger.isDebugEnabled()) logger.debug("More than 180 days since creation");
											//Account created more than 180 ago and has not been logged into the Account
											if(null == accreq){
												accreq = PrepareAccountRequest(link);
											} 
											addAttReqtoAccReq(accreq, link, "description", "_DISABLED_" +dateFormat.format(new Date()) +"GMT:NOT_LOGGED_ON_FOR_MONTHS");
										} else {
											if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
												if(logger.isDebugEnabled()) logger.debug("Personal Account");
												String royalName = (String) identity.getAttribute("nameRoyalPref");
												if(null != royalName && !"".equals(royalName)){
													if(null == accreq){
														accreq = PrepareAccountRequest(link);
													}
													addAttReqtoAccReq(accreq, link, "description", firstName +" " +royalName +" " +lastName);
												} else {
													if(null == accreq){
														accreq = PrepareAccountRequest(link);
													}
													addAttReqtoAccReq(accreq, link, "description", firstName +" " +lastName);
												}
											} else if(null != link.getAttribute("employeeType") && "2".equals(link.getAttribute("employeeType"))){
												if(logger.isDebugEnabled()) logger.debug("Functional Account");
												if(null == accreq){
													accreq = PrepareAccountRequest(link);
												}
												addAttReqtoAccReq(accreq, link, "description", "_OWNER:" +identity.getDisplayName());
											}
										}
									}

								} else {
									if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
										if(logger.isDebugEnabled()) logger.debug("Personal Account");
										String royalName = (String) identity.getAttribute("nameRoyalPref");
										if(null != royalName && !"".equals(royalName)){
											if(null == accreq){
												accreq = PrepareAccountRequest(link);
											}
											addAttReqtoAccReq(accreq, link, "description", firstName +" " +royalName +" " +lastName);
										} else {
											if(null == accreq){
												accreq = PrepareAccountRequest(link);
											}
											addAttReqtoAccReq(accreq, link, "description", firstName +" " +lastName);
										}
									} else if(null != link.getAttribute("employeeType") && "2".equals(link.getAttribute("employeeType"))){
										if(logger.isDebugEnabled()) logger.debug("Functional Account");
										if(null == accreq){
											accreq = PrepareAccountRequest(link);
										}
										addAttReqtoAccReq(accreq, link, "description", "_OWNER:" +identity.getDisplayName());
									}
								}
								
								
							} else if(null != link.getAttribute("IIQDisabled") || "true".equals(link.getAttribute("IIQDisabled"))){
								//Account is InActive
								if(logger.isDebugEnabled()) logger.debug("Account Inactive");
								if(null == oldDescription || (!oldDescription.toUpperCase().startsWith("_DISABLED_") && !oldDescription.toUpperCase().startsWith("_RETIRED_"))){
									if(logger.isDebugEnabled()) logger.debug("Account does not already have a disabled description");
									if(null != terminationDate){
										if(new Date().getTime()>terminationDate.getTime()){
											if(logger.isDebugEnabled()) logger.debug("Identity has expired");
											if(null != link.getAttribute("description") && !((String)link.getAttribute("description")).toUpperCase().startsWith("_RETIRED_") && !((String)link.getAttribute("description")).toUpperCase().startsWith("_DISABLED_")){
												if(null == accreq){
													accreq = PrepareAccountRequest(link);
												}
												addAttReqtoAccReq(accreq, link, "description", "_RETIRED_" +dateFormat.format(terminationDate) + " GMT:END-OF-LIFE");
											}
										}else {
											if(logger.isDebugEnabled()) logger.debug("Identity has not expired");
											if(null != link.getAttribute("description") && !((String)link.getAttribute("description")).toUpperCase().startsWith("_RETIRED_") && !((String)link.getAttribute("description")).toUpperCase().startsWith("_DISABLED_")){
												if(null == accreq){
													accreq = PrepareAccountRequest(link);
												}
												addAttReqtoAccReq(accreq, link, "description", "_DISABLED_" +dateFormat.format(new Date()) + " GMT");
											}
										}
									}
								}
								
							}
							if(null != accreq && null != accreq.getAttributeRequests()){
								plan.add(accreq);
							}
						}
					}
				}  
				if(typeList.contains("sn") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("getsn Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								if(null != lastNamePreFix){
									addAttReqtoAccReq(accreq, link, "sn", lastNamePreFix +" " +lastName);
								} else {
									addAttReqtoAccReq(accreq, link, "sn", lastName);
								}

							} else if(null != link.getAttribute("employeeType") && "2".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Functional Account");

								/*
							if(null == accreq){
								accreq = PrepareAccountRequest(link);
							}
							addAttReqtoAccReq(accreq, link, "sn", link.getAttribute("sn"));
								 */
							}
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				} 

				if(typeList.contains("manager-seeAlso") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("manager-seeAlso Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								String managerDN = getManagerDN(identity, context);
								addAttReqtoAccReq(accreq, link, "manager", managerDN);
								addAttReqtoAccReq(accreq, link, "seeAlso", managerDN);
							} 
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}

				if(typeList.contains("initials") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("initials Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								addAttReqtoAccReq(accreq, link, "initials", identity.getAttribute("nameInitials"));
							} 
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}

				if(typeList.contains("personalTitle") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("personalTitle Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								addAttReqtoAccReq(accreq, link, "personalTitle", identity.getAttribute("personalTitle"));
							} 
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}

				if(typeList.contains("extensionAttribute12") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("extensionAttribute12 Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								addAttReqtoAccReq(accreq, link, "extensionAttribute12", identity.getAttribute("assuranceLevel"));
							} 
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}

				if(typeList.contains("employeeID") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("employeeID Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								addAttReqtoAccReq(accreq, link, "employeeID", identity.getAttribute("globalEmployeeId"));
							} 
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}

				if(typeList.contains("businessRoles") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("businessRoles Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								addAttReqtoAccReq(accreq, link, "businessRoles", identity.getAttribute("businessRoleAD"));
							} 
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}

				if(typeList.contains("generationQualifier") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("generationQualifier Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								addAttReqtoAccReq(accreq, link, "generationQualifier", identity.getAttribute("nameRoyalSuf"));
							} 
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}


				if(typeList.contains("displayName") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("getdisplayname Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								addAttReqtoAccReq(accreq, link, "displayName", identity.getDisplayableName());

							} else if(null != link.getAttribute("employeeType") && "2".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Functional Account");
								/*
							if(null == accreq){
								accreq = PrepareAccountRequest(link);
							} 
							addAttReqtoAccReq(accreq, link, "displayName", link.getAttribute("displayName"));
								 */
							}
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}
				if(typeList.contains("givenName") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("getgivenName Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
								if(logger.isDebugEnabled()) logger.debug("Personal Account");

								if(null == accreq){
									accreq = PrepareAccountRequest(link);
								} 
								addAttReqtoAccReq(accreq, link, "givenName", firstName);

							} 
						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}
				if(typeList.contains("employeeNumber") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("employeeNumber Identity " +identity.getName());

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							if(null == accreq){
								accreq = PrepareAccountRequest(link);
							} 
							addAttReqtoAccReq(accreq, link, "employeeNumber", identity.getName());

						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}
				if(typeList.contains("extensionAttribute14") || typeList.contains("ALL")){

					if(logger.isDebugEnabled()) logger.debug("extensionAttribute14 Identity " +identity.getName());

					String identityStatus = (String) identity.getAttribute("identityStatus");

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1") && null != link.getAttribute("employeeType") && ("4".equals(link.getAttribute("employeeType")) || "2".equals(link.getAttribute("employeeType")))){

							if(null == accreq){
								accreq = PrepareAccountRequest(link);
							} 

							if(null == identityStatus){
								addAttReqtoAccReq(accreq, link, "extensionAttribute14", "2");
							} else {

								identityStatus = identityStatus.toLowerCase();

								if(identityStatus.equals("tobeactivated") || identityStatus.equals("active")){
									addAttReqtoAccReq(accreq, link, "extensionAttribute14", "0");
								} else if(identityStatus.equals("inactive")){
									addAttReqtoAccReq(accreq, link, "extensionAttribute14", "1");
								} else {
									addAttReqtoAccReq(accreq, link, "extensionAttribute14", "2");
								}
							}

						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}
				/*
			if(typeList.contains("targetAddress") || typeList.contains("ALL")){

				if(logger.isDebugEnabled()) logger.debug("targetAddress Identity " +identity.getName());

				for(int i =0; i<links.size(); i++){
					AccountRequest accreq = null;

					Link link = (Link) links.get(i);
					if(link.getApplicationName().equals("CODE1") && null != link.getAttribute("mail") && null != link.getAttribute("extensionAttribute1") && "active".equals(link.getAttribute("extensionAttribute1").toString().toLowerCase()) && null != link.getAttribute("employeeType") && ("4".equals(link.getAttribute("employeeType")) || "2".equals(link.getAttribute("employeeType")))){

						String mail = (String) link.getAttribute("mail");

						if(null == accreq){
							accreq = PrepareAccountRequest(link);
						} 

						addAttReqtoAccReq(accreq, link, "targetAddress", "smtp:" +mail.substring(0, mail.indexOf("@"))+"@philips.mail.onmicrosoft.com");

					}
					if(null != accreq && null != accreq.getAttributeRequests()){
						plan.add(accreq);
					}
				}
			}
				 */

				/* Removed from Build
			if(typeList.contains("accountExpires") || typeList.contains("ALL")){

				List links = identity.getLinks();
				if(logger.isDebugEnabled()) logger.debug("accountExpires Identity " +identity.getName());

				Date termDate = (Date) identity.getAttribute("terminationDate");

				if(null != termDate){

					String ldapDate = convertJavadateToADdate(termDate.getTime());

					if(logger.isDebugEnabled()) logger.debug("ldapDate is  " +ldapDate);

					for(int i =0; i<links.size(); i++){
						AccountRequest accreq = null;

						Link link = (Link) links.get(i);
						if(link.getApplicationName().equals("CODE1")){

							String currentValue = (String) link.getAttribute("accountExpires");

							if(logger.isDebugEnabled()) logger.debug("link currentValue is  " +currentValue);

							if(!isNumeric(currentValue) && !"never".equals(currentValue)){
								currentValue = getLdapDate(currentValue);
							} 

							if(!"never".equals(currentValue) || ("never".equals(currentValue) && Long.parseLong(ldapDate) < 2650152384000000000L )){
								if(logger.isDebugEnabled()) logger.debug("Comparing currentValue  " +currentValue +" with : " +ldapDate);
								if("never".equals(currentValue) || (!currentValue.equals(ldapDate) && Math.abs(Long.parseLong(currentValue)-Long.parseLong(ldapDate)) > 3600000000L)){
									if(null == accreq){
										accreq = PrepareAccountRequest(link);
									} 
									addAttReqtoAccReq(accreq, link, "accountExpires", ldapDate);
								}
							}

						}
						if(null != accreq && null != accreq.getAttributeRequests()){
							plan.add(accreq);
						}
					}
				}
			}
				 */

				if(null != plan && null != plan.getAccountRequests() && plan.getAccountRequests().size() >0){
					Map workflowArgs = new HashMap();

					workflowArgs.put("identityName", identity.getName());
					workflowArgs.put("type", "ALL");
					workflowArgs.put("plan", plan);

					launchWorkflow(context, "PhilipsUpdateAccountFromSpecialAttributeTrigger", "(" +identity.getName() +")", workflowArgs, 60000L);
				}

				context.decache(identity);
			}

		}catch(Exception e){
			logger.error(stack2string(e));
		} finally{
			try {
				SailPointFactory.releaseContext(context);
			} catch (GeneralException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private String getManagerDN(Identity identity, SailPointContext context) throws Exception {
		if(null != identity){
			Identity manager = identity.getManager();

			if(null != manager){
				List links = manager.getLinks();

				for(int i =0; i<links.size(); i++){
					Link link = (Link) links.get(i);
					if(link.getApplicationName().equals("CODE1")){
						if(null != link.getAttribute("employeeType") && "4".equals(link.getAttribute("employeeType"))){
							context.decache(manager);
							return link.getNativeIdentity();
						}
					}
				}
				context.decache(manager);
			}
		}
		return null;
	}

	private void launchWorkflow(SailPointContext context, String workflowName, String nameAppend,  Map workflowArgs, long wait) throws Exception {

		String caseName = "";

		if(null == nameAppend){
			caseName = "Run '" + workflowName + "' from Task ";
		} else {
			caseName = "Run '" + workflowName +" " +nameAppend + "' from Task ";
		}

		Identity id = context.getObjectByName(Identity.class, "spadmin");

		long launchTime = System.currentTimeMillis() + wait;  
		caseName = caseName + "(" + launchTime + ")";

		// Build out a map of arguments to pass to the Request Scheduler. 
		Attributes reqArgs = new Attributes();  
		reqArgs.put(StandardWorkflowHandler.ARG_REQUEST_DEFINITION,  sailpoint.request.WorkflowRequestExecutor.DEFINITION_NAME);  
		reqArgs.put(sailpoint.workflow.StandardWorkflowHandler.ARG_WORKFLOW,  workflowName);  
		reqArgs.put(sailpoint.workflow.StandardWorkflowHandler.ARG_REQUEST_NAME,  caseName);  
		reqArgs.put( "requestName", caseName ); 


		reqArgs.putAll(workflowArgs); 

		// Use the Request Launcher to schedule the workflow reqeust.  This requires  
		// a Request object to store the properties of the request item.  
		Request req = new Request();  
		RequestDefinition reqdef = context.getObject(RequestDefinition.class, "Workflow Request");  
		req.setDefinition(reqdef);  
		req.setEventDate( new Date( launchTime ) );  
		req.setOwner(id);  
		req.setName(caseName);  
		req.setAttributes( reqdef, reqArgs );  

		// Schedule the work flow via the request manager.  
		RequestManager.addRequest(context, req);

		context.decache(id);

	}

	private void addAttReqtoAccReq(AccountRequest ar, Link link, String key, Object value){
		if(link != null){
			if(logger.isDebugEnabled()) logger.debug("Calling addAttReqtoAccReq key : " +key +" value : " +value +" link value : " +link.getAttribute(key));
		} else {
			if(logger.isDebugEnabled()) logger.debug("Calling addAttReqtoAccReq key : " +key +" value : " +value  +" link is null");
		}
		if(null == link || (null == link.getAttribute(key) && null != value && !"".equals(value) ) || (null != value && null != link.getAttribute(key) && !link.getAttribute(key).equals(value)) ){
			AttributeRequest attr = new AttributeRequest();
			attr.setName(key);
			attr.setValue(value);
			attr.setOperation(ProvisioningPlan.Operation.Set);
			ar.add(attr);
		}

	}

	private String convertJavadateToADdate(long javatime) {
		javatime = Long.parseLong(String.valueOf(javatime));
		if(logger.isDebugEnabled()) logger.debug("long value : "+javatime);



		// convert UNITS from (milliseconds)(100 nano-seconds) to (100 nano-seconds)
		javatime *= 10000;

		// Filetime Epoch is 01 January, 1970
		// LDAP date Epoch is 01 January, 1601
		// so take the number and Add java Epoch:

		Long adtime = javatime + 116444736000000000L;

		if(logger.isDebugEnabled()) logger.debug("adtime value : "+adtime);



		// Date(long date)
		// Allocates a Date object and initializes it to represent
		// the specified number of milliseconds since the standard base
		// time known as "the epoch", namely January 1, 1970, 00:00:00 GMT.
		return ""+adtime;
	}

	private String stack2string(Exception e) { 

		try { 

			StringWriter sw = new StringWriter(); 
			PrintWriter pw = new PrintWriter(sw); 
			e.printStackTrace(pw); 

			return "------\r\n" + sw.toString() + "------\r\n"; 

		} 
		catch(Exception e2) { 
			return "bad stack2string"; 
		} 
	}

	private boolean isNumeric(String str) {
		if (str == null) {
			return false;
		}
		int sz = str.length();
		for (int i = 0; i < sz; i++) {
			if (Character.isDigit(str.charAt(i)) == false) {
				return false;
			}
		}
		return true;
	}


	private String getLdapDate(String dateAttrStr) throws Exception{

		if(isNumeric(dateAttrStr)){
			return dateAttrStr;
		} else {
			long timeAdjust=11644473600000L;
			String format = "M/d/y h:m:s a z"; 
			DateFormat df = new SimpleDateFormat(format);
			Date dateAtt = df.parse(dateAttrStr);
			return ""+(dateAtt.getTime()+timeAdjust)*10000;
		}
	}

	private AccountRequest PrepareAccountRequest(Link link){
		AccountRequest accreq = new AccountRequest();
		accreq.setApplication("CODE1");
		accreq.setNativeIdentity(link.getNativeIdentity());
		accreq.setOp(ProvisioningPlan.ObjectOperation.Modify);
		return accreq;
	}
}
