package com.philips.custom.tools.migration;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Capability;
import sailpoint.object.Identity;
import sailpoint.tools.GeneralException;

public class AmRaHdMigrator{
	
	//The folder where the output is written to.
	private String outputFolderName;
	//The path of the CSV file containing the mappings of roles to OUs
	private String rolesFile;
	//The path of the CSV file containing the mapping of ObjectIds to PIMIds, __ sorted by ObjectId in ascending order __! 
	private String pimIdsFile;
	
	
	private SortedMap<String, User> accountManagers;
	private SortedMap<String, User> helpDeskPersonnel;
	private SortedMap<String, User> RAManagers;

	private SortedMap<String, Integer> ouStatsAM;
	private SortedMap<String, Integer> ouStatsHD;
	private SortedMap<String, Integer> ouStatsRA;
	private int objectIdOff;
	private int pIMIDOff;
	private int numUsersSuccess;
	private int numUsersError;
	private int numOUs;
	private int numAccountManagers;
	private int numHelpDeskPersonnel;
	private int numRAManagers;

	private enum UserCapability {ACCOUNT_MANAGER, HELP_DESK_PERSONNEL, RA_MANAGER};

	public AmRaHdMigrator() {
		objectIdOff = -1;
		pIMIDOff = -1;
		numUsersSuccess = 0;
		numUsersError = 0;
		numOUs = 0;
		numAccountManagers = 0;
		numHelpDeskPersonnel = 0;
		numRAManagers = 0;
		
		accountManagers = new TreeMap<String, User>();
		helpDeskPersonnel = new TreeMap<String, User>();
		RAManagers = new TreeMap<String, User>();
		
		ouStatsAM = new TreeMap<String, Integer>();
		ouStatsHD = new TreeMap<String, Integer>();
		ouStatsRA = new TreeMap<String, Integer>();
	}

	

	public void execute(SailPointContext context, String _rolesFile, String _pimIdsFile, String _outputFolderName, Log log) throws Exception {
		this.rolesFile=_rolesFile;
		this.pimIdsFile=_pimIdsFile;
		this.outputFolderName=_outputFolderName;
		
		log.info("Cleaning errors file...");
		cleanErrorsFile();

		log.info("Collecting roles...");
		collectRoles(rolesFile, log);

		log.info("Determining PIMIDs for roles...");
		determinePIMIds(pimIdsFile);

		log.info("Assigning IIQ Capabilities...");
		assignIIQCapabilities(context);
		
		log.info("Writing Output XML file...");
		writeXMLOutput(context);
		
		log.info("Writing Stats...");
		writeStats();

		log.info("Done");
	}

	/**
	 * Deletes the MigrationErrors file of previous runs
	 */
	private void cleanErrorsFile() {
		File outFile = new File(outputFolderName + "\\MigrationErrors.txt");
		outFile.delete();
	}


	/**
	 * Determines the PIMID for each user.
	 * @param pimFileName The location of the PIM QA Exported file in csv format, sorted by ObjectId in ascending order.
	 * @throws IOException 
	 */
	private void determinePIMIds(String pimFileName) throws IOException{
		String[] fields;
		BufferedReader br = new BufferedReader(new FileReader(pimFileName));
		//locate columns
		String line = br.readLine();
		if(line != null){
			fields = line.split(";");
			for(int i = 0; i < fields.length; i++){
				if(fields[i].equals("ObjectId")){
					objectIdOff = i;
					if(pIMIDOff >= 0)
						break;
					else
						continue;
				}
				if(fields[i].equals("PIMID")){
					pIMIDOff = i;
					if(objectIdOff >= 0)
						break;
					else
						continue;
				}
			}
		}
		//Iterators for user maps
		Iterator<Map.Entry<String, User>> amIt = accountManagers.entrySet().iterator();
		Iterator<Map.Entry<String, User>> hdIt = helpDeskPersonnel.entrySet().iterator();
		Iterator<Map.Entry<String, User>> raIt = RAManagers.entrySet().iterator();
		User currentAM = null;
		User currentHD = null;
		User currentRA = null;

		//Initialize references to current users
		if(amIt.hasNext())
			currentAM = amIt.next().getValue();
		if(hdIt.hasNext())
			currentHD = hdIt.next().getValue();
		if(raIt.hasNext())
			currentRA = raIt.next().getValue();

		//The main loop.
		//Let X be the number of mappings of ObjectIds to PIMIds and Y the number of ObjectIds to revolve.
		//Since we iterate exactly once through all mappings of ObjectIds to PIMIds this loop is O(X).
		//This works only if the mappings of ObjectIds to PIMIds are sorted by ObjectIds
		//A naive approach which just searches every single user to resolve would be O(X*Y), which is much worse since X and Y are 
		//quite huge.
		for(line = br.readLine(); line != null; line = br.readLine()){
			fields = line.split(";");
			String currentObjectId = fields[objectIdOff].toLowerCase();
			if(currentAM != null){
				if(currentObjectId.equals(currentAM.getUUID())){
					currentAM.setPimid(fields[pIMIDOff]);
					if(amIt.hasNext())
						currentAM = amIt.next().getValue();
					else
						currentAM = null; //No more AMs to process
				}
				else if(currentObjectId.compareTo(currentAM.getUUID()) > 0){
					//not found
					logProcessError("Could not resolve user in PIM QA Export: " + currentAM.getUUID());
					for(String ou: currentAM.getOUs()){
						ouStatsAM.put(ou, ouStatsAM.get(ou) - 1);
					}
					amIt.remove();
					numUsersError++;
					if(amIt.hasNext())
						currentAM = amIt.next().getValue();
					else
						currentAM = null; //No more AMs to process
				}
			}
			if(currentHD != null){
				if(currentObjectId.equals(currentHD.getUUID())){
					currentHD.setPimid(fields[pIMIDOff]);
					if(hdIt.hasNext())
						currentHD = hdIt.next().getValue();
					else
						currentHD = null; //No more HDs to process
				}
				else if(currentObjectId.compareTo(currentHD.getUUID()) > 0){
					//not found
					logProcessError("Could not resolve user in PIM QA Export: " + currentHD.getUUID());
					for(String ou: currentHD.getOUs()){
						ouStatsHD.put(ou, ouStatsHD.get(ou) - 1);
					}
					hdIt.remove();
					numUsersError++;
					if(hdIt.hasNext())
						currentHD = hdIt.next().getValue();
					else
						currentHD = null; //No more HDs to process
				}
			}
			if(currentRA != null){
				if(currentObjectId.equals(currentRA.getUUID())){
					currentRA.setPimid(fields[pIMIDOff]);
					if(raIt.hasNext())
						currentRA = raIt.next().getValue();
					else
						currentRA = null; //No more RAs to process
				}
				else if(currentObjectId.compareTo(currentRA.getUUID()) > 0){
					//not found
					logProcessError("Could not resolve user in PIM QA Export: " + currentRA.getUUID());
					for(String ou: currentRA.getOUs()){
						ouStatsRA.put(ou, ouStatsRA.get(ou) - 1);
					}
					raIt.remove();
					numUsersError++;
					if(raIt.hasNext())
						currentRA = raIt.next().getValue();
					else
						currentRA = null; //No more RAs to process
				}
			}
		}
		br.close();

	}

	/**
	 * Collects Account Manager, Help Desk Personnel and RA Manager roles per OU.
	 * @param rolesFileName The location of the Account Manager Roles GUID file in CSV format 
	 * @throws IOException 
	 */
	private void collectRoles(String rolesFileName, Log log) throws IOException{

		String[] fields;
		int ownerOff = -1;
		int nameOff = -1;
		int hdOff = -1;
		int raOff = -1;

		log.trace("collectRoles: open account managers file");
		BufferedReader br = new BufferedReader(new FileReader(rolesFileName));
		log.trace("collectRoles: locate columns");
		String line = br.readLine();
		if(line != null){
			fields = line.split(";");
			for(int i = 0; i < fields.length; i++){
				if(fields[i].equals("Owner")){
					ownerOff = i;
					continue;
				}
				if(fields[i].equals("Name")){
					nameOff = i;
					continue;
				}
				if(fields[i].equals("ExecutorsHD")){
					hdOff = i;
					continue;
				}
				if(fields[i].equals("ExecutorsRA")){
					raOff = i;
					continue;
				}
			}
		}
		log.trace("collectRoles: iterate over lines");
		for(line = br.readLine(); line != null; line = br.readLine()){
			fields = line.split(";");
			if(fields.length <= 1)
				continue;
			//determine OU
			String ou = fields[nameOff];
			//count for stats
			numOUs++;
			String[] userUUIDs;
			//collect Account Managers for OU
			if(ownerOff < fields.length){
				userUUIDs = extractUUIDsFromString(fields[ownerOff]);
				int n = userUUIDs.length;
				for(String uuid: userUUIDs){
					if(uuid.equals("")){
						n--;
						continue;
					}
					User u = createOrGetUser(uuid, UserCapability.ACCOUNT_MANAGER);
					u.addOU(ou);
				}
				ouStatsAM.put(ou, n);
			}
			//collect Help Desk Personnel for OU
			if(hdOff < fields.length){
				userUUIDs = extractUUIDsFromString(fields[hdOff]);
				int n = userUUIDs.length;
				for(String uuid: userUUIDs){
					if(uuid.equals("")){
						n--;
						continue;
					}
					User u = createOrGetUser(uuid, UserCapability.HELP_DESK_PERSONNEL);
					u.addOU(ou);
				}
				ouStatsHD.put(ou, n);
			}
			//collect RA managers for OU
			if(raOff < fields.length){
				userUUIDs = extractUUIDsFromString(fields[raOff]);
				int n = userUUIDs.length;
				for(String uuid: userUUIDs){
					if(uuid.equals("")){
						n--;
						continue;
					}
					User u = createOrGetUser(uuid, UserCapability.RA_MANAGER);
					u.addOU(ou);
				}
				ouStatsRA.put(ou, n);
			}
		}
		br.close();
	}

	/**
	 * Perform the IIQ assignments. 
	 * @throws GeneralException
	 * @throws IOException
	 */
	private void assignIIQCapabilities(SailPointContext context) throws GeneralException, IOException{
		Iterator<Map.Entry<String, User>> it = accountManagers.entrySet().iterator();
		while(it.hasNext()){
			User u = it.next().getValue();
			Identity id = null;
			try{
				id = context.getObjectByName(Identity.class, u.getPimid());
				if(id == null) throw new GeneralException();
			} catch (GeneralException e){
				logProcessError("No such user in IIQ: " + u.getPimid());
				numUsersError++;
				for(String ou: u.getOUs()){
					ouStatsAM.put(ou, ouStatsAM.get(ou) - 1);
				}
				continue;
			}
			//If that fails, fail hard since it would always fail and the whole function would not make sense!
			Capability cap = context.getObjectByName(Capability.class, "AccountManager"); 
			id.add(cap);
			try{
				context.saveObject(id);
			} catch(GeneralException e){
				logProcessError("Error on saving identity: " + u.getPimid());
				numUsersError++;
			}
			numAccountManagers++;
			numUsersSuccess++;
		}

		it = helpDeskPersonnel.entrySet().iterator();
		while(it.hasNext()){
			User u = it.next().getValue();
			Identity id = null;
			try{
				id = context.getObjectByName(Identity.class, u.getPimid());
				if(id == null) throw new GeneralException();
			} catch (GeneralException e){
				logProcessError("No such user in IIQ: " + u.getPimid());
				numUsersError++;
				for(String ou: u.getOUs()){
					ouStatsHD.put(ou, ouStatsHD.get(ou) - 1);
				}
				continue;
			}
			//If that fails, fail hard since it would always fail and the whole function would not make sense!
			Capability cap = context.getObjectByName(Capability.class, "HelpDesk");
			id.add(cap);

			//Fail softly, because there might be some workgroups which do not exist.
			for(String ou: u.getOUs()){
				Identity wg = null;
				String wgName = "wg-" + ou + "-HelpDesk";
				try{
					wg = context.getObjectByName(Identity.class, wgName);
					if(wg == null) throw new GeneralException();
				} catch (GeneralException e){
					logProcessError("No such workgroup: " + wgName);
					//Subtract by one due to error
					ouStatsHD.put(ou, ouStatsHD.get(ou) - 1);
					
					numUsersError++;
					continue;
				}
				id.add(wg);
				try{
					context.saveObject(id);
				} catch(GeneralException e){
					logProcessError("Error on saving identity: " + u.getPimid());
					numUsersError++;
				}
				numHelpDeskPersonnel++;
				numUsersSuccess++;
			}
		}

		it = RAManagers.entrySet().iterator();
		while(it.hasNext()){
			User u = it.next().getValue();
			Identity id = null;
			try{
				id = context.getObjectByName(Identity.class, u.getPimid());
				if(id == null) throw new GeneralException();
			} catch (GeneralException e){
				logProcessError("No such user in IIQ: " + u.getPimid());
				numUsersError++;
				for(String ou: u.getOUs()){
					ouStatsRA.put(ou, ouStatsRA.get(ou) - 1);
				}
				continue;
			}
			//If that fails, fail hard since it would always fail and the whole function would not make sense!
			Capability cap = context.getObjectByName(Capability.class, "RAManager");
			id.add(cap);
			
			//Fail softly, because there might be some workgroups which do not exist.
			for(String ou: u.getOUs()){
				Identity wg = null;
				String wgName = "wg-" + ou + "-RAManager";
				try{
					wg = context.getObjectByName(Identity.class, wgName);
					if(wg == null) throw new GeneralException();
				} catch (GeneralException e){
					logProcessError("No such workgroup: " + wgName);
					//Subtract by one due to error
					ouStatsRA.put(ou, ouStatsRA.get(ou) - 1);
					
					numUsersError++;
					continue;
				}
				id.add(wg);
				
			}
			try{
				context.saveObject(id);
			} catch(GeneralException e){
				logProcessError("Error on saving identity: " + u.getPimid());
				numUsersError++;
			}
			numRAManagers++;
			numUsersSuccess++;
		}
		context.commitTransaction();
	}

	/**
	 * Writes the Account Manager XML Output into a single file.
	 * @throws Exception 
	 */
	private void writeXMLOutput(SailPointContext context) throws Exception{
		writeXMLOutput(Integer.MAX_VALUE, context);
	}
	
	/**
	 * Writes the Account Manager XML Output into files with at most maxNumberOfUsers users.
	 * @param maxNumberOfUsers
	 * @throws IOException
	 * @throws Exception 
	 */
	private void writeXMLOutput(int maxNumberOfUsers, SailPointContext context) throws IOException, Exception{
		boolean done = false;
		int chunkCount = 0;
		int fileNum = 0;
		
		logProcessError("Starting writeXMLOutput ");
		
		Iterator<Map.Entry<String, User>> it = accountManagers.entrySet().iterator();
			
			// Change to move AccountManager OU onto the Identity. PH 25/10/2016
			
			while(it.hasNext()){
	
				User u = it.next().getValue();
		
				try{
					String pimid = u.getPimid();
				
					Identity id = context.getObjectByName(Identity.class, u.getPimid());
				
					SortedSet<String> oUs = u.getOUs();
	
					List amOUList = new ArrayList();
					for(String oU: oUs){
						//logProcessError("Adding OU " +oU +" to " +pimid );
						amOUList.add(oU);
					}
					id.setAttribute("amScopes", amOUList);
					context.saveObject(id);
					context.commitTransaction();
					logProcessError("Updating PIMID : " +pimid );
					context.decache(id);
				}catch(Exception e){
					logProcessError("writeXMLOutput exception for pimid " +u.getPimid());
				}
			}
			
			/*
			fileNum++;
			//Open file
			File outFile = null;
			if(fileNum > 1)
				outFile = new File(outputFolderName + "\\AccountManagers" + fileNum + ".xml");
			else
				outFile = new File(outputFolderName + "\\AccountManagers.xml");
			FileWriter outFileWriter = new FileWriter(outFile, false);
			PrintWriter out = new PrintWriter(outFileWriter);
			//Write headers
			out.println("<?xml version='1.0' encoding='UTF-8'?>");
			out.println("<!DOCTYPE sailpoint PUBLIC \"sailpoint.dtd\" \"sailpoint.dtd\">");
			out.println("<sailpoint>");
			while(chunkCount < maxNumberOfUsers){
				if(it.hasNext()){
					User u = it.next().getValue();
					String pimid = u.getPimid();
					SortedSet<String> oUs = u.getOUs();
					int oUCounter = 0;
					//write key tag
					out.println("  <Custom name=\"PhilipsAccountManagerScopes-" + pimid + "\">");
					out.println("    <Attributes>");
					out.println("      <Map>");
					out.println("        <entry key=\"Scope\">");
					out.println("          <value>");
					out.println("            <List>");
					for(String oU: oUs){
						//write ou tag
						out.println("          <String>" + oU + "</String>");
						oUCounter++;
					}
					out.println("            </List>");
					out.println("          </value>");
					out.println("        </entry>");
					out.println("      </Map>");
					out.println("    </Attributes>");
					out.println("  </Custom>");
					chunkCount++;
				} else {
					done = true;
					break;
				}
			}
			out.println("</sailpoint>");
			//Close file
			out.close();
			*/

		logProcessError("Finished writeXMLOutput ");
	}
	
	/**
	 * Outputs the process statistics.
	 * @throws IOException
	 */
	private void writeStats() throws IOException{
		//Open file
		File outFile = new File(outputFolderName + "\\MigrationStats.txt");
		FileWriter outFileWriter = new FileWriter(outFile, false);
		PrintWriter out = new PrintWriter(outFileWriter);

		out.println("Users migrated with success: " + numUsersSuccess);
		out.println("Users migrated with error: " + numUsersError);

		out.println("Users with AccountManager Capability: " + numAccountManagers);
		out.println("Users with HelpDesk Capability: " + numHelpDeskPersonnel);
		out.println("Users with RAManager Capability: " + numRAManagers);

		out.println("Number of OUs: " + numOUs);
		
		out.println("OU Stats Account Managers:");
		Iterator<Map.Entry<String, Integer>> it = ouStatsAM.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry<String, Integer> entry = it.next();
			out.println("OU: " + entry.getKey() + "   Number of Account Managers: " + entry.getValue());
		}
		
		out.println("OU Stats Helpdesk Personnel:");
		it = ouStatsHD.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry<String, Integer> entry = it.next();
			out.println("OU: " + entry.getKey() + "   Number of Helpdesk Personnel: " + entry.getValue());
		}
		
		out.println("OU Stats RA Managers:");
		it = ouStatsRA.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry<String, Integer> entry = it.next();
			out.println("OU: " + entry.getKey() + "   Number of RA Managers: " + entry.getValue());
		}

		out.close();
	}
	
	/**
	 * Logs the process error message.
	 * @param message
	 * @throws IOException
	 */
	private void logProcessError(String message) throws IOException{
		//Open file
		File outFile = new File(outputFolderName + "\\MigrationErrors.txt");
		FileWriter outFileWriter = new FileWriter(outFile, true);
		PrintWriter out = new PrintWriter(outFileWriter);

		out.println(message);

		out.close();
	}

	/**
	 * Extracts the UUIDs from the consecutive UUIDs string
	 * @param s Input of format (urn:uuid:[uuid])*
	 * @return array of UUID string tokens 
	 */
	private String[] extractUUIDsFromString(String s){
		return s.split("urn:uuid:");
	}

	/**
	 * This method is the defined way to attempt to add a user representation as
	 * it ensures that there is at most one representation of a user in each collection.
	 * 
	 * @param uuid User Object Id
	 * @param c User Capability
	 * @return The unique representation of the user in the map of their capability 
	 */
	private User createOrGetUser(String uuid, UserCapability c){
		User u = null;
		SortedMap<String, User> m = null;
		switch(c){
		case ACCOUNT_MANAGER:
			m = accountManagers;
			break;
		case HELP_DESK_PERSONNEL:
			m = helpDeskPersonnel;
			break;
		case RA_MANAGER:
			m = RAManagers;
			break;
		}

		u = m.get(uuid);
		//We never map a uuid to null, so if u is null the user is not present.
		//Saves an iteration through the map for every user.
		if(u == null){
			u = new User(uuid);
			m.put(uuid, u);
		}
		return u;
	}
}
