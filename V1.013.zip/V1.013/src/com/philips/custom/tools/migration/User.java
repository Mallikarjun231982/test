package com.philips.custom.tools.migration;

import java.util.SortedSet;
import java.util.TreeSet;

public class User implements Comparable<User>{
	private String uuid;
	private String pimid;
	private SortedSet<String> oUs;

	public User(String uuid){
		this.uuid = uuid.toLowerCase();
		oUs = new TreeSet<String>();
	}
	
	public void addOU(String OUName){
		oUs.add(OUName);	
	}
	
	public String getUUID(){
		return uuid;
	}
	
	public SortedSet<String> getOUs(){
		return oUs;
	}
	
	/**
	 * We need to override equals(), because we identify users per uuid only and do not take
	 * the OUs into consideration for comparison. By doing so we can use a java Set and ensure that 
	 * each user has a unique representation in it.
	 */
	@Override
	public boolean equals(Object o){
		if(!(o instanceof User))
			return false;
		return this.uuid.equals(((User)o).getUUID());
	}
	
	@Override
	public int hashCode(){
		return uuid.hashCode();	
	}

	/**
	 * We need to implement compareTo in order to use a SortedSet and make the comparison consistent
	 * to the definition of equivalence and avoid attempts to perform comparisons on the OU Lists which
	 * would be very costly.
	 */
	@Override
	public int compareTo(User u) {
		return this.uuid.compareTo(u.getUUID());
	}

	public String getPimid() {
		return pimid;
	}

	public void setPimid(String pimid) {
		this.pimid = pimid;
	}
}
