package com.philips.custom.tools.migration;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Capability;
import sailpoint.object.Identity;

/**
 * 
 * @author engels
 *
 */
public class SimpleMigrator {
	/**
	 * 
	 * @param filePath
	 * @param capabilityName
	 * 
	 * The simple migrator expects the path to a csv file in which the first column contains 
	 * the name attribute of the identity. In addition the name of the capability which should be assigned to these identities
	 * is required.
	 */
	public MigratorResult execute(SailPointContext context, String filePath, String capabilityName, Log log){
		log.trace("Executing SimpleMigrator.execute... ");
		int total=0;
		int success=0;
		int failed=0;
		
		List<String> identityIDs=null;
		try {
			identityIDs = getListOfIdentitiesFromFile(filePath, log);
		} catch (Exception e) {
			log.error("Could not open or read file: "+filePath);
			e.printStackTrace();
		}
		if (identityIDs!=null){
			total = identityIDs.size();
			log.trace("Going trough list and assigning capabilities...");
			for (String id : identityIDs) {
				try {
					assignCapability(context, capabilityName, id, log);
					success++;
				} catch (Exception e) {
					log.error("Could not assign capability");
					failed++;
					e.printStackTrace();
				}	
			}
			log.trace("Capabilities assigned.");
		}
		
		return new MigratorResult(capabilityName, total, success, failed);
		
	}

	private void assignCapability(SailPointContext context,
			String capabilityName, String pimid, Log log) throws Exception {
		if (context == null){
			log.error("Context not available");
			throw new Exception("Context not available");
		}
		
		Identity id = context.getObjectByName(Identity.class, pimid);
		if (id == null){
			log.error("Identity ("+pimid+") not found");
			throw new Exception("Identity not found");
		}
			
		Capability cap = context.getObjectByName(Capability.class, capabilityName);
		if (cap == null){
			log.error("Capability not found");
			throw new Exception("Capability not found");
		}
		
		log.trace("Adding capability "+cap.getName()+" to identity "+id.getName());
		id.add(cap);

		log.trace("save...");
		context.saveObject(id);
		context.commitTransaction();

		//TODO nice to have: check if capability has been assigned already

	}

	private List<String> getListOfIdentitiesFromFile(String filePath, Log log) throws Exception{
		log.trace("Entered SimpleMigrator.getListOfIdentitiesFromFile()...");
		List<String> identityIDs = new ArrayList<String>();
		String[] fields;
				
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String row = br.readLine();
		for(row = br.readLine(); row != null; row = br.readLine()){
			fields = row.split(";");
			if(fields.length <= 1){
				continue;
			}
			identityIDs.add(fields[0]);
		}
		br.close();
		log.trace("Returning identityIDs: "+identityIDs.toString());
		return identityIDs;
	}

}
