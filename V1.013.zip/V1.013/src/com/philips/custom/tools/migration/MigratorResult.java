package com.philips.custom.tools.migration;

public class MigratorResult {
	
	private String resultType;
	private int total;
	private int success;
	private int failed;
	private int alreadyAssigned;
	
		


	public MigratorResult(String resultType, int total, int success, int failed,int alreadyAssigned) {
		this.resultType=resultType;
		this.total = total;
		this.success = success;
		this.failed = failed;
		this.alreadyAssigned = alreadyAssigned;
	}
	
	public MigratorResult(String resultType, int total, int success, int failed) {
		this.resultType=resultType;
		this.total = total;
		this.success = success;
		this.failed = failed;
	}
	
	@Override
	public String toString() {
		return "MigratorResult [resultType=" + resultType + ", total=" + total
				+ ", success=" + success + ", failed=" + failed
				+ /*", alreadyAssigned=" + alreadyAssigned + */"]";
	}

	public String getResultType() {
		return resultType;
	}
	public int getTotal() {
		return total;
	}
	public int getSuccess() {
		return success;
	}
	public int getFailed() {
		return failed;
	}
	public int getAlreadyAssigned() {
		return alreadyAssigned;
	}

}
