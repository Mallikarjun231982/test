package com.philips.custom.tools.migration;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Attributes;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskResult.CompletionStatus;
import sailpoint.object.TaskSchedule;
import sailpoint.task.AbstractTaskExecutor;
import sailpoint.task.TaskMonitor;

public class StaticGroupsMigrationExecutor extends AbstractTaskExecutor {
	
	private static Log log = org.apache.commons.logging.LogFactory.getLog("com.philips.custom.tools.migration");
	private TaskMonitor monitor = null;
	private List<MigratorResult> migResults = new ArrayList<MigratorResult>();
	private int errCounter=0;

	boolean _terminate;
	
	public boolean is_terminate() {
		return _terminate;
	}

	public void set_terminate(boolean _terminate) {
		this._terminate = _terminate;
	}
	
	@Override
	public boolean terminate() {
		set_terminate(true);
		return is_terminate();
	}

	@Override
	public void execute(SailPointContext context, TaskSchedule taskSchedule,
			TaskResult taskResult, Attributes<String, Object> att){
		
		log.trace("Entered StaticGroupsMigrationExecutor.execute...");
		
		monitor = new TaskMonitor(context, taskResult);
		setMonitor(monitor);
		
		log.trace("Going through input arguments...");
		log.trace("List of input arguments: "+att.toString());
		
		if(att.containsKey("clearAM") && att.getBoolean("clearAM") == true){
			log.trace("Calling CapabilityCleaner().clear(\"AccountManager\")..");
			migResults.add(new CapabilityCleaner().clear(context, "AccountManager", log));
		}
		if(att.containsKey("clearRA") && att.getBoolean("clearRA") == true){
			log.trace("Calling CapabilityCleaner().clear(\"RAManager\")..");
			migResults.add(new CapabilityCleaner().clear(context, "RAManager", log));			
		}
		if(att.containsKey("clearHD") && att.getBoolean("clearHD") == true){
			log.trace("Calling CapabilityCleaner().clear(\"HelpDesk\")..");
			migResults.add(new CapabilityCleaner().clear(context, "HelpDesk",log));			
		}
		if(att.containsKey("clearMM") && att.getBoolean("clearMM") == true){
			log.trace("Calling CapabilityCleaner().clear(\"GlobalMailManager\")..");
			migResults.add(new CapabilityCleaner().clear(context, "GlobalMailManager",log));			
		}
		if(att.containsKey("clearDI") && att.getBoolean("clearDI") == true){
			log.trace("Calling CapabilityCleaner().clear(\"GlobalDataInspector\")..");
			migResults.add(new CapabilityCleaner().clear(context, "GlobalDataInspector",log));			
		}
		if(att.containsKey("ClearGDQM") && att.getBoolean("ClearGDQM") == true){
			log.trace("Calling CapabilityCleaner().clear(\"GlobalDataQualityManager\")..");
			migResults.add(new CapabilityCleaner().clear(context, "GlobalDataQualityManager",log));			
		}
		if(att.containsKey("importAMRAHD") && att.getBoolean("importAMRAHD") == true){
			String rolesFile="";
			String pimIdsFile="";
			String outputFolderName="";
			if(att.containsKey("amrahdRolesFile") && att.get("amrahdRolesFile") != null){
				rolesFile=att.get("amrahdRolesFile").toString();
			}else {
				log.error("amrahdRolesFile Path for option A not defined!");
				errCounter++;
			}
			if(att.containsKey("amrahdPimIdsFile") && att.get("amrahdPimIdsFile") != null){
				pimIdsFile=att.get("amrahdPimIdsFile").toString();
			}else{
				log.error("amrahdPimIdsFile Path for option A not defined!");
				errCounter++;
			}
			if(att.containsKey("amrahdOutputFolderName") && att.get("amrahdOutputFolderName") != null){
				outputFolderName=att.get("amrahdOutputFolderName").toString();				
			}else{
				log.error("amrahdOutputFolderName Path for option A not defined!");
				errCounter++;
			}
			log.trace("Calling AmRaHdMigrator().execute...");
			try {
				new AmRaHdMigrator().execute(context, rolesFile, pimIdsFile, outputFolderName, log);
			} catch (Exception e) {
				log.error("Execution of AmRaHdMigrator failed!");
				errCounter++;
				e.printStackTrace();
			}
		}
		if(att.containsKey("importMM") && att.getBoolean("importMM") == true){
			if(att.containsKey("mmFile") && att.get("mmFile") != null){
				log.trace("Calling SimpleMigrator().execute(att.get(\"mmFile\").toString(), \"GlobalMailManager\")... ");
				migResults.add(new SimpleMigrator().execute(context, att.get("mmFile").toString(), "GlobalMailManager", log));
			}else{
				log.error("Path for option B not defined!");
				errCounter++;
			}
		}
		if(att.containsKey("importDI") && att.getBoolean("importDI") == true){
			if(att.containsKey("diFile") && att.get("diFile") != null){
				log.trace("Calling SimpleMigrator().execute(att.get(\"diFile\").toString(), \"GlobalDataInspector\")... ");
				migResults.add(new SimpleMigrator().execute(context, att.get("diFile").toString(), "GlobalDataInspector", log));
			}else{
				log.error("Path for option C not defined!");
				errCounter++;
			}
		}
		if(att.containsKey("importGDQM") && att.getBoolean("importGDQM") == true){
			if(att.containsKey("gdqmFile") && att.get("gdqmFile") != null){
				log.trace("Calling SimpleMigrator().execute(att.get(\"gdqmFile\").toString(), \"GlobalDataQualityManager\")...");
				migResults.add(new SimpleMigrator().execute(context, att.get("gdqmFile").toString(), "GlobalDataQualityManager", log));				
			}else{
				log.error("Path for option D not defined!");
				errCounter++;
			}
		}
		
		
		if(migResults.isEmpty()){
			taskResult.addMessage("No migration results available...");
		}else{
			for (MigratorResult migratorResult : migResults) {
				taskResult.addMessage(migratorResult.toString());
			}	
		}
		taskResult.addMessage("Task ended with "+errCounter+" errors, see logs for details." );
		taskResult.setCompletionStatus(CompletionStatus.Success);
		log.trace("Exit StaticGroupsMigrationExecutor.execute...");
		
	}
}
