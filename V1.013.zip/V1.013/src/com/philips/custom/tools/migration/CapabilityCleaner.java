package com.philips.custom.tools.migration;

import java.util.Iterator;

import org.apache.commons.logging.Log;

import sailpoint.api.SailPointContext;
import sailpoint.object.Capability;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.QueryOptions;

public class CapabilityCleaner {
	
	public MigratorResult clear(SailPointContext context,String capabilityName, Log log) {
		log.trace("Entered CapabilityCleaner.clear... ");
		int total=0;
		int success=0;
		int failed=0;
		

		Iterator<Object[]> iter = null;
		try {
			iter = getIdentities(context, capabilityName, log);
		} catch (Exception e) {
			log.error("Could not search context for identities");
			e.printStackTrace();
		}
        if (iter!=null){
        	log.trace("Going trough list and removing capabilities...");
        	while (iter.hasNext()) {
        		Object[] obj = (Object[]) iter.next();
	   			log.trace("Identity: "+obj[0]);
	   			String id=obj[0].toString();
				try {
					removeCapability(context, capabilityName, id, log);
					success++;
					total++;
				} catch (Exception e) {
					log.error("Could not remove capability");
					failed++;
					total++;
					e.printStackTrace();
				}	
        	}
        	log.trace("Capabilities removed.");
        }
        		
        return new MigratorResult(capabilityName, total, success, failed);
        		
	}

	

	private Iterator<Object[]> getIdentities(SailPointContext context,
			String capabilityName, Log log) throws Exception {
		log.trace("Entered CapabilityCleaner.getIdentities...");
		
		QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("capabilities.name", capabilityName));       
        Iterator<Object[]> iter = context.search(Identity.class, qo, "name");
        
		return iter;
	}




	private void removeCapability(SailPointContext context,
			String capabilityName, String pimid, Log log) throws Exception {
		log.trace("Entered CapabilityCleaner.removeCapability");
		if (context == null){
			log.error("Context not available");
			throw new Exception("Context not available");
		}
		
		Identity id = context.getObjectByName(Identity.class, pimid);
		if (id == null){
			log.error("Identity ("+pimid+") not found");
			throw new Exception("Identity not found");
		}
			
		Capability cap = context.getObjectByName(Capability.class, capabilityName);
		if (cap == null){
			log.error("Capability not found");
			throw new Exception("Capability not found");
		}
		
		log.trace("Removing capability "+cap.getName()+" from identity "+id.getName());
		id.remove(cap);

		log.trace("save...");
		context.saveObject(id);
		context.commitTransaction();

	}

}

