package com.philips.custom.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sailpoint.api.Aggregator;
import sailpoint.api.IdentityService;
import sailpoint.api.SailPointContext;
import sailpoint.connector.Connector;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.ResourceObject;
import sailpoint.object.Rule;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskResult.CompletionStatus;
import sailpoint.object.TaskSchedule;
import sailpoint.task.AbstractTaskExecutor;
import sailpoint.tools.GeneralException;

public class SingleUserAggregation extends AbstractTaskExecutor{
	
	private boolean terminated = false;
	private Log logger = LogFactory.getLog(SingleUserAggregation.class);

	@Override
	public void execute(SailPointContext context, TaskSchedule taskSchedule, TaskResult taskResult, Attributes<String, Object> attr)
			throws Exception {
		
		if(logger.isDebugEnabled()) logger.debug("attr: " +attr);
		
		String application = (String) attr.get("application");
		String identityString = (String) attr.get("identity");
		boolean allAccounts = false;
		
		if(attr.containsKey("allAccounts") && "true".equals(attr.get("allAccounts"))){
			if(logger.isDebugEnabled()) logger.debug("found allAccounts " );
			allAccounts = true;
		}
		String accountName = (String) attr.get("accountName");
		
		List<String> accountNIs = new ArrayList();
		
		if(allAccounts){
			
			IdentityService ids = new IdentityService(context);
			Application app = context.getObject(Application.class, application);
			Identity identity = context.getObject(Identity.class, identityString);
			
			List<Link> links = ids.getLinks(identity, app);
			
			for(Link link : links){
				accountNIs.add(link.getNativeIdentity());
			}
			
			context.decache(identity);
			context.decache(app);
			
		}else{
			if(null == accountName){
				throw new GeneralException("Either Account Name or All Accounts must be populated");
			}
			
			Link account = context.getUniqueObject(Link.class, Filter.or(Filter.eq("nativeIdentity", accountName), Filter.eq("linkMail", accountName)));
			
			if(null != account){
				accountNIs.add(account.getNativeIdentity());
				
				context.decache(account);
			}else{
				throw new GeneralException("Did not find nativeIdentity for " +accountName);
			}
		}
		
		//OK We know what to Aggregate now
		
		if(logger.isDebugEnabled()) logger.debug("accountNIs: " +accountNIs);
		
		boolean allSuccess = true;
		
		for(String account : accountNIs){
			if(terminated){
				break;
			}
			String result = aggregate(account, application, context);
			
			if("Success".equals(result)){
				taskResult.addMessage("Succfully Aggregated : " +account);
			} else {
				throw new GeneralException(result);
			}
		}
		
		if(!terminated){
			taskResult.setCompletionStatus(CompletionStatus.Success);
		}
		
	}

	private String aggregate(String accountName, String applicationName, SailPointContext context) throws Exception {
		

		// Initialize the error message to nothing.
		String errorMessage = "";


		// We have already validated all of the arguments.  No just load the objects.
		Application appObject = context.getObject(Application.class, applicationName);
		String appConnName = appObject.getConnector();
		if(logger.isDebugEnabled()) logger.debug("Application " + applicationName + " uses connector " + appConnName);

		Connector appConnector = sailpoint.connector.ConnectorFactory.getConnector(appObject, null);
		if (null == appConnector) {
		   errorMessage = "Failed to construct an instance of connector [" + appConnName + "]";
		   return errorMessage;
		}

		if(logger.isDebugEnabled()) logger.debug("Connector instantiated, calling getObject() to read account details...");

		ResourceObject rObj = null;
		try {
		   
		   rObj = (ResourceObject) appConnector.getObject("account", accountName, null);
		   
		} catch (sailpoint.connector.ObjectNotFoundException onfe) {
		   errorMessage = "Connector could not find account: [" + accountName + "]";
		   errorMessage += " in application  [" + applicationName + "]";
		   if(logger.isDebugEnabled()) logger.error(errorMessage);
		   if(logger.isDebugEnabled()) logger.error(onfe);   
		   return errorMessage;
		}

		if (null == rObj) {
		   errorMessage = "ERROR: Could not get ResourceObject for account: " + accountName;
		   if(logger.isDebugEnabled()) logger.error(errorMessage);
		   return errorMessage;
		}

		if(logger.isDebugEnabled()) logger.debug("Got raw resourceObject: " + rObj.toXml());

		// Now we have a raw ResourceObject.  The Application in IdentityIQ may have a 
		// Customization rule defined to transform the ResourceObject.  We need to 
		// honor that configuration, so if the Applicaiton has a Rule then we run it.
		Rule customizationRule = appObject.getCustomizationRule();
		if (null != customizationRule) {

			if(logger.isDebugEnabled()) logger.debug("Customization rule found for applicaiton " + applicationName);   
		   
		   try {
		   
		      // Pass the mandatory arguments to the Customization rule for the app.
		      HashMap ruleArgs = new HashMap();
		      ruleArgs.put("context",     context);
		      ruleArgs.put("log",         logger);
		      ruleArgs.put("object",      rObj);
		      ruleArgs.put("application", appObject);
		      ruleArgs.put("connector",   appConnector);
		      ruleArgs.put("state",       new HashMap());
		   
		      // Call the customization rule just like a normal aggregation would.
		      ResourceObject newRObj = (ResourceObject) context.runRule(customizationRule, ruleArgs, null);
		      
		      // Make sure we got a valid resourceObject back from the rule.  
		      if (null != newRObj) {
		         rObj = newRObj;
		         if(logger.isDebugEnabled()) logger.debug("Got post-customization resourceObject: " + rObj.toXml());
		      }    
		      
		   } catch (Exception ex) {
		   
		      // Swallow any customization rule errors, the show must go on!
			   if(logger.isDebugEnabled()) logger.error("Error while running Customization rule for " + applicationName);
		         
		   }  

		}

		// Next we perform a miniature "Aggregation" using IIQ's built in Aggregator.
		// Create an arguments map for the aggregation task. 
		// To change this (if you need to), the map contains aggregation options and is the same as the 
		// arguments to the acocunt aggregation tasks.  Some suggestied defaults are:
		Attributes argMap = new Attributes();
		argMap.put("promoteAttributes",       "true");
		argMap.put("correlateEntitlements",   "true");
		argMap.put("noOptimizeReaggregation", "true");  // Note: Set to false to disable re-correlation.

		// Consturct an aggregator instance.
		Aggregator agg = new Aggregator(context, argMap);
		if (null == agg) {
		   errorMessage = "Null Aggregator returned from constructor.  Unable to Aggregate!";
		   if(logger.isDebugEnabled()) logger.error(errorMessage);
		   return errorMessage;
		}

		// Invoke the aggregation task by calling the aggregate() method.
		// Note: the aggregate() call may take serveral seconds to complete.
		if(logger.isDebugEnabled()) logger.debug("Calling aggregate() method... ");
		TaskResult taskResult = agg.aggregate(appObject, rObj);
		if(logger.isDebugEnabled()) logger.debug("aggregation complete.");

		if (null == taskResult) {
		   errorMessage = "ERROR: Null taskResult returned from aggregate() call.";
		   if(logger.isDebugEnabled()) logger.error(errorMessage);
		   return errorMessage;
		}



		if(logger.isDebugEnabled()) logger.debug("TaskResult details: \n" + taskResult.toXml());

		return "Success";
		
	}

	@Override
	public boolean terminate() {
		
		terminated=true;
		
		return false;
	}

}
