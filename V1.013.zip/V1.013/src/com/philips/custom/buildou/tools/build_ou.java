package com.philips.custom.buildou.tools;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;


import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.api.Terminator;
import sailpoint.object.Application;
import sailpoint.object.ApplicationAccountSelectorRule;
import sailpoint.object.Attributes;
import sailpoint.object.Bundle;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.IdentitySelector;
import sailpoint.object.ManagedAttribute;
import sailpoint.object.Profile;
import sailpoint.object.QueryOptions;
import sailpoint.object.Rule;
import sailpoint.object.SailPointObject;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskSchedule;
import sailpoint.task.AbstractTaskExecutor;
import sailpoint.task.Monitor;
import sailpoint.task.TaskMonitor;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;

public class build_ou
extends AbstractTaskExecutor {
    private static Logger log = Logger.getLogger((String)"rule.philips.task.buildou");
    private Application application;
    private TaskMonitor monitor = null;
    private SailPointContext _context = null;
    boolean _terminate;
    private Bundle b;
    private InitialDirContext dirContext = null;
    private String application_id;
    private String orRol_id;
    private NamingEnumeration results;
    private List ouResults = null;
    private List current_workgroups = null;
    private List workgroups_to_delete = null;
    private List<Bundle> current_BR_roles = null;
    private List<Bundle> current_IT_roles = null;
    private int no_ent_value = 0;
    private String no_ent_value_names = "";
    private int no_itRol_value = 0;
    private String no_itRol_value_names = "";
    private int wg_created = 0;
    private int wg_existing = 0;
    private int total_wg = 0;
    private int AD_total_wg = 0;
    private int delete_wg = 0;
    private int deleted = 0;
    private int it_roles_sp = 0;
    private int it_roles_created = 0;
    private int it_roles_existent = 0;
    private int it_roles_activated = 0;
    private int it_roles_deactivated = 0;
    private int it_roles_not_exist = 0;
    private int it_roles_deleted = 0;
    private int it_roles_already_deactivated = 0;
    private int BR_roles_sp = 0;
    private int BR_roles_created = 0;
    private int BR_roles_existent = 0;
    private int BR_roles_activated = 0;
    private int BR_roles_deactivated = 0;
    private int BR_roles_not_exist = 0;
    private int BR_roles_already_deactivated = 0;
    private int BR_roles_deleted = 0;

    private int ManageITRole(SailPointContext context, Application app, Identity owner, String entName, String entValue, String rolName, String displayName, String ruleName, String operation) {
        log.debug((Object)("Starting method ManageITRole :: entitlement name: " + entName + " entitlement value: " + entValue + " rolName: " + rolName));
        this.b = null;
        log.debug((Object)("Searching the IT rol " + rolName));
        try {
            this.b = (Bundle)context.getObjectByName((Class)Bundle.class, rolName);
        }
        catch (GeneralException e) {
            e.printStackTrace();
        }
        if (this.b == null) {
            if (operation.equalsIgnoreCase("Create")) {
                ArrayList<String> ents = new ArrayList<String>();
                ents.add(entValue);
                log.debug((Object)"ManageITRole creating filter");
                ArrayList<Filter> cons = new ArrayList<Filter>();
                cons.add(Filter.containsAll((String)entName, ents));
                log.debug((Object)("ManageITRole constraints: " + cons));
                log.debug((Object)"ManageITRole rol not found... The IT rol will be created ");
                log.debug((Object)"ManageITRole creating the profile");
                Rule ruleSelector = null;
                try {
                    ruleSelector = (Rule)context.getObjectByName((Class)Rule.class, ruleName);
                }
                catch (GeneralException e) {
                    e.printStackTrace();
                    try {
                        this.TerminateWithError("Fatal error --- The rule: " + ruleName + " cannot be found");
                    }
                    catch (GeneralException f) {
                        f.printStackTrace();
                        return -1;
                    }
                }
                ApplicationAccountSelectorRule app_accsel_rul = new ApplicationAccountSelectorRule(app, ruleSelector);
                ArrayList<ApplicationAccountSelectorRule> acc_app = new ArrayList<ApplicationAccountSelectorRule>();
                acc_app.add(app_accsel_rul);
                Profile profile = new Profile();
                profile.setApplication(app);
                profile.setConstraints(cons);
                log.debug((Object)"ManageITRole saving the profile");
                try {
                    context.saveObject((SailPointObject)profile);
                    context.commitTransaction();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                log.debug((Object)("ManageITRole Creating the IT Rol " + rolName));
                Bundle role = new Bundle();
                role.setName(rolName);
                role.setDisplayName(displayName);
                role.setType("it");
                if (owner != null) {
                    role.setOwner(owner);
                }
                role.addDescription("Automatic creation of the IT Rol " + rolName, "en_US");
                role.setApplicationAccountSelectorRules(acc_app);
                role.setAllowDuplicateAccounts(false);
                role.setAllowMultipleAssignments(false);
                role.setMergeTemplates(false);
                role.add(profile);
                log.debug((Object)("ManageITRole saving the role: " + (Object)role));
                try {
                    context.saveObject((SailPointObject)role);
                    context.commitTransaction();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    this.b = (Bundle)context.getObjectByName((Class)Bundle.class, rolName);
                }
                catch (GeneralException e) {
                    e.printStackTrace();
                }
                return 1;
            }
            log.error((Object)("The rol " + rolName + " does not exist on delete operation"));
            return 4;
        }
        if (operation.equalsIgnoreCase("Delete")) {
            if (!this.b.isDisabled()) {
                this.b.setDisabled(true);
                try {
                    context.saveObject((SailPointObject)this.b);
                    context.commitTransaction();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                return 2;
            }
            return 5;
        }
        if (this.b.isDisabled()) {
            this.b.setDisabled(false);
            try {
                context.saveObject((SailPointObject)this.b);
                context.commitTransaction();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            return 6;
        }
        log.debug((Object)"Rol found and active");
        return 3;
    }

    private int ManageBRRole(SailPointContext context, Identity owner, String rolName, String displayName, String itRoleName, String orRoleID, String ruleName, String operation) {
        log.debug((Object)("Starting method ManageBRRole :: rolName: " + rolName));
        this.b = null;
        Bundle itRol = null;
        Bundle orRol = null;
        log.debug((Object)("ManageBRRole Searching the BR rol " + rolName));
        try {
            this.b = (Bundle)context.getObjectByName((Class)Bundle.class, rolName);
        }
        catch (GeneralException e) {
            e.printStackTrace();
        }
        if (operation.equalsIgnoreCase("Create")) {
            log.debug((Object)("ManageBRRole Searching the it rol " + itRoleName));
            try {
                itRol = (Bundle)context.getObjectByName((Class)Bundle.class, itRoleName);
            }
            catch (GeneralException e) {
                e.printStackTrace();
            }
        }
        log.debug((Object)("ManageBRRole Searching the Organizational rol " + orRoleID));
        try {
            orRol = (Bundle)context.getObjectById((Class)Bundle.class, orRoleID);
        }
        catch (GeneralException e) {
            e.printStackTrace();
        }
        if (this.b == null && itRol != null) {
            if (operation.equalsIgnoreCase("Create")) {
                log.debug((Object)"ManageBRRole rol not found... The BR rol will be created ");
                log.debug((Object)"ManageBRRole creating the profile");
                Rule ruleSelector = null;
                try {
                    ruleSelector = (Rule)context.getObjectByName((Class)Rule.class, ruleName);
                }
                catch (GeneralException e) {
                    e.printStackTrace();
                    try {
                        this.TerminateWithError("Fatal error recovering the rule " + ruleName);
                    }
                    catch (GeneralException f) {
                        f.printStackTrace();
                    }
                }
                IdentitySelector ident_selector = new IdentitySelector();
                ident_selector.setRule(ruleSelector);
                log.debug((Object)("ManageITRole Creating the IT Rol " + rolName));
                Bundle role = new Bundle();
                role.setName(rolName);
                role.setDisplayName(displayName);
                role.setType("business");
                role.addRequirement(itRol);
                if (owner != null) {
                    role.setOwner(owner);
                }
                role.addDescription("Automatic creation of the BR Rol " + rolName, "en_US");
                if (orRol != null) {
                    role.addInheritance(orRol);
                }
                role.setSelector(ident_selector);
                role.setAllowDuplicateAccounts(false);
                role.setAllowMultipleAssignments(false);
                role.setMergeTemplates(false);
                log.debug((Object)("ManageBRRole saving the role: " + (Object)role));
                try {
                    context.saveObject((SailPointObject)role);
                    context.commitTransaction();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                itRol.addInheritance(role);
                try {
                    context.saveObject((SailPointObject)itRol);
                    context.commitTransaction();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                return 1;
            }
            log.error((Object)("The rol " + rolName + " does not exist on delete operation"));
            return 4;
        }
        if (operation.equalsIgnoreCase("Delete")) {
            if (this.b != null && !this.b.isDisabled()) {
                this.b.setDisabled(true);
                try {
                    context.saveObject((SailPointObject)this.b);
                    context.commitTransaction();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                return 2;
            }
            if (this.b != null) {
                return 5;
            }
            return 4;
        }
        if (this.b != null) {
            List inheritance;
            boolean modified = false;
            int value_to_return = 3;
            List requirements = this.b.getRequirements();
            if (requirements != null) {
                if (!requirements.contains((Object)itRol)) {
                    this.b.addRequirement(itRol);
                    itRol.addInheritance(this.b);
                    try {
                        context.saveObject((SailPointObject)itRol);
                        context.commitTransaction();
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                    modified = true;
                }
            } else {
                this.b.addRequirement(itRol);
                itRol.addInheritance(this.b);
                try {
                    context.saveObject((SailPointObject)itRol);
                    context.commitTransaction();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                modified = true;
            }
            if (this.b.isDisabled()) {
                this.b.setDisabled(false);
                modified = true;
                value_to_return = 6;
            }
            if (!(inheritance = this.b.getInheritance()).contains((Object)orRol)) {
                inheritance.clear();
                inheritance.add(orRol);
                this.b.setInheritance(inheritance);
                modified = true;
            }
            if (modified) {
                try {
                    context.saveObject((SailPointObject)this.b);
                    context.commitTransaction();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return value_to_return;
        }
        if (this.b == null && itRol != null) {
            ++this.no_itRol_value;
            this.no_itRol_value_names = this.no_itRol_value == 1 ? itRoleName : this.no_itRol_value_names + "\n" + itRoleName;
            return 7;
        }
        return 3;
    }

    private void Load_IT_Roles() {
        QueryOptions it_ro = new QueryOptions();
        it_ro.addFilter(Filter.like((String)"name", (Object)"IT_"));
        this.current_IT_roles = null;
        try {
            this.current_IT_roles = this._context.getObjects((Class)Bundle.class, it_ro);
        }
        catch (GeneralException e) {
            e.printStackTrace();
            log.error((Object)"The current IT roles cannot be retrieved");
        }
        if (this.current_IT_roles != null) {
            this.it_roles_sp = this.current_IT_roles.size();
        }
    }

    private void Load_BR_Roles() {
        QueryOptions br_ro = new QueryOptions();
        br_ro.addFilter(Filter.like((String)"name", (Object)"BR_"));
        this.current_BR_roles = null;
        try {
            this.current_BR_roles = this._context.getObjects((Class)Bundle.class, br_ro);
        }
        catch (GeneralException e) {
            e.printStackTrace();
            log.error((Object)"The current BR roles cannot be retrieved");
        }
        if (this.current_BR_roles != null) {
            this.BR_roles_sp = this.current_BR_roles.size();
        }
    }

    public void set_terminate(boolean _terminate) {
        this._terminate = _terminate;
    }

    public boolean is_terminate() {
        return this._terminate;
    }

    public boolean terminate() {
        this.set_terminate(true);
        return this.is_terminate();
    }

    private String getEntitlementValue(SailPointContext context, String ou) {
        log.debug((Object)("Starting getEntitlementValue - Entitlement: " + ou));
        try {
            log.debug((Object)"Creating filter");
            QueryOptions qo = new QueryOptions();
            qo.addFilter(Filter.eq((String)"displayName", (Object)("gd_AccountManagerOwner_" + ou)));
            log.debug((Object)"Filter created");
            Iterator maResult = context.search((Class)ManagedAttribute.class, qo);
            if (maResult.hasNext()) {
                log.debug((Object)"Managed Attribute found");
                ManagedAttribute ent = (ManagedAttribute)maResult.next();
                return ent.getNativeIdentity();
            }
            log.debug((Object)"The managed attribute does not exist.");
        }
        catch (Exception e) {
            e.printStackTrace();
            try {
                this.TerminateWithError(e.getMessage());
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
        return null;
    }

    private boolean get_AD_details() {
        log.debug((Object)"Start get_AD_details");
        try {
            this.application = (Application)this._context.getObjectById((Class)Application.class, this.application_id);
        }
        catch (GeneralException e) {
            e.printStackTrace();
            try {
                this.TerminateWithError("The information of the application: " + this.application_id + "cannot be retrieved");
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
        log.debug((Object)("application : " + (Object)this.application));
        List domainSettingsList = (List)this.application.getAttributeValue("domainSettings");
        Map domainSettings = (Map)domainSettingsList.get(0);
        Object ldapHost = domainSettings.get("servers");
        String ldapPort = (String)domainSettings.get("port");
        String ldapUser = (String)domainSettings.get("user");
        String ldapPwd = null;
        try {
            ldapPwd = this._context.decrypt((String)domainSettings.get("password"));
        }
        catch (GeneralException e) {
            log.debug("Error retrieving the password for AD application");
            e.printStackTrace();
            try {
                this.TerminateWithError("The password of the application " + (Object)this.application + "cannot be decrypted");
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
        log.debug((Object)("ldapHost : " + ldapHost + " ldapPort : " + ldapPort + " ldapUser : " + ldapUser + " ldapPwd : " + "xxxx"));
        List searchDNList = (List)this.application.getAttributeValue("account.searchDNs");
        log.debug("SearchDNList retrieved: "+searchDNList);
        Map searchDNMap = (Map)searchDNList.get(0);
        String searchDN = (String)searchDNMap.get("searchDN");
        log.debug("SearchDN retrieved: "+searchDN);
        if(searchDN == null || searchDN.equalsIgnoreCase(""))
            searchDN ="dc=code1-test,dc=emi-test,dc=philips,dc=com";
        if (ldapHost instanceof List) {
            List ldatHostList = (List)ldapHost;
            for (int i = 0; i < ldatHostList.size(); ++i) {
                String ldapHostName = (String)ldatHostList.get(i);
                Properties properties = new Properties();
                properties.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
                if (ldapPort.equals("389")) {
                    properties.put("java.naming.provider.url", "LDAP://" + ldapHostName + ":" + ldapPort);
                } else if (ldapPort.equals("636")) {
                    properties.put("java.naming.provider.url", "LDAPS://" + ldapHostName + ":" + ldapPort);
                }
                properties.put("java.naming.security.principal", ldapUser);
                properties.put("java.naming.security.credentials", ldapPwd);
                try {
                    this.dirContext = new InitialDirContext(properties);
                    continue;
                }
                catch (NamingException e) {
                    log.error((Object)e.getMessage());
                }
            }
        } else if (ldapHost instanceof String) {
            Properties properties = new Properties();
            properties.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            if (ldapPort.equals("389")) {
                properties.put("java.naming.provider.url", "LDAP://" + ldapHost + ":" + ldapPort);
            } else if (ldapPort.equals("636")) {
                properties.put("java.naming.provider.url", "LDAPS://" + ldapHost + ":" + ldapPort);
            }
            properties.put("java.naming.security.principal", ldapUser);
            properties.put("java.naming.security.credentials", ldapPwd);
            try {
                this.dirContext = new InitialDirContext(properties);
            }
            catch (NamingException e) {
                log.error((Object)e.getMessage());
                return false;
            }
        }
        log.debug((Object)("dirContext " + this.dirContext));
        SearchControls searchCtls = new SearchControls();
        searchCtls.setSearchScope(1);
        String searchFilter = "(objectClass=organizationalUnit)";
        String searchBase = searchDN;
        try {
            this.results = this.dirContext.search(searchBase, searchFilter, searchCtls);
        }
        catch (NamingException e) {
            e.printStackTrace();
            try {
                this.TerminateWithError("The OU of the AD cannot be retrieved");
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
        return true;
    }

    private void load_current_groups() {
        boolean ouCounter = false;
        this.current_workgroups = new ArrayList();
        this.workgroups_to_delete = new ArrayList();
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq((String)"workgroup", (Object)true));
        qo.addFilter(Filter.like((String)"name", (Object)"wg-"));
        log.debug((Object)"Populate the existing groups information");
        Iterator wgIter = null;
        try {
            wgIter = this._context.search((Class)Identity.class, qo);
        }
        catch (GeneralException e) {
            e.printStackTrace();
            try {
                this.TerminateWithError("The current workgroups information cannot be retrieved");
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
        while (wgIter.hasNext()) {
            ++this.total_wg;
            ++this.deleted;
            Identity wg = (Identity)wgIter.next();
            this.current_workgroups.add(wg.getName());
            this.workgroups_to_delete.add(wg.getName());
        }
    }

    private void load_OU() {
        this.ouResults = new ArrayList();
        log.debug((Object)"Starting Load_OU");
        while (this.results.hasMoreElements()) {
            ++this.AD_total_wg;
            log.debug((Object)("Results to get:" + this.results));
            SearchResult sr = null;
            try {
                sr = (SearchResult)this.results.next();
            }
            catch (NamingException e) {
                e.printStackTrace();
                try {
                    this.TerminateWithError("The OU information cannot be retrieved");
                }
                catch (GeneralException f) {
                    f.printStackTrace();
                }
            }
            String ou = sr.getName().substring(3);
            this.ouResults.add(ou);
            String identityNameRA = "wg-" + ou + "-RAManager";
            String identityNameHD = "wg-" + ou + "-HelpDesk";
            if (!this.current_workgroups.contains(identityNameRA)) {
                Identity identityRA = new Identity();
                identityRA.setName(identityNameRA);
                identityRA.setWorkgroup(true);
                try {
                    this._context.saveObject((SailPointObject)identityRA);
                }
                catch (GeneralException e) {
                    e.printStackTrace();
                    try {
                        e.printStackTrace();
                        this.TerminateWithError("The workgroup " + identityNameRA + " cannot be saved");
                    }
                    catch (GeneralException f) {
                        f.printStackTrace();
                    }
                }
                try {
                    this._context.commitTransaction();
                }
                catch (GeneralException e) {
                    e.printStackTrace();
                    try {
                        this.TerminateWithError("The workgroup " + identityNameRA + " cannot be commited");
                    }
                    catch (GeneralException f) {
                        f.printStackTrace();
                    }
                }
                ++this.wg_created;
            } else {
                this.workgroups_to_delete.remove(identityNameRA);
                ++this.wg_existing;
                --this.deleted;
            }
            if (!this.current_workgroups.contains(identityNameHD)) {
                Identity identityHD = new Identity();
                identityHD.setName(identityNameHD);
                identityHD.setWorkgroup(true);
                try {
                    this._context.saveObject((SailPointObject)identityHD);
                }
                catch (GeneralException e) {
                    e.printStackTrace();
                    try {
                        this.TerminateWithError("The workgroup " + identityNameHD + " cannot be saved");
                    }
                    catch (GeneralException f) {
                        f.printStackTrace();
                    }
                }
                try {
                    this._context.commitTransaction();
                }
                catch (GeneralException e) {
                    e.printStackTrace();
                    try {
                        this.TerminateWithError("The workgroup " + identityNameHD + " cannot be commited");
                    }
                    catch (GeneralException f) {
                        f.printStackTrace();
                    }
                }
                ++this.wg_created;
            } else {
                this.workgroups_to_delete.remove(identityNameHD);
                ++this.wg_existing;
                --this.deleted;
            }
            String entValue = this.getEntitlementValue(this._context, ou);
            if (entValue != null) {
                log.debug((Object)("Entitlement found: " + entValue));
                int result_role = this.ManageITRole(this._context, this.application, null, "memberOf", entValue, "IT_gd_AccountManagerOwner_" + ou, "IT role for Account Managers of the " + ou, "Code1 Account Selector", "Create");
                if (result_role == 1) {
                    ++this.it_roles_created;
                } else if (result_role == 3) {
                    if (this.it_roles_sp > 0 && this.current_IT_roles != null) {
                        ++this.it_roles_existent;
                        log.debug((Object)("IT Role to be delete:" + (Object)this.b));
                        log.debug((Object)("Roles:" + this.current_IT_roles));
                        this.current_IT_roles.remove((Object)this.b);
                    } else {
                        log.debug((Object)"Roles cannot be deleted due doesn't exist");
                    }
                } else if (result_role == 6) {
                    ++this.it_roles_activated;
                    this.current_IT_roles.remove((Object)this.b);
                }
                result_role = this.ManageBRRole(this._context, null, "BR_gd_AccountManagerOwner_" + ou, "BR role for Account Managers of the " + ou, "IT_gd_AccountManagerOwner_" + ou, this.orRol_id, "AMRole Selector", "Create");
                if (result_role == 1) {
                    ++this.BR_roles_created;
                    continue;
                }
                if (result_role == 3) {
                    ++this.BR_roles_existent;
                    log.debug((Object)("BR Role to be delete:" + (Object)this.b));
                    this.current_BR_roles.remove((Object)this.b);
                    continue;
                }
                if (result_role != 6) continue;
                ++this.BR_roles_activated;
                this.current_BR_roles.remove((Object)this.b);
                continue;
            }
            ++this.no_itRol_value;
            ++this.no_ent_value;
            this.no_ent_value_names = this.no_ent_value == 1 ? "gd_AccountManagerOwner_" + ou : this.no_ent_value_names + "\ngd_AccountManagerOwner_" + ou;
            if (this.no_itRol_value == 1) {
                this.no_itRol_value_names = "IT_gd_AccountManagerOwner_" + ou;
                continue;
            }
            this.no_itRol_value_names = this.no_itRol_value_names + "\nIT_gd_AccountManagerOwner_" + ou;
        }
        try {
            this.dirContext.close();
        }
        catch (NamingException e) {
            e.printStackTrace();
            try {
                this.TerminateWithError("The context cannot be closed");
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
        Custom philipsOU = null;
        try {
            philipsOU = (Custom)this._context.getObjectByName((Class)Custom.class, "PhilipsOUList");
        }
        catch (GeneralException e) {
            e.printStackTrace();
            try {
                this.TerminateWithError("The workgroup the object Philips OUList cannot be retrieved");
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
        if (null == philipsOU) {
            philipsOU = new Custom();
            philipsOU.setName("PhilipsOUList");
        }
        philipsOU.put("ouList", (Object)this.ouResults);
        try {
            this._context.saveObject((SailPointObject)philipsOU);
        }
        catch (GeneralException e) {
            e.printStackTrace();
            try {
                this.TerminateWithError("The Philips OU list cannot be saved");
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
        try {
            this._context.commitTransaction();
        }
        catch (GeneralException e) {
            e.printStackTrace();
            try {
                this.TerminateWithError("The workgroup OU list cannot be commited");
            }
            catch (GeneralException f) {
                f.printStackTrace();
            }
        }
    }

    private void delete_it_role() {
        for (int i = 0; i < this.current_IT_roles.size(); ++i) {
            this.b = this.current_IT_roles.get(i);
            log.debug((Object)("Deleting the IT rol: " + this.b.getName()));
            int result_role = this.ManageITRole(this._context, this.application, null, "memberOf", "", this.b.getName(), "", "", "Delete");
            if (result_role == 2) {
                ++this.it_roles_deleted;
                continue;
            }
            if (result_role == 4) {
                ++this.it_roles_not_exist;
                continue;
            }
            if (result_role != 5) continue;
            log.debug((Object)"***********************************");
            ++this.it_roles_already_deactivated;
        }
    }

    private void delete_br_role() {
        for (int i = 0; i < this.current_BR_roles.size(); ++i) {
            this.b = this.current_BR_roles.get(i);
            log.debug((Object)("Deleting the BR rol: " + this.b.getName()));
            int result_role = this.ManageBRRole(this._context, null, this.b.getName(), "", "", "", "", "Delete");
            if (result_role == 2) {
                ++this.BR_roles_deleted;
                continue;
            }
            if (result_role == 4) {
                ++this.BR_roles_not_exist;
                continue;
            }
            if (result_role != 5) continue;
            ++this.BR_roles_already_deactivated;
        }
    }

    private void delete_ou() {
        try {
            while (this.deleted > 0) {
                String wg_name = (String)this.workgroups_to_delete.get(this.deleted - 1);
                log.debug((Object)("Deleting group: " + wg_name));
                QueryOptions qo = new QueryOptions();
                qo.addFilter(Filter.eq((String)"workgroup", (Object)true));
                qo.addFilter(Filter.eq((String)"name", (Object)wg_name));
                Terminator term = new Terminator(this._context);
                term.deleteObjects((Class)Identity.class, qo);
                log.debug((Object)("Group deleted:" + this.workgroups_to_delete.get(this.deleted - 1)));
                --this.deleted;
                ++this.delete_wg;
            }
        }
        catch (Exception ex) {
            log.error((Object)("Exception deleting workgroups in Build Ou List : " + ex.getMessage()));
        }
    }

    private void TerminateWithError(String error) throws GeneralException {
        GeneralException e = new GeneralException();
        Message m = new Message();
        m.setKey(error);
        e.setLocalizedMessage(m);
        throw e;
    }

    public void execute(SailPointContext context, TaskSchedule taskSchedule, TaskResult taskResult, Attributes<String, Object> att) {
        String it_threshold;
        String br_threshold;
        String ou_threshold;
        block13 : {
            ou_threshold = null;
            it_threshold = null;
            br_threshold = null;
            log.debug((Object)"Initization of the task");
            this.monitor = new TaskMonitor(context, taskResult);
            this.setMonitor((Monitor)this.monitor);
            this._context = context;
            log.debug((Object)"Starting task Build OU.");
            log.debug((Object)("Source application " + att.get((Object)"application")));
            this.application_id = (String)att.get((Object)"application");
            log.debug((Object)("Application " + (Object)this.application));
            this.orRol_id = (String)att.get((Object)"orRol");
            log.debug((Object)("orRol_id: " + this.orRol_id));
            int ou_sec_threshold = Integer.valueOf(att.getString("ou_sec_threshold"));
            int it_sec_threshold = Integer.valueOf(att.getString("it_sec_threshold"));
            int br_sec_threshold = Integer.valueOf(att.getString("br_sec_threshold"));
            if (this.get_AD_details()) {
                try {
                    this.load_current_groups();
                    this.Load_BR_Roles();
                    this.Load_IT_Roles();
                    this.load_OU();
                    log.debug((Object)("OU Security Threshold: " + ou_sec_threshold));
                    float threshod_comp = (100 - ou_sec_threshold) * this.total_wg;
                    log.debug((Object)("Percentage calculation: " + threshod_comp));
                    log.debug((Object)("Calculation: " + (threshod_comp /= 100.0f)));
                    if ((float)this.deleted < threshod_comp) {
                        this.delete_ou();
                    } else {
                        ou_threshold = "!";
                    }
                    log.debug((Object)("IT role Security Threshold: " + it_sec_threshold));
                    threshod_comp = (100 - it_sec_threshold) * this.total_wg;
                    log.debug((Object)("Percentage calculation: " + threshod_comp));
                    if (this.current_IT_roles != null && (float)this.current_IT_roles.size() < (threshod_comp /= 100.0f)) {
                        this.delete_it_role();
                    } else {
                        it_threshold = "!";
                    }
                    log.debug((Object)("BR role Security Threshold: " + br_sec_threshold));
                    threshod_comp = (100 - br_sec_threshold) * this.total_wg;
                    log.debug((Object)("Percentage calculation: " + threshod_comp));
                    if (this.current_BR_roles != null && (float)this.current_BR_roles.size() < (threshod_comp /= 100.0f)) {
                        this.delete_br_role();
                        break block13;
                    }
                    br_threshold = "!";
                }
                catch (Exception e) {
                    e.printStackTrace();
                    try {
                        this.TerminateWithError(e.getMessage());
                    }
                    catch (GeneralException f) {
                        f.printStackTrace();
                    }
                }
            } else {
                try {
                    this.TerminateWithError("Cannot get the AD Details");
                }
                catch (GeneralException e) {
                    e.printStackTrace();
                }
            }
        }
        taskResult.setAttribute("INI_WG", (Object)Integer.toString(this.total_wg / 2));
        taskResult.setAttribute("AD_WG", (Object)Integer.toString(this.AD_total_wg));
        taskResult.setAttribute("CR_WG", (Object)(Integer.toString(this.wg_created / 2) + "/" + Integer.toString(this.wg_created)));
        taskResult.setAttribute("EX_WG", (Object)(Integer.toString(this.wg_existing / 2) + "/" + Integer.toString(this.wg_existing)));
        taskResult.setAttribute("DE_WG", (Object)(Integer.toString(this.delete_wg / 2) + "/" + Integer.toString(this.delete_wg)));
        taskResult.setAttribute("OU_TH", (Object)ou_threshold);
        taskResult.setAttribute("TOTAL_IT_ROL_TO_AD", (Object)Integer.toString(this.AD_total_wg));
        taskResult.setAttribute("TOTAL_CURRENT_IT_ROL", (Object)Integer.toString(this.it_roles_sp));
        taskResult.setAttribute("IT_ROL_CREATED", (Object)Integer.toString(this.it_roles_created));
        taskResult.setAttribute("IT_ROL_EXIST", (Object)Integer.toString(this.it_roles_existent));
        taskResult.setAttribute("IT_ROL_EXIST_DE", (Object)Integer.toString(this.it_roles_already_deactivated));
        taskResult.setAttribute("IT_ROL_ACT", (Object)Integer.toString(this.it_roles_activated));
        taskResult.setAttribute("IT_ROL_NOT_EXT", (Object)Integer.toString(this.it_roles_not_exist));
        taskResult.setAttribute("IT_ROL_DEL", (Object)Integer.toString(this.it_roles_deleted));
        taskResult.setAttribute("IT_ROL_DEACT", (Object)Integer.toString(this.it_roles_deactivated));
        taskResult.setAttribute("IT_ROL_NO_ENT", (Object)Integer.toString(this.no_ent_value));
        taskResult.setAttribute("NO_ENT", (Object)this.no_ent_value_names);
        taskResult.setAttribute("IT_TH", (Object)it_threshold);
        taskResult.setAttribute("TOTAL_BR_ROL_TO_AD", (Object)Integer.toString(this.AD_total_wg));
        taskResult.setAttribute("TOTAL_CURRENT_BR_ROL", (Object)Integer.toString(this.BR_roles_sp));
        taskResult.setAttribute("BR_ROL_CREATED", (Object)Integer.toString(this.BR_roles_created));
        taskResult.setAttribute("BR_ROL_EXIST", (Object)Integer.toString(this.BR_roles_existent));
        taskResult.setAttribute("BR_ROL_EXIST_DE", (Object)Integer.toString(this.BR_roles_already_deactivated));
        taskResult.setAttribute("BR_ROL_ACT", (Object)Integer.toString(this.BR_roles_activated));
        taskResult.setAttribute("BR_ROL_DEL", (Object)Integer.toString(this.BR_roles_deleted));
        taskResult.setAttribute("BR_ROL_NOT_EXT", (Object)Integer.toString(this.BR_roles_not_exist));
        taskResult.setAttribute("BR_ROL_DEACT", (Object)Integer.toString(this.BR_roles_deactivated));
        taskResult.setAttribute("BR_ROL_NO_IT", (Object)Integer.toString(this.BR_roles_deactivated));
        taskResult.setAttribute("BR_ROL_NO_ENT", (Object)Integer.toString(this.no_itRol_value));
        taskResult.setAttribute("NO_IT_ROL", (Object)this.no_itRol_value_names);
        taskResult.setAttribute("BR_TH", (Object)br_threshold);
    }
}